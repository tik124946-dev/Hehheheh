// archive_nintendo — вход для Nintendo Switch (libnx). Весь интерфейс и логика в app.cpp.
#include <switch.h>
#include <stdio.h>
#include <string.h>
#include "app.hpp"
#include "nsp_install.hpp"
#include "util.hpp"

NspBackend* make_switch_backend(int storage);
bool switch_es_init();
void switch_es_exit();
bool switch_tls_init();
void switch_tls_exit();

static bool g_ncm = false, g_ns = false, g_es = false, g_time = false;

extern "C" void userAppInit(void) {
    appletLockExit();                      // даём время откатить недоустановленное при выходе
    // Торренту нужно 30+ соединений сразу. Памяти под сокеты по умолчанию мало (sb_efficiency = 4) —
    // при нехватке сервис сокетов отдаёт нулевое окно приёма и скорость падает почти до нуля. Берём вдвое больше.
    SocketInitConfig sc = *socketGetDefaultInitConfig();
    sc.sb_efficiency = 8;
    sc.tcp_rx_buf_max_size = 0x80000;           // окно приёма до 512 КиБ на соединение (по умолчанию 256) — выше скорость на одном пире
    sc.tcp_tx_buf_max_size = 0x10000;           // отправляем только мелкие запросы, много не нужно
    if (R_FAILED(socketInitialize(&sc))) socketInitializeDefault();
    g_time = R_SUCCEEDED(timeInitialize());
    g_ncm = R_SUCCEEDED(ncmInitialize());
    g_ns = R_SUCCEEDED(nsInitialize());
    g_es = switch_es_init();
    switch_tls_init();                      // HTTPS для «Скачать по ссылке»; если не получилось — http:// всё равно работает
}

extern "C" void userAppExit(void) {
    switch_tls_exit();
    switch_es_exit();
    if (g_ns) nsExit();
    if (g_ncm) ncmExit();
    if (g_time) timeExit();
    socketExit();
    appletUnlockExit();
}

class SwitchPlatform : public Platform {
public:
    std::string root() override { return "sdmc:/"; }

    bool cal(int64_t ts, TimeCalendarTime& c) {
        if (!g_time) return false;
        TimeCalendarAdditionalInfo info;
        return R_SUCCEEDED(timeToCalendarTimeWithMyRule((u64)ts, &c, &info));
    }
    int64_t epoch() override {
        u64 t = 0;
        if (g_time && R_SUCCEEDED(timeGetCurrentTime(TimeType_Default, &t))) return (int64_t)t;
        return 0;
    }
    std::string time_str() override {
        TimeCalendarTime c; char b[16];
        if (!cal(epoch(), c)) return "--:--";
        snprintf(b, sizeof b, "%02d:%02d", c.hour, c.minute);
        return b;
    }
    std::string date_str(int64_t e) override {
        TimeCalendarTime c; char b[24];
        if (!e || !cal(e, c)) return "—";
        snprintf(b, sizeof b, "%02d.%02d.%02d", c.day, c.month, c.year % 100);
        return b;
    }
    int64_t free_space(int storage) override { return space(storage, true); }
    int64_t total_space(int storage) override { return space(storage, false); }

    bool can_install() override { return g_ncm && g_ns && g_es; }
    Installer* new_installer(int storage, const std::string& resume) override {
        if (!can_install()) return nullptr;
        return new NspInstaller(make_switch_backend(storage), resume);
    }
    void discard_install(int storage, const std::string& state) override {
        if (!can_install()) return;
        NspBackend* be = make_switch_backend(storage);
        nsp_discard(be, state);
        delete be;
    }
    // Яркость и подсветку приложение НЕ трогает (раньше вызовы lbl оставляли экран затемнённым по всей системе).
    // Пока идёт загрузка, консоль только не засыпает и не затемняется сама — это снимается на выходе автоматически.
    void keep_awake(bool on) override {
        appletSetMediaPlaybackState(on);
        appletSetAutoSleepDisabled(on);
    }
    void backlight(bool) override {}           // «погасший» экран — просто чёрная картинка, подсветка не меняется

    // Экранная клавиатура системы (swkbd). Пока она открыта, главный цикл стоит.
    bool text_input(const std::string& header, const std::string& initial, std::string& out, std::string& err) override {
        SwkbdConfig kbd;
        Result rc = swkbdCreate(&kbd, 0);
        if (R_FAILED(rc)) { char b[96]; snprintf(b, sizeof b, "Не удалось открыть клавиатуру (код 0x%X)", (unsigned)rc); err = b; return false; }
        swkbdConfigMakePresetDefault(&kbd);
        swkbdConfigSetType(&kbd, SwkbdType_QWERTY);
        swkbdConfigSetHeaderText(&kbd, header.c_str());
        swkbdConfigSetGuideText(&kbd, "http://… или https://…");
        if (initial.size() <= 400) swkbdConfigSetInitialText(&kbd, initial.c_str());
        swkbdConfigSetStringLenMax(&kbd, 500);
        static char buf[2048];
        buf[0] = 0;
        uint64_t t0 = now_ms();
        rc = swkbdShow(&kbd, buf, sizeof buf);
        swkbdClose(&kbd);
        err.clear();
        if (R_FAILED(rc)) {
            // отмена тоже приходит как ошибка; если клавиатура закрылась мгновенно — скорее всего, она не открылась
            if (now_ms() - t0 < 400) { char b[112]; snprintf(b, sizeof b, "Клавиатура не открылась (код 0x%X). Запустите через hbmenu с удержанием R", (unsigned)rc); err = b; }
            return false;
        }
        buf[sizeof buf - 1] = 0;
        out = buf;
        return true;
    }

private:
    int64_t space(int storage, bool free_) {
        s64 v = 0;
        if (storage == 0) {
            FsFileSystem* fs = fsdevGetDeviceFileSystem("sdmc");
            if (!fs) return -1;
            Result rc = free_ ? fsFsGetFreeSpace(fs, "/", &v) : fsFsGetTotalSpace(fs, "/", &v);
            return R_SUCCEEDED(rc) ? v : -1;
        }
        if (!g_ncm) return -1;
        NcmContentStorage cs;
        if (R_FAILED(ncmOpenContentStorage(&cs, NcmStorageId_BuiltInUser))) return -1;
        Result rc = free_ ? ncmContentStorageGetFreeSpaceSize(&cs, &v) : ncmContentStorageGetTotalSpaceSize(&cs, &v);
        ncmContentStorageClose(&cs);
        return R_SUCCEEDED(rc) ? v : -1;
    }
};

static uint32_t map_keys(u64 d) {
    uint32_t k = 0;
    if (d & HidNpadButton_A) k |= K_A;
    if (d & HidNpadButton_B) k |= K_B;
    if (d & HidNpadButton_X) k |= K_X;
    if (d & HidNpadButton_Y) k |= K_Y;
    if (d & HidNpadButton_L) k |= K_L;
    if (d & HidNpadButton_R) k |= K_R;
    if (d & HidNpadButton_ZL) k |= K_ZL;
    if (d & HidNpadButton_ZR) k |= K_ZR;
    if (d & HidNpadButton_AnyUp) k |= K_UP;
    if (d & HidNpadButton_AnyDown) k |= K_DOWN;
    if (d & HidNpadButton_AnyLeft) k |= K_LEFT;
    if (d & HidNpadButton_AnyRight) k |= K_RIGHT;
    if (d & HidNpadButton_Plus) k |= K_PLUS;
    if (d & HidNpadButton_Minus) k |= K_MINUS;
    if (d) k |= K_ANY;                      // любая кнопка (в т. ч. стики, SL/SR) будит экран
    return k;
}

int main(int, char**) {
    padConfigureInput(8, HidNpadStyleSet_NpadStandard);
    PadState pad;
    padInitializeAny(&pad);
    hidInitializeTouchScreen();

    NWindow* win = nwindowGetDefault();
    Framebuffer fb;
    framebufferCreate(&fb, win, Gfx::W, Gfx::H, PIXEL_FORMAT_RGBA_8888, 2);
    framebufferMakeLinear(&fb);

    SwitchPlatform pf;
    App* app = new App(&pf);
    app->init();
    Gfx* g = new Gfx;
    bool touch_prev = false;
    int touch_x = 0, touch_y = 0;

    while (appletMainLoop()) {
        padUpdate(&pad);
        uint32_t keys = map_keys(padGetButtonsDown(&pad));
        uint64_t now = now_ms();
        HidTouchScreenState ts = {0};
        bool touch = hidGetTouchScreenStates(&ts, 1) > 0 && ts.count > 0;
        if (touch) {
            touch_x = (int)ts.touches[0].x; touch_y = (int)ts.touches[0].y;
            app->touch(touch_x, touch_y, touch_prev ? 1 : 0, now);
        } else if (touch_prev) {
            app->touch(touch_x, touch_y, 2, now);
        }
        touch_prev = touch;
        if (!app->frame(keys, now)) break;

        if (app->dirty(now)) {
            app->draw(*g, now);
            u32 stride;
            u8* out = (u8*)framebufferBegin(&fb, &stride);
            for (int y = 0; y < Gfx::H; y++) memcpy(out + (size_t)y * stride, &g->px[(size_t)y * Gfx::W], Gfx::W * 4);
            framebufferEnd(&fb);
        } else if (!app->busy()) {
            svcSleepThread(16000000ULL);
        }
    }

    delete app;                             // откатывает недоустановленные NSP
    delete g;
    framebufferClose(&fb);
    return 0;
}
