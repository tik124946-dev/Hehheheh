#include "app.hpp"
#include "util.hpp"
#include <algorithm>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

static const uint32_t BG = C(15, 17, 23), PANEL = C(23, 26, 35), CARD = C(31, 35, 48), CARD2 = C(40, 45, 62);
static const uint32_t ACC = C(79, 195, 247), OKC = C(102, 214, 138), WARN = C(255, 193, 7), ERRC = C(239, 83, 80);
static const uint32_t TXT = C(232, 234, 240), DIM = C(136, 143, 160), BAR_BG = C(52, 58, 78);
static const int TOP_H = 64, SIDE_W = 248, BOT_H = 58, CX = SIDE_W + 18, CARD_H = 280;
static const uint64_t MEM_CAP = 64ull << 20;     // окно «вперёд» в памяти: чем оно больше, тем меньше простаивают быстрые пиры
static const char* TAB_NAMES[4] = {"Установленные", "Загрузки", "Торренты", "URL"};

App::App(Platform* pf) : pf_(pf) {}
App::~App() {
    // выход посреди загрузки: сохраняем место остановки, при следующем запуске она продолжится сама
    for (auto& j : jobs_) if (j->st == Job::RUNNING && j->swarm) { suspend_job(*j); save_job(*j, 3); }
    if (awake_) pf_->keep_awake(false);
    if (screen_off_) pf_->backlight(true);
}

bool App::job_running() const { return running() != nullptr; }

App::Job* App::running() const {
    for (auto& j : jobs_) if (j->st == Job::RUNNING) return j.get();
    return nullptr;
}
App::Job* App::find_job(const std::string& h) const {
    for (auto& j : jobs_) if (j->hash == h) return j.get();
    return nullptr;
}

std::string App::job_state_text() const {
    Job* j = running();
    return j ? "running" : "idle";
}

void App::init() {
    std::string root = pf_->root();
    mkdirs(root + "archive_nintendo/torrents");
    mkdirs(root + "archive_nintendo/downloads");
    lib_.load(root + "archive_nintendo/library.txt");
    load_uhist();
    // незавершённые загрузки возвращаем в список как «приостановленные»
    for (auto& e : lib_.items) {
        if (e.status == 1 || e.tpath.empty()) continue;
        auto j = std::make_unique<Job>();
        j->tpath = e.tpath; j->hash = e.hash; j->files_done = e.files_done; j->cur_off = e.cur_off; j->inst = e.inst; j->mode = e.mode;
        std::string err;
        if (!Meta::load(e.tpath, j->meta, err)) { j->st = Job::ERROR; j->err = ".torrent: " + err; j->meta.name = e.name; }
        else j->st = e.status == 3 ? Job::QUEUED : Job::PAUSED;       // 3 — загрузку прервал выход/сбой: продолжаем сами
        if (e.status == 2 && j->st == Job::PAUSED) { j->st = Job::ERROR; j->err = e.note; }
        jobs_.push_back(std::move(j));
    }
    scan_torrents();
    tab_ = jobs_.empty() ? 2 : 1;
    last_space_ = 0;
    queue_next(now_ms());                                             // продолжить то, что было прервано
}

void App::scan_torrents() {
    tors_.clear();
    std::string root = pf_->root();
    std::vector<std::string> dirs = {tdir(), root + "torrents", root};
    for (auto& d : dirs) {
        std::vector<std::string> names;
        if (!list_dir(d, names)) continue;
        std::sort(names.begin(), names.end());
        for (auto& n : names) {
            if (!ends_with_ci(n, ".torrent") || tors_.size() >= 300) continue;
            TorEntry t; t.path = (d.back() == '/' ? d : d + "/") + n; t.fname = n;
            Meta m; std::string err;
            if (Meta::load(t.path, m, err)) {
                t.ok = true; t.name = m.name; t.total = m.total; t.nfiles = m.files.size(); t.ntr = m.trackers.size();
                t.hash = to_hex(m.infohash, 20);
                for (auto& u : m.trackers) if (u.compare(0, 7, "http://") == 0 || u.compare(0, 6, "udp://") == 0) t.nsupp++;
            } else { t.err = err; t.name = n; }
            bool dup = false;
            for (auto& o : tors_) if (o.ok && o.hash == t.hash) dup = true;
            if (!dup) tors_.push_back(t);
        }
    }
    preview_idx_ = -1;
    if (sel_[2] >= (int)tors_.size()) sel_[2] = std::max(0, (int)tors_.size() - 1);
    dirty_ = true;
}

bool App::confirm(const std::string& key, uint64_t now) {
    if (confirm_key_ == key && now < confirm_until_) { confirm_key_.clear(); return true; }
    confirm_key_ = key; confirm_until_ = now + 4000;
    return false;
}

// ───────── место на карте ─────────
bool App::space_check(const Meta& m, size_t from, uint64_t done_in_first, bool inst, std::string& err) {
    uint64_t sd_need = 0, nand_need = 0;
    for (size_t i = from; i < m.files.size(); i++) {
        const TFile& f = m.files[i];
        if (f.pad) continue;
        uint64_t len = f.len;
        if (i == from) len -= std::min(len, done_in_first);        // эта часть уже на карте
        if (inst && ends_with_ci(f.path, ".nsp")) { (storage_ == 0 ? sd_need : nand_need) += len; }
        else sd_need += len;
    }
    const uint64_t margin = 64ull << 20;
    int64_t sd = pf_->free_space(0), nand = pf_->free_space(1);
    if (sd >= 0 && sd_need && (uint64_t)sd < sd_need + margin) {
        err = "не хватает места на SD: нужно " + human_size((double)sd_need) + ", свободно " + human_size((double)sd);
        return false;
    }
    if (nand >= 0 && nand_need && (uint64_t)nand < nand_need + margin) {
        err = "не хватает места в памяти консоли: нужно " + human_size((double)nand_need) + ", свободно " + human_size((double)nand);
        return false;
    }
    return true;
}

// ───────── задачи ─────────
void App::save_job(Job& j, int status) {
    LibEntry e;
    if (LibEntry* x = lib_.find(j.hash)) e = *x;
    e.hash = j.hash; e.name = j.meta.name; e.total = j.meta.total;
    e.files_done = (uint32_t)j.files_done; e.files_total = (uint32_t)j.meta.files.size();
    e.status = status; e.when = pf_->epoch();
    e.note = status == 2 ? j.err : j.note;
    e.tpath = j.tpath;
    e.cur_off = status == 1 ? 0 : j.cur_off;
    e.inst = status == 1 ? std::string() : j.inst;
    e.mode = j.mode;
    lib_.upsert(e);
    lib_.save();
}

void App::request_add(const TorEntry& t, uint64_t now) {
    if (!t.ok) { toast("Ошибка .torrent: " + t.err, now); return; }
    if (find_job(t.hash)) { tab_ = 1; toast("Уже в загрузках", now); return; }
    if (t.nsupp == 0) {
        toast("В торренте нет http/udp-трекеров (только https/DHT/magnet) — скачать его нельзя", now, 8000);
        return;
    }
    LibEntry* le = lib_.find(t.hash);
    if (le && le->status == 1 && !confirm("re:" + t.hash, now)) {
        toast("Это уже скачано. Нажмите A ещё раз, чтобы скачать заново", now); return;
    }
    dlg_ = true; dlg_sel_ = last_mode_; dlg_t_ = t; dirty_ = true;
}

void App::add_job(const TorEntry& t, int mode, uint64_t now) {
    if (find_job(t.hash)) { tab_ = 1; toast("Уже в загрузках", now); return; }
    auto j = std::make_unique<Job>();
    std::string err;
    if (!Meta::load(t.path, j->meta, err)) { toast("Ошибка .torrent: " + err, now); return; }
    j->tpath = t.path; j->hash = t.hash; j->files_done = 0; j->st = Job::QUEUED; j->mode = mode == 1 ? 1 : 0;
    jobs_.push_back(std::move(j));
    save_job(*jobs_.back(), 0);
    toast(running() ? "Добавлено в очередь" : "Запускаю…", now);
    queue_next(now);
    tab_ = 1;
    sel_[1] = 0;
}

void App::dialog_keys(uint32_t k, uint64_t now) {
    if (k & K_UP) { dlg_sel_ = std::max(0, dlg_sel_ - 1); dirty_ = true; }
    if (k & K_DOWN) { dlg_sel_ = std::min(2, dlg_sel_ + 1); dirty_ = true; }
    if (k & K_B) { dlg_ = false; dirty_ = true; return; }
    if (k & K_A) {
        dlg_ = false; dirty_ = true;
        if (dlg_sel_ <= 1) { last_mode_ = dlg_sel_; add_job(dlg_t_, dlg_sel_, now); }
    }
}

void App::start_job(Job& j, uint64_t now) {
    j.err.clear();
    if (j.files_done >= j.meta.files.size()) { j.st = Job::DONE; return; }
    std::string err;
    const TFile& cf = j.meta.files[j.files_done];
    bool raw = j.mode == 1;
    bool inst = !raw && pf_->can_install();
    bool nsp = inst && ends_with_ci(cf.path, ".nsp");
    // откуда продолжать: NSP — с начала файла (состояние установки решит, что пропустить),
    // обычный файл — с того места, где реально лежат данные на SD
    uint64_t resume_off = 0;
    if (!nsp && j.cur_off > 0 && !cf.pad) {
        uint64_t have = 0;
        std::string d = plain_dest(pf_, j.meta, j.files_done, raw);
        if (FILE* f = fopen(d.c_str(), "rb")) { fseek(f, 0, SEEK_END); long sz = ftell(f); if (sz > 0) have = (uint64_t)sz; fclose(f); }
        resume_off = std::min<uint64_t>(std::min<uint64_t>(j.cur_off, have), cf.len);
    }
    if (!space_check(j.meta, j.files_done, nsp ? j.cur_off : resume_off, inst, err)) {
        j.st = Job::ERROR; j.err = err; save_job(j, 2); return;
    }
    ResumeInfo ri;
    ri.idx = j.files_done; ri.off = resume_off; ri.inst = nsp ? j.inst : std::string();
    j.router = std::make_unique<Router>(pf_, inst, storage_, ri, raw);
    j.swarm = std::make_unique<Swarm>(j.meta, j.router.get(), cf.off + resume_off, MEM_CAP);
    Job* jp = &j;
    j.swarm->set_file_done_cb([this, jp](size_t i) { jp->files_done = i + 1; jp->cur_off = 0; jp->inst.clear(); save_job(*jp, 3); });
    j.st = Job::RUNNING;
    t_stall_start_ = now;
    last_save_ = now;
    dirty_ = true;
}

// Запомнить, докуда дошла загрузка: обычный файл — число записанных байт, NSP — состояние установки
void App::capture(Job& j) {
    if (!j.router) return;
    j.router->flush();
    if (j.router->in_nsp()) { j.cur_off = j.router->inst_bytes(); j.inst = j.router->inst_state(); }
    else { j.cur_off = j.router->file_pos(); j.inst.clear(); }
}

void App::suspend_job(Job& j) {
    capture(j);
    j.swarm.reset();
    if (j.router) {
        j.router->suspend();
        if (j.router->in_nsp() == false && !j.router->inst_state().empty()) j.inst = j.router->inst_state();
        j.note = j.router->summary();
        j.router.reset();
    }
}

void App::cancel_job(Job& j) {
    j.swarm.reset();
    if (j.router) { j.router->abort(); j.router.reset(); }
    if (!j.inst.empty()) pf_->discard_install(storage_, j.inst);
    j.inst.clear();
}

void App::finish_job(Job& j, uint64_t now) {
    j.note = j.router->summary();
    if (j.router->last_info().size()) j.note += (j.note.empty() ? "" : "; ") + std::string("ID ") + j.router->last_info();
    j.swarm.reset(); j.router.reset();
    j.st = Job::DONE;
    j.files_done = j.meta.files.size(); j.cur_off = 0; j.inst.clear();
    save_job(j, 1);
    toast("Готово: " + j.meta.name, now, 8000);
}

void App::queue_next(uint64_t now) {
    if (running()) return;
    for (auto& j : jobs_) if (j->st == Job::QUEUED) { start_job(*j, now); if (j->st == Job::RUNNING) return; }
}

void App::update_awake() {
    bool want = downloading_any();
    if (want != awake_) { awake_ = want; pf_->keep_awake(want); }
}

// ───────── ввод ─────────
std::vector<App::Job*> App::dl_jobs() const {
    std::vector<Job*> v;
    for (auto& j : jobs_) if (j->st != Job::DONE) v.push_back(j.get());
    std::stable_sort(v.begin(), v.end(), [](Job* a, Job* b) { return (a->st == Job::RUNNING) > (b->st == Job::RUNNING); });
    return v;
}

std::vector<LibEntry*> App::done_entries() {
    std::vector<LibEntry*> v;
    for (auto& e : lib_.items) if (e.status == 1) v.push_back(&e);
    std::reverse(v.begin(), v.end());
    return v;
}

int App::list_len() const {
    if (tab_ == 2) return (int)tors_.size();
    if (tab_ == 1) return (int)dl_jobs().size();
    if (tab_ == 3) return 1 + (int)uhist_.size();                       // 0 — «Ввести ссылку», дальше история
    int n = 0; for (auto& e : lib_.items) if (e.status == 1) n++;
    return n;
}

void App::on_a(uint64_t now) {
    if (tab_ == 3) {
        int h = sel_[3] - 1;
        if (h < 0 || h >= (int)uhist_.size()) { open_url_input(now); return; }
        if (fetch_) { url_win_ = true; toast("Уже идёт скачивание по ссылке — дождитесь или отмените его", now); return; }
        std::string u = uhist_[h].url;
        last_url_ = u;
        start_fetch(u, now);                                              // «скачать снова» без клавиатуры
        return;
    }
    if (tab_ == 2) {
        if (tors_.empty()) return;
        request_add(tors_[sel_[2]], now);
    } else if (tab_ == 1) {
        auto v = dl_jobs();
        if (v.empty()) return;
        Job* j = v[std::min<int>(sel_[1], (int)v.size() - 1)];
        if (j->st == Job::RUNNING) { suspend_job(*j); j->st = Job::PAUSED; save_job(*j, 0); toast("Пауза. Продолжится с этого места (A)", now); queue_next(now); }
        else if (j->st == Job::PAUSED || j->st == Job::ERROR) {
            j->st = Job::QUEUED;
            if (Job* r = running()) { (void)r; toast("В очереди", now); }
            else queue_next(now);
        }
    }
}

void App::on_x(uint64_t now) {
    if (tab_ == 3) {
        int h = sel_[3] - 1;
        if (h < 0 || h >= (int)uhist_.size()) return;
        if (!confirm("urlhist:" + std::to_string(h), now)) { toast("Нажмите X ещё раз — убрать ссылку из списка (файл не удаляется)", now); return; }
        uhist_.erase(uhist_.begin() + h);
        save_uhist();
        sel_[3] = std::min(sel_[3], (int)uhist_.size());
        toast("Ссылка убрана из списка", now);
        return;
    }
    if (tab_ == 2) { scan_torrents(); toast("Список торрентов обновлён: " + std::to_string(tors_.size()), now); return; }
    if (tab_ == 1) {
        auto v = dl_jobs();
        if (v.empty()) return;
        Job* j = v[std::min<int>(sel_[1], (int)v.size() - 1)];
        if (!confirm("cancel:" + j->hash, now)) { toast("Нажмите X ещё раз — отменить и убрать из списка", now); return; }
        std::string h = j->hash;
        cancel_job(*j);
        lib_.remove(h); lib_.save();
        jobs_.erase(std::remove_if(jobs_.begin(), jobs_.end(), [&](const std::unique_ptr<Job>& p) { return p->hash == h; }), jobs_.end());
        toast("Убрано из загрузок", now);
        queue_next(now);
    } else {
        auto v = done_entries();
        if (v.empty()) return;
        LibEntry* e = v[std::min<int>(sel_[0], (int)v.size() - 1)];
        if (!confirm("del:" + e->hash, now)) { toast("Нажмите X ещё раз — убрать запись из списка (файлы и игры не удаляются)", now); return; }
        std::string h = e->hash;
        lib_.remove(h); lib_.save();
        jobs_.erase(std::remove_if(jobs_.begin(), jobs_.end(), [&](const std::unique_ptr<Job>& p) { return p->hash == h; }), jobs_.end());
        toast("Запись убрана", now);
    }
}

void App::try_exit(uint64_t now) {
    if (!downloading_any() || confirm("exit", now)) exit_ = true;
    else toast("Идёт загрузка. Нажмите + ещё раз для выхода (прогресс сохранится)", now, 4000);
}

void App::move_sel(int d) {
    int n = list_len();
    sel_[tab_] = std::min(std::max(0, n - 1), std::max(0, sel_[tab_] + d));
    dirty_ = true;
}

void App::handle_keys(uint32_t k, uint64_t now) {
    if (url_win_ && fetch_) {                                         // окно ссылки: управляет только оно
        if (k & K_PLUS) try_exit(now); else url_keys(k, now);
        return;
    }
    if (dlg_) {                                                       // открыто окно выбора: управляет только оно
        if (k & K_PLUS) try_exit(now); else dialog_keys(k, now);
        return;
    }
    if (k & (K_L | K_ZL | K_LEFT)) { tab_ = (tab_ + 3) % 4; dirty_ = true; }
    if (k & (K_R | K_ZR | K_RIGHT)) { tab_ = (tab_ + 1) % 4; dirty_ = true; }
    if (k & K_UP) move_sel(-1);
    if (k & K_DOWN) move_sel(+1);
    if (k & K_A) on_a(now);
    if (k & K_X) on_x(now);
    if (k & K_Y) open_url_input(now);
    if (k & K_MINUS) {
        if (running()) toast("Менять место установки можно между загрузками", now);
        else if (!pf_->can_install()) toast("Установка NSP недоступна", now);
        else { storage_ = storage_ ? 0 : 1; toast(storage_ ? "NSP устанавливаются в память консоли" : "NSP устанавливаются на SD-карту", now); }
    }
    if (k & K_PLUS) try_exit(now);
}

// ───────── скачивание по ссылке ─────────
static std::string one_line(std::string s) {
    for (auto& c : s) if (c == '\t' || c == '\n' || c == '\r') c = ' ';
    return s;
}

void App::load_uhist() {
    uhist_.clear();
    std::vector<uint8_t> raw;
    if (!read_file(pf_->root() + "archive_nintendo/urls.txt", raw, 1 << 20)) return;
    std::string all(raw.begin(), raw.end());
    size_t i = 0;
    while (i < all.size() && uhist_.size() < 40) {
        size_t e = all.find('\n', i);
        if (e == std::string::npos) e = all.size();
        std::string ln = all.substr(i, e - i);
        i = e + 1;
        std::vector<std::string> f;
        size_t a = 0;
        for (;;) { size_t t = ln.find('\t', a); if (t == std::string::npos) { f.push_back(ln.substr(a)); break; } f.push_back(ln.substr(a, t - a)); a = t + 1; }
        if (f.size() < 5 || f[0].empty()) continue;
        UrlHist h; h.url = f[0]; h.name = f[1]; h.size = strtoull(f[2].c_str(), nullptr, 10); h.when = atoll(f[3].c_str()); h.torrent = f[4] == "1";
        uhist_.push_back(h);
    }
}

void App::save_uhist() {
    std::string o;
    for (auto& h : uhist_) o += one_line(h.url) + "\t" + one_line(h.name) + "\t" + std::to_string(h.size) + "\t" + std::to_string(h.when) + "\t" + (h.torrent ? "1" : "0") + "\n";
    write_file(pf_->root() + "archive_nintendo/urls.txt", o);
}

void App::open_url_input(uint64_t now) {
    if (fetch_) { url_win_ = true; dirty_ = true; return; }          // уже идёт — просто показать окно
    std::string out, err;
    bool ok = pf_->text_input("Ссылка на файл (http:// или https://)", last_url_, out, err);
    input_done_ = true;                                               // пока была открыта клавиатура, прошло время
    t_stall_start_ = now_ms();
    now = now_ms();
    dirty_ = true;
    if (!ok) { if (!err.empty()) toast(err, now, 9000); return; }
    size_t a = 0, b = out.size();
    while (a < b && (unsigned char)out[a] <= 0x20) a++;
    while (b > a && (unsigned char)out[b - 1] <= 0x20) b--;
    out = out.substr(a, b - a);
    if (out.empty()) return;
    last_url_ = out;
    start_fetch(out, now);
}

void App::start_fetch(const std::string& url, uint64_t now) {
    (void)now;
    fetch_input_ = url;
    fetch_ = std::make_unique<UrlFetch>(url, ddir(), tdir());
    fetch_->set_free_fn([this]() { return pf_->free_space(0); });
    url_win_ = true; last_fetch_state_ = -1; dirty_ = true; confirm_key_.clear();
}

void App::finish_fetch(uint64_t now) {
    std::string path = fetch_->dest_path(), name = fetch_->name();
    bool tor = fetch_->is_torrent(), visible = url_win_;
    {
        UrlHist h; h.url = fetch_->input_url(); h.name = name; h.size = fetch_->downloaded(); h.when = pf_->epoch(); h.torrent = tor;
        for (size_t i = uhist_.size(); i-- > 0;) if (uhist_[i].url == h.url) uhist_.erase(uhist_.begin() + i);
        uhist_.insert(uhist_.begin(), h);
        if (uhist_.size() > 40) uhist_.resize(40);
        save_uhist();
    }
    fetch_.reset(); url_win_ = false; dirty_ = true;
    if (!tor) { toast("Скачано: " + name + "  →  archive_nintendo/downloads", now, 9000); return; }
    scan_torrents();
    int idx = -1;
    for (size_t i = 0; i < tors_.size(); i++) if (tors_[i].path == path) idx = (int)i;
    if (idx < 0) {                                                    // такой торрент уже был под другим именем файла
        Meta m; std::string e;
        if (Meta::load(path, m, e)) {
            std::string h = to_hex(m.infohash, 20);
            for (size_t i = 0; i < tors_.size(); i++) if (tors_[i].ok && tors_[i].hash == h) idx = (int)i;
        }
    }
    tab_ = 2;
    if (idx < 0) { toast("Торрент сохранён: " + name, now, 9000); return; }
    sel_[2] = idx;
    if (visible) request_add(tors_[idx], now);                       // человек ждёт — сразу спрашиваем, как скачивать
    else toast("Торрент скачан: " + name + " — выберите его и нажмите A", now, 9000);
}

void App::url_keys(uint32_t k, uint64_t now) {
    if (!fetch_) { url_win_ = false; dirty_ = true; return; }
    if (fetch_->failed()) {
        if (k & K_A) { std::string u = fetch_input_; start_fetch(u, now); }
        else if (k & K_B) { fetch_.reset(); url_win_ = false; dirty_ = true; }
    } else if (k & K_B) {
        if (confirm("urlcancel", now)) { fetch_.reset(); url_win_ = false; toast("Скачивание по ссылке отменено", now); }
        else toast("Нажмите B ещё раз — отменить скачивание", now);
        dirty_ = true;
    } else if (k & K_X) {
        url_win_ = false; dirty_ = true;
        toast("Скачивание идёт в фоне. Y — снова открыть окно", now);
    }
}

void App::wake(uint64_t now) {
    screen_off_ = false; pf_->backlight(true); t_stall_start_ = now; dirty_ = true;
}

bool App::frame(uint32_t keys, uint64_t now) {
    // экран выключен: любая кнопка только будит экран и не нажимает ничего другого
    if (screen_off_) {
        if (keys) { wake(now); keys = 0; }
    }
    if (keys) {
        handle_keys(keys, now);
        if (input_done_) { input_done_ = false; now = now_ms(); }    // пока открыта клавиатура, время шло
    }

    if (Job* j = running()) {
        j->swarm->tick(now);
        if (j->swarm->failed()) {
            j->err = j->swarm->error();
            std::string e = j->err;
            suspend_job(*j);                                       // место остановки сохраняем — «A» продолжит
            j->st = Job::ERROR; j->err = e;
            save_job(*j, 2);
            toast("Ошибка: " + e + " — A продолжит с этого места", now, 10000);
            queue_next(now);
        } else if (j->swarm->finished()) {
            finish_job(*j, now);
            queue_next(now);
        }
    }
    if (fetch_) {
        fetch_->tick(now);
        int st = (int)fetch_->state();
        if (st != last_fetch_state_) { last_fetch_state_ = st; dirty_ = true; }
        if (fetch_->finished()) finish_fetch(now);
        else if (fetch_->failed() && !url_win_) {
            if (dlg_) { toast("Ошибка загрузки по ссылке: " + fetch_->error(), now, 9000); fetch_.reset(); }
            else { url_win_ = true; dirty_ = true; }                  // покажем причину
        }
    }
    update_awake();

    // каждые 3 с запоминаем место, докуда дошли: при обрыве/выходе загрузка продолжится отсюда
    if (Job* j = running()) {
        if (now - last_save_ >= 3000) { last_save_ = now; capture(*j); save_job(*j, 3); }
    }

    // нет прогресса stall_limit_ms → гасим экран (консоль не засыпает, загрузка продолжается)
    if (Job* j = running()) {
        uint64_t last = std::max(j->swarm->last_progress(), t_stall_start_);
        if (!screen_off_ && now > last && now - last >= stall_limit_ms) {
            screen_off_ = true; pf_->backlight(false);
        }
    }
    if (now - last_space_ > 2500) {
        last_space_ = now;
        sd_free_ = pf_->free_space(0); sd_total_ = pf_->total_space(0);
        dirty_ = true;
    }
    return !exit_;
}

// ───────── отрисовка ─────────
static std::string pct(uint64_t a, uint64_t b) {
    char s[16]; snprintf(s, sizeof s, "%.1f%%", b ? 100.0 * (double)a / (double)b : 0.0);
    return s;
}

static void bar(Gfx& g, int x, int y, int w, int h, double frac, uint32_t col) {
    frac = std::max(0.0, std::min(1.0, frac));
    g.rrect(x, y, w, h, h / 2, BAR_BG);
    int fw = (int)(w * frac);
    if (fw > 0) g.rrect(x, y, std::max(fw, h), h, h / 2, col);
}

void App::btn(Gfx& g, int& xr, int y, const std::string& label, int key, bool accent) {
    int w = g.text_width(label, F_SMALL) + 30, h = 38, x = xr - w;
    g.rrect(x, y, w, h, 10, accent ? ACC : CARD2);
    g.text_center(x + w / 2, y + 9, label, accent ? C(10, 12, 18) : TXT, F_SMALL);
    add_hit(x, y, w, h, H_KEY, key);
    xr = x - 10;
}

void App::draw_top(Gfx& g) {
    g.rect(0, 0, Gfx::W, TOP_H, PANEL);
    g.text(20, 14, "archive_nintendo", TXT, F_TITLE);
    std::string t = pf_->time_str();
    g.text_right(Gfx::W - 22, 10, t, TXT, F_BIG);
    // кнопка «Скачать по ссылке» (если идёт скачивание в фоне — показывает ход)
    {
        int xr = Gfx::W - 22 - g.text_width(t, F_BIG) - 18;
        std::string lb = "Скачать по ссылке (Y)";
        if (fetch_ && !url_win_) {
            if (fetch_->failed()) lb = "Ссылка: ошибка (Y)";
            else if (fetch_->total()) lb = "Ссылка: " + pct(fetch_->downloaded(), fetch_->total()) + " (Y)";
            else lb = "Ссылка: " + human_size((double)fetch_->downloaded()) + " (Y)";
        }
        btn(g, xr, 13, lb, K_Y, !fetch_);
    }
    // свободное место на SD
    int x = 380, w = 420;
    std::string s;
    if (sd_free_ >= 0 && sd_total_ > 0) s = "SD-карта: свободно " + human_size((double)sd_free_) + " из " + human_size((double)sd_total_);
    else s = "SD-карта: нет данных";
    g.text(x, 8, s, TXT, F_BODY);
    double used = sd_total_ > 0 && sd_free_ >= 0 ? 1.0 - (double)sd_free_ / (double)sd_total_ : 0;
    bar(g, x, 40, w, 10, used, used > 0.92 ? ERRC : used > 0.8 ? WARN : ACC);
}

void App::draw_side(Gfx& g) {
    g.rect(0, TOP_H, SIDE_W, Gfx::H - TOP_H, PANEL);
    int cnt[4];
    cnt[0] = 0; for (auto& e : lib_.items) if (e.status == 1) cnt[0]++;
    cnt[1] = (int)dl_jobs().size();
    cnt[2] = (int)tors_.size();
    cnt[3] = fetch_ ? 1 : 0;                                            // идёт скачивание по ссылке
    for (int i = 0; i < 4; i++) {
        int y = TOP_H + 16 + i * 66;
        bool a = tab_ == i;
        add_hit(10, y, SIDE_W - 20, 56, H_TAB, i);
        if (a) { g.rrect(10, y, SIDE_W - 20, 56, 10, CARD2); g.rect(10, y + 8, 5, 40, ACC); }
        g.text(30, y + 14, TAB_NAMES[i], a ? TXT : DIM, F_BODY);
        if (cnt[i]) {
            std::string c = std::to_string(cnt[i]);
            int cw = g.text_width(c, F_SMALL) + 14;
            g.rrect(SIDE_W - 22 - cw, y + 17, cw, 22, 11, (i == 1 && running()) || (i == 3 && fetching()) ? ACC : BAR_BG);
            g.text_center(SIDE_W - 22 - cw / 2, y + 19, c, a || (i == 1 && running()) || (i == 3 && fetching()) ? C(10, 12, 18) : TXT, F_SMALL);
        }
    }
    int y = Gfx::H - BOT_H - 120;
    g.text(20, y, "Установка игр (NSP):", DIM, F_SMALL);
    bool can = pf_->can_install();
    g.text(20, y + 20, can ? "✓ доступна" : "недоступна", can ? OKC : ERRC, F_BODY);
    g.text(20, y + 54, "Игры ставить в:", DIM, F_SMALL);
    g.text(20, y + 74, storage_ ? "память консоли" : "SD-карта", TXT, F_BODY);
}

static int rows_visible(int h, int rh) { return std::max(1, h / rh); }

void App::draw_torrents(Gfx& g, uint64_t now) {
    (void)now;
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    g.text(x, y, "Торренты: " + std::to_string(tors_.size()) + "   ·   папка sdmc:/archive_nintendo/torrents", DIM, F_SMALL);
    y += 28;
    if (tors_.empty()) {
        g.rrect(x, y + 10, w, 170, 12, CARD);
        g.text(x + 24, y + 30, "Здесь пока пусто", TXT, F_TITLE);
        g.text(x + 24, y + 70, "Положите файлы .torrent в папку", DIM, F_BODY);
        g.text(x + 24, y + 98, "sdmc:/archive_nintendo/torrents/", ACC, F_BODY);
        g.text(x + 24, y + 126, "и нажмите X (обновить список).", DIM, F_BODY);
        return;
    }
    int lw = 600, rh = 58;
    int avail = Gfx::H - BOT_H - y - 8;
    int vis = rows_visible(avail, rh);
    int sel = sel_[2];
    int first = std::max(0, std::min(sel - vis / 2, (int)tors_.size() - vis));
    for (int i = 0; i < vis && first + i < (int)tors_.size(); i++) {
        const TorEntry& t = tors_[first + i];
        int yy = y + i * rh;
        bool a = first + i == sel;
        add_hit(x, yy, lw, rh - 6, H_ROW, first + i);
        g.rrect(x, yy, lw, rh - 6, 10, a ? CARD2 : CARD);
        if (a) g.frame(x, yy, lw, rh - 6, 2, ACC);
        g.text(x + 14, yy + 5, g.fit(t.ok ? t.name : t.fname, lw - 28, F_BODY), t.ok ? TXT : ERRC, F_BODY);
        std::string sub;
        if (t.ok) sub = human_size((double)t.total) + "  ·  файлов: " + std::to_string(t.nfiles);
        else sub = t.err;
        Job* j = t.ok ? find_job(t.hash) : nullptr;
        LibEntry* le = t.ok ? lib_.find(t.hash) : nullptr;
        std::string tag; uint32_t tc = DIM;
        if (j && j->st != Job::DONE) { tag = "в загрузках"; tc = ACC; }
        else if (le && le->status == 1) { tag = "✓ скачано"; tc = OKC; }
        else if (t.ok && t.nsupp == 0) { tag = "нет http/udp-трекеров"; tc = ERRC; }
        g.text(x + 14, yy + 31, g.fit(sub, lw - 200, F_SMALL), DIM, F_SMALL);
        if (!tag.empty()) g.text_right(x + lw - 14, yy + 31, tag, tc, F_SMALL);
    }
    // предпросмотр выбранного
    const TorEntry& t = tors_[sel];
    int px = x + lw + 16, pw = w - lw - 16;
    g.rrect(px, y, pw, Gfx::H - BOT_H - y - 8, 12, CARD);
    if (!t.ok) { g.text(px + 16, y + 14, "Файл повреждён", ERRC, F_BODY); return; }
    if (preview_idx_ != sel) {
        std::string e; preview_idx_ = sel;
        if (!Meta::load(t.path, preview_, e)) preview_.files.clear();
    }
    g.text(px + 16, y + 12, g.fit(t.name, pw - 32, F_BODY), TXT, F_BODY);
    char b[160];
    snprintf(b, sizeof b, "%s · кусок %s · трекеров: %d", human_size((double)preview_.total).c_str(), human_size((double)preview_.plen).c_str(), (int)preview_.trackers.size());
    g.text(px + 16, y + 42, g.fit(b, pw - 32, F_SMALL), DIM, F_SMALL);
    int fy = y + 72;
    g.text(px + 16, fy, "Куда пойдут файлы:", DIM, F_SMALL);
    fy += 24;
    int pm = dlg_ ? std::min(dlg_sel_, 1) : last_mode_;               // в окне выбора предпросмотр показывает выбранный вариант
    bool inst = pm == 0 && pf_->can_install(), raw = pm == 1;
    int maxrows = (Gfx::H - BOT_H - 20 - fy) / 40;
    for (size_t i = 0; i < preview_.files.size() && (int)i < maxrows; i++) {
        if (preview_.files[i].pad) continue;
        g.text(px + 16, fy, g.fit(preview_.files[i].path, pw - 32, F_SMALL), TXT, F_SMALL);
        g.text(px + 16, fy + 17, "→ " + route_label(preview_, i, inst, raw) + "   " + human_size((double)preview_.files[i].len), ACC, F_SMALL);
        fy += 40;
    }
    if ((int)preview_.files.size() > maxrows) g.text(px + 16, fy, "… и ещё " + std::to_string(preview_.files.size() - maxrows), DIM, F_SMALL);
}

// Окно выбора поверх списка торрентов: справа остаётся предпросмотр и показывает, куда пойдёт каждый файл
void App::draw_dialog(Gfx& g) {
    if (!dlg_) return;
    hits_.clear();                                                     // окно модальное: нажимается только оно
    int x = CX, y = TOP_H + 42, w = 600, h = Gfx::H - BOT_H - y - 8;
    g.rrect(x, y, w, h, 14, PANEL);
    g.frame(x, y, w, h, 2, ACC);
    g.text(x + 20, y + 14, "Как поступить с торрентом?", TXT, F_TITLE);
    g.text(x + 20, y + 50, g.fit(dlg_t_.name, w - 40, F_BODY), DIM, F_BODY);
    bool can = pf_->can_install();
    struct Opt { const char* title; std::string l1, l2; } opt[2] = {
        {"Автоустановка",
         can ? std::string("Игры .nsp — установить на ") + (storage_ ? "память консоли" : "SD-карту") : std::string("Игры .nsp — сохранить файлом (установка недоступна)"),
         "Порты и homebrew — в switch/…, прочее — в downloads"},
        {"Положить в папку",
         "Всё как есть: без установки и без распаковки",
         "→ sdmc:/archive_nintendo/downloads/"}};
    int yy = y + 92;
    for (int i = 0; i < 2; i++) {
        bool a = dlg_sel_ == i;
        add_hit(x + 16, yy, w - 32, 104, H_DLG, i);
        g.rrect(x + 16, yy, w - 32, 104, 12, a ? CARD2 : CARD);
        if (a) g.frame(x + 16, yy, w - 32, 104, 2, ACC);
        g.text(x + 36, yy + 10, std::string(a ? "▶ " : "   ") + opt[i].title, a ? TXT : DIM, F_TITLE);
        g.text(x + 36, yy + 48, g.fit(opt[i].l1, w - 72, F_SMALL), a ? TXT : DIM, F_SMALL);
        g.text(x + 36, yy + 72, g.fit(opt[i].l2, w - 72, F_SMALL), DIM, F_SMALL);
        yy += 116;
    }
    bool a = dlg_sel_ == 2;
    add_hit(x + 16, yy, w - 32, 50, H_DLG, 2);
    g.rrect(x + 16, yy, w - 32, 50, 12, a ? CARD2 : CARD);
    if (a) g.frame(x + 16, yy, w - 32, 50, 2, ACC);
    g.text(x + 36, yy + 10, std::string(a ? "▶ " : "   ") + "Отмена", a ? TXT : DIM, F_BODY);
}

void App::draw_card(Gfx& g, Job& j, int x, int y, int w, uint64_t now) {
    Swarm* s = j.swarm.get();
    Router* r = j.router.get();
    g.rrect(x, y, w, CARD_H, 14, CARD);
    const char* ml = j.mode == 1 ? "в папку" : "автоустановка";
    g.text_right(x + w - 18, y + 18, ml, ACC, F_SMALL);
    g.text(x + 18, y + 12, g.fit(j.meta.name, w - 36 - g.text_width(ml, F_SMALL) - 16, F_TITLE), TXT, F_TITLE);
    uint64_t total = j.meta.total;
    uint64_t dl = s->downloaded_abs(), cons = s->consumed_bytes();
    double sp = s->speed();
    std::string line;
    if (r->installing()) line = "Установка NSP: " + j.meta.files[std::min(s->cur_file(), j.meta.files.size() - 1)].path;
    else line = "Файл " + std::to_string(std::min(s->cur_file() + 1, j.meta.files.size())) + " из " + std::to_string(j.meta.files.size()) + ": " + r->current_name();
    g.text(x + 18, y + 50, g.fit(line, w - 36, F_SMALL), DIM, F_SMALL);
    int bw = w - 36;
    // скачано
    g.text(x + 18, y + 76, "Скачано", TXT, F_SMALL);
    g.text_right(x + w - 18, y + 76, human_size((double)dl) + " / " + human_size((double)total) + "   " + pct(dl, total), TXT, F_SMALL);
    bar(g, x + 18, y + 98, bw, 14, total ? (double)dl / (double)total : 0, ACC);
    // установлено / записано
    bool nsp = r->installing() || r->n_installed() > 0;
    g.text(x + 18, y + 120, nsp ? "Установлено / записано" : "Записано на SD", TXT, F_SMALL);
    g.text_right(x + w - 18, y + 120, human_size((double)cons) + "   " + pct(cons, total), TXT, F_SMALL);
    bar(g, x + 18, y + 142, bw, 14, total ? (double)cons / (double)total : 0, OKC);
    // скорость / ETA
    int64_t eta = sp > 1024 ? (int64_t)((double)(total - std::min(total, dl)) / sp) : -1;
    g.text(x + 18, y + 168, "Скорость", DIM, F_SMALL);
    g.text(x + 18, y + 186, human_speed(sp), TXT, F_BODY);
    g.text(x + 230, y + 168, "Осталось", DIM, F_SMALL);
    g.text(x + 230, y + 186, eta >= 0 ? human_time(eta) : "—", TXT, F_BODY);
    g.text(x + 420, y + 168, "Буфер в памяти", DIM, F_SMALL);
    g.text(x + 420, y + 186, human_size((double)s->buffered_bytes()), TXT, F_BODY);
    g.text(x + 640, y + 168, "Источник", DIM, F_SMALL);
    g.text(x + 640, y + 186, g.fit(s->status_text(), w - 660, F_BODY), TXT, F_BODY);
    // что делают трекеры и пиры — по этим строкам видно, почему нет скорости
    bool no_peers = s->peers_active() == 0;
    g.text(x + 18, y + 214, g.fit(s->diag_trackers(), w - 36, F_SMALL), no_peers ? WARN : DIM, F_SMALL);
    g.text(x + 18, y + 234, g.fit(s->diag_peers(), w - 36, F_SMALL), no_peers ? WARN : DIM, F_SMALL);
    // предупреждение о простое
    uint64_t last = std::max(s->last_progress(), t_stall_start_);
    if (now > last && now - last > 20000) {
        uint64_t idle = now - last;
        int64_t left = (int64_t)(stall_limit_ms > idle ? (stall_limit_ms - idle) / 1000 : 0);
        char b[160];
        snprintf(b, sizeof b, "Нет данных уже %s · экран станет чёрным через %s (любая кнопка или касание вернёт)", human_time((int64_t)(idle / 1000)).c_str(), human_time(left).c_str());
        g.text(x + 18, y + 256, g.fit(b, w - 36, F_SMALL), WARN, F_SMALL);
    } else {
        g.text(x + 18, y + 256, "Экран не гаснет, пока идёт загрузка. Данные не копятся на SD — установленное сразу освобождается.", DIM, F_SMALL);
    }
}

void App::draw_downloads(Gfx& g, uint64_t now) {
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    auto v = dl_jobs();
    if (v.empty()) {
        g.rrect(x, y, w, 120, 12, CARD);
        g.text(x + 24, y + 22, "Нет активных загрузок", TXT, F_TITLE);
        g.text(x + 24, y + 62, "Откройте вкладку «Торренты» и нажмите A на выбранном торренте.", DIM, F_BODY);
        return;
    }
    int sel = std::min(sel_[1], (int)v.size() - 1);
    int yy = y;
    for (size_t i = 0; i < v.size(); i++) {
        Job& j = *v[i];
        bool a = (int)i == sel;
        if (j.st == Job::RUNNING && j.swarm) {
            add_hit(x, yy, w, CARD_H, H_ROW, (int)i);
            draw_card(g, j, x, yy, w, now);
            if (a) g.frame(x, yy, w, CARD_H, 2, ACC);
            yy += CARD_H + 12;
        } else {
            if (yy + 64 > Gfx::H - BOT_H) break;
            add_hit(x, yy, w, 58, H_ROW, (int)i);
            g.rrect(x, yy, w, 58, 10, a ? CARD2 : CARD);
            if (a) g.frame(x, yy, w, 58, 2, ACC);
            g.text(x + 14, yy + 6, g.fit(j.meta.name, w - 300, F_BODY), TXT, F_BODY);
            std::string st; uint32_t sc = DIM;
            switch (j.st) {
            case Job::QUEUED: st = "в очереди"; sc = ACC; break;
            case Job::PAUSED: st = "приостановлено"; sc = WARN; break;
            case Job::ERROR: st = "ошибка"; sc = ERRC; break;
            default: break;
            }
            g.text_right(x + w - 14, yy + 6, st, sc, F_BODY);
            uint64_t done = j.files_done < j.meta.files.size() ? j.meta.files[j.files_done].off + std::min(j.cur_off, j.meta.files[j.files_done].len) : j.meta.total;
            std::string sub = "Скачано " + human_size((double)done) + " из " + human_size((double)j.meta.total) + " (" + pct(done, j.meta.total) + ")  ·  файлов: " + std::to_string(j.files_done) + " из " + std::to_string(j.meta.files.size());
            sub += j.mode == 1 ? "  ·  в папку" : "  ·  автоустановка";
            if (j.st == Job::PAUSED || j.st == Job::ERROR) sub += "  ·  A — продолжить";
            if (j.st == Job::ERROR) sub = j.err;
            g.text(x + 14, yy + 34, g.fit(sub, w - 28, F_SMALL), j.st == Job::ERROR ? ERRC : DIM, F_SMALL);
            yy += 64;
        }
    }
}

void App::draw_installed(Gfx& g) {
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    auto v = const_cast<App*>(this)->done_entries();
    g.text(x, y, "Скачано и установлено через archive_nintendo: " + std::to_string(v.size()), DIM, F_SMALL);
    y += 28;
    if (v.empty()) {
        g.rrect(x, y, w, 100, 12, CARD);
        g.text(x + 24, y + 28, "Пока ничего нет — готовые загрузки появятся здесь.", DIM, F_BODY);
        return;
    }
    int rh = 70, vis = rows_visible(Gfx::H - BOT_H - y - 8, rh), sel = std::min(sel_[0], (int)v.size() - 1);
    int first = std::max(0, std::min(sel - vis / 2, (int)v.size() - vis));
    for (int i = 0; i < vis && first + i < (int)v.size(); i++) {
        LibEntry& e = *v[first + i];
        int yy = y + i * rh;
        bool a = first + i == sel;
        add_hit(x, yy, w, rh - 6, H_ROW, first + i);
        g.rrect(x, yy, w, rh - 6, 10, a ? CARD2 : CARD);
        if (a) g.frame(x, yy, w, rh - 6, 2, ACC);
        g.text(x + 14, yy + 6, g.fit("✓ " + e.name, w - 220, F_BODY), TXT, F_BODY);
        g.text_right(x + w - 14, yy + 6, human_size((double)e.total), TXT, F_BODY);
        std::string sub = pf_->date_str(e.when);
        if (!e.note.empty()) sub += "  ·  " + e.note;
        g.text(x + 14, yy + 36, g.fit(sub, w - 28, F_SMALL), DIM, F_SMALL);
    }
}

void App::draw_bottom(Gfx& g, uint64_t now) {
    (void)now;
    int y = Gfx::H - BOT_H;
    g.rect(0, y, Gfx::W, BOT_H, PANEL);
    std::string h = "L/R вкладки   ↑↓ выбор   Y скачать по ссылке";
    int xr = Gfx::W - 16, by = y + (BOT_H - 38) / 2;
    if (dlg_ || url_win_) {
        h = dlg_ ? "↑↓ выбор   A подтвердить   B отмена" : "";
    } else {
        btn(g, xr, by, "Выход (+)", K_PLUS);
        if (tab_ == 2) {
            if (pf_->can_install()) btn(g, xr, by, storage_ ? "NSP: память (−)" : "NSP: SD (−)", K_MINUS);
            btn(g, xr, by, "Обновить (X)", K_X);
            btn(g, xr, by, "Скачать (A)", K_A, true);
        } else if (tab_ == 3) {
            if (sel_[3] > 0) btn(g, xr, by, "Убрать (X)", K_X);
            btn(g, xr, by, sel_[3] > 0 ? "Скачать снова (A)" : "Ввести ссылку (A)", K_A, true);
        } else if (tab_ == 1) {
            auto v = dl_jobs();
            bool run = !v.empty() && v[std::min<int>(sel_[1], (int)v.size() - 1)]->st == Job::RUNNING;
            btn(g, xr, by, "Отменить (X)", K_X);
            btn(g, xr, by, run ? "Пауза (A)" : "Продолжить (A)", K_A, true);
        } else {
            btn(g, xr, by, "Убрать (X)", K_X);
        }
    }
    g.text(20, y + (BOT_H - 22) / 2, g.fit(h, std::max(100, xr - 40), F_SMALL), DIM, F_SMALL);
}

void App::draw_toast(Gfx& g, uint64_t now) {
    if (now >= toast_until_ || toast_.empty()) return;
    int y = Gfx::H - BOT_H;
    int tw = std::min(Gfx::W - 300, g.text_width(toast_, F_BODY) + 40);
    int tx = SIDE_W + (Gfx::W - SIDE_W - tw) / 2;
    g.rrect(tx, y - 54, tw, 42, 12, C(60, 70, 100));
    g.text(tx + 20, y - 46, g.fit(toast_, tw - 40, F_BODY), TXT, F_BODY);
}

// Что за файл — по расширению и типу от сервера (чтобы было понятно, что именно скачивается)
static std::string kind_label(const std::string& name, const std::string& ctype) {
    static const struct { const char* ext; const char* txt; } K[] = {
        {".torrent", "торрент — дальше спросит, как скачивать"}, {".nsp", "установочный файл игры (NSP)"},
        {".nsz", "сжатая игра (NSZ), не устанавливается"}, {".xci", "образ картриджа (XCI)"},
        {".nro", "программа для Switch (.nro)"}, {".zip", "архив ZIP"}, {".7z", "архив 7z"}, {".rar", "архив RAR"},
        {".png", "картинка"}, {".jpg", "картинка"}, {".jpeg", "картинка"}, {".gif", "картинка"}, {".webp", "картинка"},
        {".mp4", "видео"}, {".mkv", "видео"}, {".avi", "видео"}, {".mp3", "аудио"}, {".flac", "аудио"}, {".ogg", "аудио"}, {".wav", "аудио"},
        {".pdf", "документ PDF"}, {".txt", "текст"}, {".json", "данные JSON"}, {".iso", "образ диска"},
        {".html", "веб-страница, а не файл"}, {".htm", "веб-страница, а не файл"},
    };
    for (auto& k : K) if (ends_with_ci(name, k.ext)) return k.txt;
    if (ctype.compare(0, 9, "text/html") == 0) return "веб-страница, а не файл";
    if (!ctype.empty() && ctype.find("octet-stream") == std::string::npos) return ctype.substr(0, ctype.find(';'));
    return "файл (тип не указан)";
}

// Перенос по словам (до maxlines строк; последняя обрезается «…»)
static std::vector<std::string> wrap(Gfx& g, const std::string& s, int maxw, FontId f, int maxlines) {
    std::vector<std::string> out;
    size_t i = 0;
    while (i < s.size() && (int)out.size() < maxlines) {
        while (i < s.size() && s[i] == ' ') i++;
        if (i >= s.size()) break;
        if ((int)out.size() == maxlines - 1) { out.push_back(g.fit(s.substr(i), maxw, f)); break; }
        size_t j = i, last_sp = std::string::npos;
        while (j < s.size()) {
            size_t k = j + 1;
            while (k < s.size() && ((unsigned char)s[k] & 0xC0) == 0x80) k++;
            if (g.text_width(s.substr(i, k - i), f) > maxw) break;
            if (s[j] == ' ') last_sp = j;
            j = k;
        }
        size_t end = j;
        if (j < s.size() && last_sp != std::string::npos && last_sp > i) end = last_sp;
        if (end == i) { end = i + 1; while (end < s.size() && ((unsigned char)s[end] & 0xC0) == 0x80) end++; }
        out.push_back(s.substr(i, end - i));
        i = end;
    }
    return out;
}

void App::draw_url(Gfx& g, uint64_t now) {
    hits_.clear();                                                     // окно модальное: нажимается только оно
    if (!fetch_) return;
    UrlFetch& f = *fetch_;
    int w = 800, h = 380, x = (Gfx::W - w) / 2, y = 150;
    g.rrect(x, y, w, h, 14, PANEL);
    g.frame(x, y, w, h, 2, f.failed() ? ERRC : ACC);
    g.text(x + 24, y + 16, "Скачать по ссылке", TXT, F_TITLE);
    g.text(x + 24, y + 58, g.fit(f.input_url(), w - 48, F_SMALL), DIM, F_SMALL);
    int xr = x + w - 24, by = y + h - 62;
    if (f.failed()) {
        g.text(x + 24, y + 96, "Не удалось скачать", ERRC, F_BODY);
        int ly = y + 134;
        for (auto& ln : wrap(g, f.error(), w - 48, F_BODY, 4)) { g.text(x + 24, ly, ln, TXT, F_BODY); ly += 30; }
        btn(g, xr, by, "Закрыть (B)", K_B);
        btn(g, xr, by, "Повторить (A)", K_A, true);
        return;
    }
    g.text(x + 24, y + 96, g.fit(f.status_text(), w - 48, F_BODY), TXT, F_BODY);
    if (!f.name().empty()) {
        g.text(x + 24, y + 134, g.fit("Файл: " + f.name(), w - 260, F_SMALL), TXT, F_SMALL);
        g.text_right(x + w - 24, y + 134, f.is_torrent() ? "→ папка торрентов" : "→ archive_nintendo/downloads", ACC, F_SMALL);
    }
    if (!f.name().empty()) {
        std::string info = "Сервер: " + f.host() + "   ·   Это: " + kind_label(f.name(), f.content_type());
        if (f.redirects() > 0) info += "   ·   перенаправлений: " + std::to_string(f.redirects());
        g.text(x + 24, y + 160, g.fit(info, w - 48, F_SMALL), DIM, F_SMALL);
    }
    int by2 = y + 184, bw = w - 48;
    uint64_t total = f.total(), dl = f.downloaded();
    if (total) bar(g, x + 24, by2, bw, 18, (double)dl / (double)total, ACC);
    else {                                                              // размер неизвестен: бегущая полоска
        g.rrect(x + 24, by2, bw, 18, 9, BAR_BG);
        if (f.state() == UrlFetch::S_BODY) { int sw = 160, px = (int)((now / 6) % (uint64_t)(bw - sw)); g.rrect(x + 24 + px, by2, sw, 18, 9, ACC); }
    }
    std::string l = human_size((double)dl);
    if (total) l += " из " + human_size((double)total) + "   " + pct(dl, total);
    g.text(x + 24, y + 214, l, TXT, F_BODY);
    if (f.state() == UrlFetch::S_BODY) {
        double sp = f.speed();
        std::string r = human_speed(sp);
        if (total && sp > 1024) r += "  ·  осталось " + human_time((int64_t)((double)(total - std::min(total, dl)) / sp));
        g.text_right(x + w - 24, y + 214, r, TXT, F_BODY);
    }
    bool sure = confirm_key_ == "urlcancel" && now < confirm_until_;
    btn(g, xr, by, sure ? "Точно отменить? (B)" : "Отмена (B)", K_B);
    btn(g, xr, by, "Свернуть (X)", K_X, true);
}

void App::draw_urltab(Gfx& g, uint64_t now) {
    int x = CX, y = TOP_H + 14, w = Gfx::W - x - 16;
    g.text(x, y, "Скачать файл по ссылке (http:// или https://)   ·   последних ссылок: " + std::to_string(uhist_.size()), DIM, F_SMALL);
    y += 28;
    // строка 0: ввод
    bool a0 = sel_[3] == 0;
    add_hit(x, y, w, 84, H_ROW, 0);
    g.rrect(x, y, w, 84, 12, a0 ? CARD2 : CARD);
    if (a0) g.frame(x, y, w, 84, 2, ACC);
    g.text(x + 18, y + 14, "Ввести ссылку…", TXT, F_BODY);
    g.text(x + 18, y + 48, g.fit("Откроется клавиатура консоли. Файл попадёт в archive_nintendo/downloads, а .torrent — в список торрентов.", w - 36, F_SMALL), DIM, F_SMALL);
    y += 94;
    // что скачивается сейчас
    if (fetch_) {
        UrlFetch& f = *fetch_;
        add_hit(x, y, w, 112, H_KEY, K_Y);
        g.rrect(x, y, w, 112, 12, CARD);
        if (f.failed()) {
            g.frame(x, y, w, 112, 2, ERRC);
            g.text(x + 18, y + 12, "Не удалось скачать", ERRC, F_BODY);
            g.text(x + 18, y + 46, g.fit(f.error(), w - 36, F_SMALL), TXT, F_SMALL);
            g.text(x + 18, y + 76, "Нажмите, чтобы открыть окно: повторить или закрыть", DIM, F_SMALL);
        } else {
            std::string head = f.name().empty() ? f.status_text() : f.name();
            g.text(x + 18, y + 10, g.fit(head, w - 260, F_BODY), TXT, F_BODY);
            if (f.state() == UrlFetch::S_BODY) g.text_right(x + w - 18, y + 12, human_speed(f.speed()), TXT, F_SMALL);
            uint64_t total = f.total(), dl = f.downloaded();
            if (total) bar(g, x + 18, y + 50, w - 36, 14, (double)dl / (double)total, ACC);
            else {
                g.rrect(x + 18, y + 50, w - 36, 14, 7, BAR_BG);
                if (f.state() == UrlFetch::S_BODY) { int sw = 140, bw = w - 36; g.rrect(x + 18 + (int)((now / 6) % (uint64_t)(bw - sw)), y + 50, sw, 14, 7, ACC); }
            }
            std::string l = human_size((double)dl);
            if (total) l += " из " + human_size((double)total) + "   " + pct(dl, total);
            g.text(x + 18, y + 74, l, DIM, F_SMALL);
            if (!f.name().empty()) g.text_right(x + w - 18, y + 74, g.fit(kind_label(f.name(), f.content_type()), w / 2, F_SMALL), DIM, F_SMALL);
        }
        y += 122;
    }
    // история
    if (uhist_.empty()) {
        if (!fetch_) {
            g.rrect(x, y, w, 70, 12, CARD);
            g.text(x + 18, y + 20, "Скачанные по ссылке файлы появятся здесь — можно скачать снова одним нажатием.", DIM, F_SMALL);
        }
        return;
    }
    int rh = 64, vis = rows_visible(Gfx::H - BOT_H - y - 8, rh);
    int hsel = std::max(0, sel_[3] - 1), n = (int)uhist_.size();
    int first = std::max(0, std::min(hsel - vis / 2, n - vis));
    for (int i = 0; i < vis && first + i < n; i++) {
        UrlHist& h = uhist_[first + i];
        int yy = y + i * rh;
        bool a = sel_[3] == first + i + 1;
        add_hit(x, yy, w, rh - 6, H_ROW, first + i + 1);
        g.rrect(x, yy, w, rh - 6, 10, a ? CARD2 : CARD);
        if (a) g.frame(x, yy, w, rh - 6, 2, ACC);
        g.text(x + 14, yy + 5, g.fit(h.name, w - 260, F_BODY), TXT, F_BODY);
        g.text_right(x + w - 14, yy + 5, human_size((double)h.size) + "  ·  " + pf_->date_str(h.when), DIM, F_SMALL);
        g.text(x + 14, yy + 32, g.fit(h.url, w - 28 - 200, F_SMALL), DIM, F_SMALL);
        g.text_right(x + w - 14, yy + 32, h.torrent ? "→ торренты" : "→ downloads", ACC, F_SMALL);
    }
}

// ───────── касания ─────────
void App::tap(int x, int y, uint64_t now) {
    const Hit* hit = nullptr;
    for (size_t i = hits_.size(); i-- > 0;) {                          // сверху вниз: что нарисовано позже, то и нажимается
        const Hit& c = hits_[i];
        if (x >= c.x && x < c.x + c.w && y >= c.y && y < c.y + c.h) { hit = &c; break; }
    }
    if (!hit) return;
    int kind = hit->kind, arg = hit->arg;
    dirty_ = true;
    switch (kind) {
    case H_KEY: handle_keys((uint32_t)arg, now); if (input_done_) input_done_ = false; break;
    case H_TAB: tab_ = arg; break;
    case H_ROW:
        if (arg >= list_len()) break;
        if (tab_ == 3 && arg == 0) { sel_[3] = 0; on_a(now); }         // «Ввести ссылку» нажимается сразу
        else if ((tab_ == 2 || tab_ == 3) && sel_[tab_] == arg) on_a(now);   // повторное касание выбранной строки — как A
        else sel_[tab_] = arg;
        break;
    case H_DLG: dlg_sel_ = arg; dialog_keys(K_A, now); break;
    }
}

void App::touch(int x, int y, int phase, uint64_t now) {
    if (phase == 0) {
        if (screen_off_) { wake(now); ignore_touch_ = true; touching_ = true; return; }   // касание только будит экран
        ignore_touch_ = false; touching_ = true; dragging_ = false;
        tx0_ = tx_ = x; ty0_ = ty_ = y; drag_acc_ = 0;
        return;
    }
    if (!touching_) return;
    if (ignore_touch_) { if (phase == 2) { touching_ = false; ignore_touch_ = false; } return; }
    if (phase == 1) {
        if (!dragging_ && (abs(x - tx0_) > 24 || abs(y - ty0_) > 24)) dragging_ = true;
        if (dragging_ && !dlg_ && !url_win_ && x > SIDE_W && y > TOP_H && y < Gfx::H - BOT_H) {
            // палец тянет список: вверх — выбор вниз, и наоборот
            const int step = 56;
            drag_acc_ += y - ty_;
            while (drag_acc_ <= -step) { drag_acc_ += step; move_sel(+1); }
            while (drag_acc_ >= step) { drag_acc_ -= step; move_sel(-1); }
        }
        tx_ = x; ty_ = y;
        return;
    }
    touching_ = false;                                                 // отпустили
    if (!dragging_) tap(tx0_, ty0_, now);
}

void App::draw(Gfx& g, uint64_t now) {
    last_draw_ = now; dirty_ = false;
    hits_.clear();
    if (screen_off_) { g.clear(C(0, 0, 0)); return; }
    g.clear(BG);
    draw_side(g);
    if (tab_ == 3) draw_urltab(g, now);
    else if (tab_ == 2) draw_torrents(g, now);
    else if (tab_ == 1) draw_downloads(g, now);
    else draw_installed(g);
    draw_top(g);
    draw_bottom(g, now);
    if (url_win_ && fetch_) draw_url(g, now);
    else if (dlg_) draw_dialog(g);
    draw_toast(g, now);
}
