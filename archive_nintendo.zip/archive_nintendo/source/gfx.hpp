#pragma once
#include <stdint.h>
#include <string>
#include <vector>

enum FontId { F_SMALL = 0, F_BODY, F_TITLE, F_BIG };

// Цвет в памяти: R,G,B,A (как RGBA8888 у Switch)
static inline uint32_t C(int r, int g, int b, int a = 255) { return (uint32_t)r | (uint32_t)g << 8 | (uint32_t)b << 16 | (uint32_t)a << 24; }

struct Gfx {
    static constexpr int W = 1280, H = 720;
    std::vector<uint32_t> px;
    Gfx() : px((size_t)W * H, 0) {}
    void clear(uint32_t c);
    void rect(int x, int y, int w, int h, uint32_t c);
    void rrect(int x, int y, int w, int h, int r, uint32_t c);
    void frame(int x, int y, int w, int h, int t, uint32_t c);
    void text(int x, int y, const std::string& s, uint32_t c, FontId f = F_BODY);
    int text_width(const std::string& s, FontId f = F_BODY);
    void text_right(int xr, int y, const std::string& s, uint32_t c, FontId f = F_BODY) { text(xr - text_width(s, f), y, s, c, f); }
    void text_center(int xc, int y, const std::string& s, uint32_t c, FontId f = F_BODY) { text(xc - text_width(s, f) / 2, y, s, c, f); }
    std::string fit(const std::string& s, int maxw, FontId f = F_BODY);   // обрезает с «…»
    int line_height(FontId f);
    bool save_ppm(const std::string& path) const;
};
