#include "nsp_install.hpp"
#include "util.hpp"
#include <string.h>

static uint16_t r16(const uint8_t* p) { uint16_t v; memcpy(&v, p, 2); return v; }
static uint32_t r32(const uint8_t* p) { uint32_t v; memcpy(&v, p, 4); return v; }
static uint64_t r64(const uint8_t* p) { uint64_t v; memcpy(&v, p, 8); return v; }

bool build_meta_record(const std::vector<uint8_t>& c, const uint8_t meta_cid[16], uint64_t meta_size,
                       uint64_t& id, uint32_t& ver, uint8_t& type, uint64_t& app_id,
                       std::vector<uint8_t>& rec, std::vector<std::string>& cids, std::string& err) {
    const size_t n = c.size();
    if (n < 0x20) { err = "CNMT слишком короткий"; return false; }
    const uint8_t* b = c.data();
    id = r64(b); ver = r32(b + 8); type = b[0x0C];
    uint16_t ext = r16(b + 0x0E), cc = r16(b + 0x10), mc = r16(b + 0x12);
    uint8_t attrs = b[0x14];
    size_t infos = 0x20 + (size_t)ext;
    size_t tail = infos + (size_t)cc * 0x38;
    if (tail > n) { err = "CNMT повреждён"; return false; }
    if (type < 0x80) { err = "системные компоненты не поддерживаются (ставятся только игры, обновления и DLC)"; return false; }
    if (type == 0x80) app_id = id;
    else if (type == 0x81 || type == 0x82) { if (ext < 8) { err = "CNMT без application id"; return false; } app_id = r64(b + 0x20); }
    else { err = "неподдерживаемый тип контента 0x" + to_hex(&type, 1); return false; }

    rec.clear();
    // NcmContentMetaHeader
    uint16_t ext16 = ext, cnt16 = (uint16_t)(cc + 1);
    rec.insert(rec.end(), (uint8_t*)&ext16, (uint8_t*)&ext16 + 2);
    rec.insert(rec.end(), (uint8_t*)&cnt16, (uint8_t*)&cnt16 + 2);
    rec.insert(rec.end(), (uint8_t*)&mc, (uint8_t*)&mc + 2);
    rec.push_back(attrs); rec.push_back(0);
    rec.insert(rec.end(), b + 0x20, b + 0x20 + ext);
    // сам CNMT-NCA как первая запись (тип Meta = 0)
    uint8_t ci[0x18]; memset(ci, 0, sizeof ci);
    memcpy(ci, meta_cid, 16);
    uint32_t lo = (uint32_t)(meta_size & 0xFFFFFFFFu); memcpy(ci + 16, &lo, 4);
    ci[20] = (uint8_t)(meta_size >> 32); ci[21] = 0; ci[22] = 0; ci[23] = 0;
    rec.insert(rec.end(), ci, ci + 0x18);
    cids.clear();
    for (uint16_t i = 0; i < cc; i++) {
        const uint8_t* e = b + infos + (size_t)i * 0x38;
        rec.insert(rec.end(), e + 0x20, e + 0x38);                  // NcmContentInfo (без sha256)
        cids.push_back(to_hex(e + 0x20, 16));
    }
    size_t tail_end = n >= tail + 0x20 ? n - 0x20 : n;             // последние 32 байта — дайджест
    if (tail_end > tail) rec.insert(rec.end(), b + tail, b + tail_end);
    return true;
}

// ───────────────────────── NspInstaller ─────────────────────────
// Формат состояния: v1|<hex cid частично записанного NCA>|<hex placeholder>|<записано байт>|<cid1,cid2,...>
NspInstaller::NspInstaller(NspBackend* be, const std::string& resume) : be_(be), pfs_(this) {
    memset(cur_cid_, 0, sizeof cur_cid_);
    if (!resume.empty()) parse_resume(resume);
}

NspInstaller::~NspInstaller() { if (!done_) abort(); delete be_; }

static std::vector<std::string> split_s(const std::string& s, char d) {
    std::vector<std::string> v; size_t a = 0;
    for (;;) { size_t t = s.find(d, a); if (t == std::string::npos) { v.push_back(s.substr(a)); break; } v.push_back(s.substr(a, t - a)); a = t + 1; }
    return v;
}

void NspInstaller::parse_resume(const std::string& s) {
    auto f = split_s(s, '|');
    if (f.size() < 5 || f[0] != "v1") return;
    r_cid_ = f[1]; r_ph_ = f[2]; r_off_ = strtoull(f[3].c_str(), nullptr, 10);
    for (auto& c : split_s(f[4], ',')) if (c.size() == 32) created_.push_back(c);
}

std::string NspInstaller::state() {
    std::string cid, ph; uint64_t off = 0;
    if (cur_open_ && !cur_skip_ && (kind_ == K_NCA || kind_ == K_CNMT)) {
        cid = to_hex(cur_cid_, 16); ph = be_->placeholder_hex(); off = cur_off_;
    }
    if (!opened_ && created_.empty() && r_cid_.empty()) return "";
    std::string c;
    for (size_t i = 0; i < created_.size(); i++) { if (i) c += ","; c += created_[i]; }
    // пока заголовок NSP ещё не разобран, сохраняем то, что было
    if (cid.empty() && !r_cid_.empty() && !opened_) { cid = r_cid_; ph = r_ph_; off = r_off_; }
    return "v1|" + cid + "|" + ph + "|" + std::to_string((unsigned long long)off) + "|" + c;
}

bool NspInstaller::write(uint64_t off, const uint8_t* p, size_t n) {
    if (!err_.empty()) return false;
    if (!opened_) {
        std::string e;
        if (!be_->open(r_cid_.empty() && created_.empty(), e)) return fail(e);
        opened_ = true;
    }
    if (!pfs_.write_at(off, p, n)) return fail(err_.empty() ? pfs_.error() : err_);
    return true;
}

bool NspInstaller::take_seek(uint64_t& off) {
    if (!want_seek_) return false;
    want_seek_ = false; off = seek_to_;
    return true;
}

bool NspInstaller::pfs_begin(const std::string& name, uint64_t size, uint64_t entry_off) {
    cur_name_ = name; cur_size_ = size; cur_off_ = 0; entry_off_ = entry_off;
    cur_skip_ = false; cur_open_ = false; cur_buf_.clear();
    std::string l = lower(name);
    kind_ = K_OTHER;
    if (ends_with_ci(l, ".cnmt.nca")) kind_ = K_CNMT;
    else if (ends_with_ci(l, ".nca")) kind_ = K_NCA;
    else if (ends_with_ci(l, ".tik")) kind_ = K_TIK;
    else if (ends_with_ci(l, ".cert")) kind_ = K_CERT;
    if (kind_ == K_NCA || kind_ == K_CNMT) {
        std::string stem = l.substr(0, l.find('.'));
        if (!from_hex(stem, cur_cid_, 16)) return fail("непонятное имя NCA: " + name);
        if (size == 0) return fail("пустой NCA: " + name);
        std::string e;
        int r = -1;
        bool resumed = false;
        // 1) пробуем продолжить прерванную запись этого же NCA
        if (stem == r_cid_ && r_off_ > 0 && r_off_ < size) {
            r = be_->resume_content(cur_cid_, r_ph_, e);
            if (r == 0) { resumed = true; want_seek_ = true; seek_to_ = entry_off + r_off_; }
            if (r == 0 || r == 1) r_ph_.clear();
            r_cid_.clear();
        }
        // 2) иначе — обычное создание (или «уже установлено»)
        if (!resumed && r != 1) { e.clear(); r = be_->begin_content(cur_cid_, size, e); }
        if (r < 0) return fail(e);
        seen_.insert(stem);
        cur_open_ = r == 0;
        cur_skip_ = r == 1;
        if (cur_skip_) { want_seek_ = true; seek_to_ = entry_off + size; }     // перескакиваем уже установленное
    } else if ((kind_ == K_TIK || kind_ == K_CERT) && size > (1u << 20)) {
        return fail("слишком большой файл " + name);
    }
    return true;
}

bool NspInstaller::pfs_data(const uint8_t* p, size_t n) {
    std::string e;
    switch (kind_) {
    case K_NCA: case K_CNMT:
        if (!cur_skip_) {
            if (!be_->write_content(cur_off_, p, n, e)) return fail(e);
        }
        cur_off_ += n;
        break;
    case K_TIK: case K_CERT:
        cur_buf_.insert(cur_buf_.end(), p, p + n);
        break;
    default: break;                                                 // прочее (xml и т. п.) игнорируем
    }
    return true;
}

bool NspInstaller::pfs_end() {
    std::string e;
    if (kind_ == K_NCA || kind_ == K_CNMT) {
        if (cur_open_) {
            if (cur_off_ != cur_size_) return fail("NCA записан не полностью: " + cur_name_);
            if (!be_->end_content(cur_cid_, e)) { be_->abort_content(); cur_open_ = false; return fail(e); }
            created_.push_back(to_hex(cur_cid_, 16));
            cur_open_ = false;
        }
        if (kind_ == K_CNMT) { Meta m; memcpy(m.cid, cur_cid_, 16); m.size = cur_size_; metas_.push_back(m); }
    } else if (kind_ == K_TIK) {
        tiks_.emplace_back(cur_name_.substr(0, cur_name_.find('.')), cur_buf_);
    } else if (kind_ == K_CERT) {
        certs_.emplace_back(cur_name_.substr(0, cur_name_.find('.')), cur_buf_);
    }
    cur_buf_.clear();
    kind_ = K_OTHER;
    return true;
}

bool NspInstaller::finish() {
    if (!err_.empty()) return false;
    if (!opened_) return fail("пустой NSP");
    if (!pfs_.finish()) return fail(pfs_.error());
    if (!register_all()) return false;
    done_ = true;
    return true;
}

bool NspInstaller::register_all() {
    std::string e;
    if (metas_.empty()) return fail("в NSP нет CNMT — это не установочный пакет");
    // билеты (нужны для игр с titlekey)
    for (auto& t : tiks_) {
        const std::vector<uint8_t>* cert = nullptr;
        for (auto& c : certs_) if (c.first == t.first) cert = &c.second;
        if (!cert) continue;
        if (!be_->import_ticket(t.second, *cert, e)) return fail("импорт билета: " + e);
    }
    for (auto& m : metas_) {
        std::vector<uint8_t> cnmt;
        if (!be_->read_cnmt(m.cid, cnmt, e)) return fail("чтение CNMT: " + e);
        uint64_t id, app; uint32_t ver; uint8_t type;
        std::vector<uint8_t> rec; std::vector<std::string> cids;
        if (!build_meta_record(cnmt, m.cid, m.size, id, ver, type, app, rec, cids, e)) return fail(e);
        for (auto& c : cids) {
            if (!seen_.count(c)) return fail("в NSP не хватает файла " + c + ".nca");
        }
        char b[64]; snprintf(b, sizeof b, "%016llX", (unsigned long long)id);
        info_ = b;
        if (!be_->set_meta(id, ver, type, rec, e)) return fail("запись в базу контента: " + e);
        if (!be_->commit_meta(e)) return fail("commit: " + e);
        if (!be_->push_record(app, id, ver, type, e)) return fail("запись приложения: " + e);
    }
    return true;
}

// Остановка без потери: частичный NCA и уже зарегистрированные остаются, состояние уходит в библиотеку.
std::string NspInstaller::suspend() {
    if (done_) return "";
    std::string st = state();
    if (cur_open_) be_->detach();
    cur_open_ = false;
    done_ = true;
    return st;
}

void NspInstaller::abort() {
    if (done_) return;
    done_ = true;
    if (!opened_) {                                                  // ничего не открывали, но состояние могло быть сохранено
        std::string e;
        if (!created_.empty() || !r_ph_.empty()) { if (be_->open(false, e)) opened_ = true; }
    }
    if (cur_open_) { be_->abort_content(); cur_open_ = false; }
    if (!r_ph_.empty()) be_->delete_placeholder(r_ph_);
    for (auto& c : created_) { uint8_t id[16]; if (from_hex(c, id, 16)) be_->delete_content(id); }
    created_.clear();
}

void nsp_discard(NspBackend* be, const std::string& state) {
    auto f = split_s(state, '|');
    if (f.size() < 5 || f[0] != "v1") return;
    std::string e;
    if (!be->open(false, e)) return;
    if (!f[2].empty()) be->delete_placeholder(f[2]);
    for (auto& c : split_s(f[4], ',')) { uint8_t id[16]; if (c.size() == 32 && from_hex(c, id, 16)) be->delete_content(id); }
}
