#include "swarm.hpp"
#include "sha1.hpp"
#include "bencode.hpp"
#include "util.hpp"
#include <algorithm>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#ifdef __SWITCH__
#include <switch.h>
#endif

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

static const size_t BLOCK = 16384;
static const size_t QMIN = 8;               // минимум запросов в очереди у пира (новый или медленный пир)
static const size_t QCAP = 64;              // максимум (64 × 16 КиБ = 1 МиБ в полёте)
static const size_t MAXPEERS = 30;          // всего соединений с пирами (в сумме с подключающимися)
static const size_t MAXCONNECTING = 12;     // одновременно подключающихся
static const uint64_t CONNECT_TIMEOUT = 8000;
static const uint64_t HANDSHAKE_TIMEOUT = 12000;
static const uint64_t REQ_TIMEOUT = 20000;

// На Switch поддерживается только F_SETFL с O_NONBLOCK, поэтому флаги не читаем.
// Если не получилось — сокет бесполезен (connect/recv заблокируют весь цикл), вызывающий его закрывает.
static bool set_nb(int fd) {
    return fcntl(fd, F_SETFL, O_NONBLOCK) == 0;
}

static void put32(std::vector<uint8_t>& v, uint32_t x) {
    v.push_back(x >> 24); v.push_back(x >> 16); v.push_back(x >> 8); v.push_back(x);
}
static uint32_t get32(const uint8_t* p) { return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 | (uint32_t)p[2] << 8 | p[3]; }

// ───────────────────────── трекеры ─────────────────────────
struct Swarm::Tracker {
    std::string url;
    int kind = 2;                 // 0 http, 1 udp, 2 не поддерживается (https и пр.)
    uint64_t next_at = 0;
    int fails = 0;
    bool busy = false;
    bool started = false;
    bool resolved = false;        // адрес уже найден (DNS не дёргаем при каждом запросе)
    sockaddr_in addr;
    uint64_t addr_at = 0;
    std::string last_err;         // почему последний запрос не удался
    int ok_count = 0;             // сколько раз трекер ответил
    int last_peers = 0;
};

struct Swarm::TrkOp {
    Tracker* t = nullptr;
    int fd = -1;
    int stage = 0;                // http: 0 connecting,1 reading ; udp: 0 wait conn, 1 wait announce
    uint64_t t0 = 0, t_send = 0;
    int tries = 0;
    sockaddr_in addr;
    std::string host, path;
    std::string rx;
    uint32_t tx = 0;
    uint64_t conn_id = 0;
    bool done = false, ok = false;
    std::string err;
    uint32_t interval = 0;
    std::string redirect;         // http-ответ 3xx: куда перенаправляют
    std::vector<std::pair<uint32_t, uint16_t>> peers;
};

static bool resolve4(const std::string& host, uint16_t port, sockaddr_in& out) {
    memset(&out, 0, sizeof out);
    out.sin_family = AF_INET; out.sin_port = htons(port);
    if (inet_pton(AF_INET, host.c_str(), &out.sin_addr) == 1) return true;
    struct addrinfo hints; memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET; hints.ai_socktype = SOCK_STREAM;
    struct addrinfo* res = nullptr;
    if (getaddrinfo(host.c_str(), nullptr, &hints, &res) != 0 || !res) return false;
    out.sin_addr = ((sockaddr_in*)res->ai_addr)->sin_addr;
    freeaddrinfo(res);
    return true;
}

static std::string urlenc(const uint8_t* p, size_t n) {
    static const char* d = "0123456789ABCDEF";
    std::string s;
    for (size_t i = 0; i < n; i++) {
        uint8_t c = p[i];
        if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '-' || c == '.' || c == '_' || c == '~') s += (char)c;
        else { s += '%'; s += d[c >> 4]; s += d[c & 15]; }
    }
    return s;
}

static void parse_compact(const std::string& s, std::vector<std::pair<uint32_t, uint16_t>>& out) {
    for (size_t i = 0; i + 6 <= s.size(); i += 6) {
        const uint8_t* p = (const uint8_t*)s.data() + i;
        out.emplace_back(get32(p), (uint16_t)(p[4] << 8 | p[5]));
    }
}

// ───────────────────────── Swarm ─────────────────────────
Swarm::Swarm(const Meta& m, Sink* sink, uint64_t start_pos, uint64_t mem_cap)
    : m_(m), sink_(sink), mem_cap_(mem_cap) {
    t0_ = now_ms();
    last_progress_ = t0_;
    if (start_pos > m.total) start_pos = m.total;
    // файл, внутри которого (или сразу после которого начинаются пустые файлы) лежит start_pos
    size_t sf = m.files.size() - 1;
    for (size_t i = 0; i < m.files.size(); i++) {
        const TFile& f = m.files[i];
        if (f.off + f.len > start_pos || (f.len == 0 && f.off >= start_pos)) { sf = i; break; }
    }
    cur_ = sf;
    first_pos_ = std::max<uint64_t>(start_pos, m.files[sf].off);
    fed_pos_ = first_pos_;
    start_piece_ = (size_t)(first_pos_ / m.plen);
    opened_ = false;
    next_ = start_piece_;
    uint64_t w = mem_cap / m.plen;
    W_ = (size_t)std::max<uint64_t>(2, std::min<uint64_t>(64, w));
    slots_.resize(W_);
    srand((unsigned)t0_);
    memcpy(peer_id_, "-AN0100-", 8);
    for (int i = 8; i < 20; i++) peer_id_[i] = '0' + rand() % 10;
    for (auto& u : m.trackers) {
        auto t = std::make_unique<Tracker>();
        t->url = u;
        if (u.compare(0, 7, "http://") == 0) t->kind = 0;
        else if (u.compare(0, 6, "udp://") == 0) t->kind = 1;
        memset(&t->addr, 0, sizeof t->addr);
        if (t->kind != 2) trk_.push_back(std::move(t));
        else {
            unsup_++;
            size_t c = u.find("://");
            std::string sch = c == std::string::npos ? std::string("?") : u.substr(0, c);
            if (unsup_schemes_.find(sch) == std::string::npos) { if (!unsup_schemes_.empty()) unsup_schemes_ += "/"; unsup_schemes_ += sch; }
        }
    }
    if (trk_.empty()) status_ = "нет поддерживаемых трекеров (http/udp)";
    else status_ = "подключение к трекерам…";
    if (start_piece_ >= m.npieces) {                 // остались только пустые файлы
        feed(nullptr, m.total, 0);
        finished_ = !failed_;
    }
}

Swarm::~Swarm() { stop(); }

void Swarm::stop() {
    if (stopped_) return;
    stopped_ = true;
    for (auto& p : peers_) if (p->fd >= 0) { close(p->fd); p->fd = -1; }
    for (auto& o : ops_) if (o->fd >= 0) { close(o->fd); o->fd = -1; }
    peers_.clear(); ops_.clear();
}

void Swarm::fail(const std::string& e) {
    if (failed_) return;
    failed_ = true; error_ = e;
    stop();
}

uint64_t Swarm::downloaded_abs() const { return std::min<uint64_t>(m_.total, (uint64_t)start_piece_ * m_.plen + verified_); }

uint64_t Swarm::buffered_bytes() const {
    uint64_t n = 0;
    for (auto& s : slots_) if (s.active) n += (uint64_t)s.ngot * BLOCK;
    return n;
}

int Swarm::peers_active() const {
    int n = 0;
    for (auto& p : peers_) if (p->state == Peer::ACTIVE) n++;
    return n;
}

void Swarm::add_peer(uint32_t ip, uint16_t port) {
    for (auto& c : cands_) if (c.ip == ip && c.port == port) return;
    if (cands_.size() > 2000) return;
    Cand c; c.ip = ip; c.port = port;
    cands_.push_back(c);
}

bool Swarm::slot_alloc(size_t idx) {
    Slot& s = slot_for(idx);
    if (s.active && s.idx == idx) return true;
    if (s.active) return false;
    uint64_t pl = m_.piece_len(idx);
    s.active = true; s.done = false; s.idx = (uint32_t)idx;
    s.nb = (uint32_t)((pl + BLOCK - 1) / BLOCK);
    s.ngot = 0; s.hint = 0; s.fails = 0;
    s.buf.resize((size_t)pl);
    s.st.assign(s.nb, 0);
    s.bpeer.assign(s.nb, 0);
    s.dup.assign(s.nb, 0);
    s.rt.assign(s.nb, 0);
    return true;
}

void Swarm::release_block(uint32_t piece, uint32_t block) {
    Slot& s = slot_for(piece);
    if (!s.active || s.idx != piece || block >= s.nb) return;
    if (s.st[block] == 1) { s.st[block] = 0; if (block < s.hint) s.hint = block; }
}

void Swarm::release_peer_reqs(Peer& p) {
    for (auto& r : p.reqs) release_block(r.piece, r.block);
    p.reqs.clear();
}

void Swarm::drop_peer(Peer& p, bool good) {
    if (p.state == Peer::DEAD) return;
    if (p.state == Peer::CONNECTING) n_conn_fail_++;
    else if (p.state == Peer::HANDSHAKE) n_hs_fail_++;
    else if (!p.got_data) n_nodata_++;
    release_peer_reqs(p);
    if (p.fd >= 0) { close(p.fd); p.fd = -1; }
    p.state = Peer::DEAD;
    if (p.cand < cands_.size()) {
        Cand& c = cands_[p.cand];
        c.live = false;
        uint64_t now = now_ms();
        if (good && p.got_data) { c.fails = 0; c.next_try = now + 10000; }
        else { c.fails++; c.next_try = now + std::min<uint64_t>(600000, 15000ull << std::min(c.fails, 5)); }
    }
}

void Swarm::connect_more(uint64_t now) {
    size_t live = 0, connecting = 0;
    for (auto& p : peers_) {
        if (p->state == Peer::DEAD) continue;
        live++;
        if (p->state == Peer::CONNECTING || p->state == Peer::HANDSHAKE) connecting++;
    }
    int started = 0;
    for (size_t i = 0; i < cands_.size() && live < MAXPEERS && connecting < MAXCONNECTING && started < 4; i++) {
        Cand& c = cands_[i];
        if (c.live || c.banned || c.next_try > now) continue;
        int fd = socket(AF_INET, SOCK_STREAM, 0);
        if (fd < 0) { last_sock_errno_ = errno; n_sock_fail_++; break; }
        if (!set_nb(fd)) { last_sock_errno_ = errno; n_sock_fail_++; close(fd); break; }
        sockaddr_in a; memset(&a, 0, sizeof a);
        a.sin_family = AF_INET; a.sin_port = htons(c.port); a.sin_addr.s_addr = htonl(c.ip);
        n_conn_try_++;
        int r = connect(fd, (sockaddr*)&a, sizeof a);
        if (r != 0 && errno != EINPROGRESS && errno != EAGAIN && errno != EWOULDBLOCK) {
            last_sock_errno_ = errno; n_conn_fail_++;
            close(fd);
            c.fails++; c.next_try = now + 30000;
            continue;
        }
        auto p = std::make_unique<Peer>();
        p->fd = fd; p->id = next_peer_id_++; p->cand = (uint32_t)i;
        p->t_start = p->t_recv = p->t_send = p->t_choke = now;
        c.live = true;
        peers_.push_back(std::move(p));
        live++; connecting++; started++;
    }
    // чистим мёртвых
    peers_.erase(std::remove_if(peers_.begin(), peers_.end(), [](const std::unique_ptr<Peer>& p) { return p->state == Peer::DEAD; }), peers_.end());
}

bool Swarm::peer_send(Peer& p) {
    while (p.wpos < p.wbuf.size()) {
        ssize_t n = send(p.fd, p.wbuf.data() + p.wpos, p.wbuf.size() - p.wpos, MSG_NOSIGNAL);
        if (n > 0) { p.wpos += (size_t)n; p.t_send = now_ms(); continue; }
        if (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR)) break;
        return false;
    }
    if (p.wpos == p.wbuf.size()) { p.wbuf.clear(); p.wpos = 0; }
    return true;
}

// Глубина очереди зависит от скорости пира: быстрому держим до 1 МиБ в полёте, медленному — совсем немного,
// чтобы его запросы не висели до таймаута.
size_t Swarm::qmax_for(const Peer& p) const {
    return std::min<size_t>(QCAP, QMIN + (size_t)(2 * p.rate / BLOCK));      // ≈ две секунды данных в полёте
}

void Swarm::fill_requests(Peer& p, uint64_t now) {
    if (p.state != Peer::ACTIVE || p.choked) return;
    const size_t qmax = qmax_for(p);
    size_t last = std::min<size_t>(m_.npieces, next_ + W_);
    auto send_req = [&](Slot& s, uint32_t pi, uint32_t b) {
        uint64_t pl = m_.piece_len(pi);
        uint32_t len = (uint32_t)std::min<uint64_t>(BLOCK, pl - (uint64_t)b * BLOCK);
        put32(p.wbuf, 13); p.wbuf.push_back(6);
        put32(p.wbuf, pi); put32(p.wbuf, b * (uint32_t)BLOCK); put32(p.wbuf, len);
        p.reqs.push_back({pi, b, now});
        (void)s;
    };
    for (size_t pi = next_; pi < last && p.reqs.size() < qmax; pi++) {
        if (!p.has(pi)) continue;
        if (!slot_alloc(pi)) break;
        Slot& s = slot_for(pi);
        if (s.done) continue;
        while (p.reqs.size() < qmax) {
            while (s.hint < s.nb && s.st[s.hint] != 0) s.hint++;
            if (s.hint >= s.nb) break;
            uint32_t b = s.hint++;
            s.st[b] = 1; s.rt[b] = (uint32_t)now;
            send_req(s, (uint32_t)pi, b);
        }
    }
    // Свободных блоков нет, а у нас ещё есть место в очереди: берём блоки, которые слишком долго висят у других пиров
    // (медленные пиры иначе тормозят весь кусок, а быстрые простаивают). Не более 2 повторных запросов на блок.
    if (p.got_data && p.reqs.size() + 4 <= qmax && now - p.t_steal >= 300) {
        p.t_steal = now;
        uint32_t now32 = (uint32_t)now;
        for (size_t pi = next_; pi < last && p.reqs.size() < qmax; pi++) {
            if (!p.has(pi)) continue;
            Slot& s = slot_for(pi);
            if (!s.active || s.idx != pi || s.done) continue;
            for (uint32_t b = 0; b < s.nb && p.reqs.size() < qmax; b++) {
                if (s.st[b] != 1 || s.dup[b] >= 2) continue;
                if ((uint32_t)(now32 - s.rt[b]) < 800) continue;
                bool mine = false;
                for (auto& r : p.reqs) if (r.piece == pi && r.block == b) { mine = true; break; }
                if (mine) continue;
                s.dup[b]++;
                send_req(s, (uint32_t)pi, b);
            }
        }
    }
}

void Swarm::cancel_dups(uint32_t from_id, uint32_t piece, uint32_t block) {
    uint64_t pl = m_.piece_len(piece);
    uint32_t len = (uint32_t)std::min<uint64_t>(BLOCK, pl - (uint64_t)block * BLOCK);
    for (auto& q : peers_) {
        if (q->id == from_id || q->state != Peer::ACTIVE) continue;
        for (size_t i = 0; i < q->reqs.size(); i++) {
            if (q->reqs[i].piece != piece || q->reqs[i].block != block) continue;
            put32(q->wbuf, 13); q->wbuf.push_back(8);                       // cancel
            put32(q->wbuf, piece); put32(q->wbuf, block * (uint32_t)BLOCK); put32(q->wbuf, len);
            q->reqs.erase(q->reqs.begin() + i);
            break;
        }
    }
}

void Swarm::on_block(Peer& p, uint32_t piece, uint32_t begin, const uint8_t* d, size_t n, uint64_t now) {
    // найти соответствующий запрос
    uint32_t block = begin / (uint32_t)BLOCK;
    if (begin % BLOCK) return;
    auto it = std::find_if(p.reqs.begin(), p.reqs.end(), [&](const Req& r) { return r.piece == piece && r.block == block; });
    if (it == p.reqs.end()) return;       // не просили (или уже истёк таймаут)
    p.reqs.erase(it);
    p.got_data = true;
    Slot& s = slot_for(piece);
    if (!s.active || s.idx != piece || block >= s.nb || s.done) return;
    uint64_t pl = m_.piece_len(piece);
    uint32_t expect = (uint32_t)std::min<uint64_t>(BLOCK, pl - (uint64_t)block * BLOCK);
    if (n != expect) return;
    if (s.st[block] == 2) return;
    memcpy(s.buf.data() + (size_t)block * BLOCK, d, n);
    s.st[block] = 2; s.bpeer[block] = p.id; s.ngot++;
    bytes_in_ += n;
    p.rate_bytes += n;
    last_progress_ = now;
    if (s.dup[block]) cancel_dups(p.id, piece, block);       // блок пришёл — у других пиров он больше не нужен
    if (s.ngot == s.nb) verify_piece(s, now);
}

void Swarm::verify_piece(Slot& s, uint64_t now) {
    uint8_t h[20];
    Sha1::hash(s.buf.data(), s.buf.size(), h);
    if (memcmp(h, m_.hashes.data() + (size_t)s.idx * 20, 20) == 0) {
        s.done = true;
        verified_ += s.buf.size();
        return;
    }
    // кусок не прошёл проверку — если все блоки от одного пира, баним его
    uint32_t who = s.bpeer[0]; bool single = true;
    for (uint32_t b : s.bpeer) if (b != who) single = false;
    if (single) {
        for (auto& p : peers_) if (p->id == who) {
            if (p->cand < cands_.size()) cands_[p->cand].banned = true;
            drop_peer(*p, false);
        }
    }
    s.fails++;
    if (s.fails >= 12) { fail("кусок " + std::to_string(s.idx) + " не проходит проверку SHA-1"); return; }
    s.ngot = 0; s.hint = 0;
    std::fill(s.st.begin(), s.st.end(), 0);
    std::fill(s.dup.begin(), s.dup.end(), 0);
    (void)now;
}

bool Swarm::handle_msg(Peer& p, const uint8_t* b, size_t n, uint64_t now) {
    if (n == 0) return true;                           // keep-alive
    uint8_t id = b[0]; b++; n--;
    switch (id) {
    case 0: p.choked = true; p.t_choke = now; release_peer_reqs(p); break;
    case 1: p.choked = false; break;
    case 4:
        if (n == 4) {
            uint32_t i = get32(b);
            if (i < m_.npieces) {
                if (p.bits.size() < (m_.npieces + 7) / 8) p.bits.resize((m_.npieces + 7) / 8);
                p.bits[i >> 3] |= 0x80 >> (i & 7);
            }
        }
        break;
    case 5:
        p.bits.assign((m_.npieces + 7) / 8, 0);
        memcpy(p.bits.data(), b, std::min(n, p.bits.size()));
        break;
    case 7:
        if (n >= 8) on_block(p, get32(b), get32(b + 4), b + 8, n - 8, now);
        break;
    default: break;                                    // interested/have_all/extended и т.д. игнорируем
    }
    return true;
}

bool Swarm::handle_peer_data(Peer& p, uint64_t now) {
    uint8_t tmp[32768];                                // крупнее — меньше обращений к сервису сокетов
    size_t budget = 1024 * 1024;
    while (budget > 0) {
        ssize_t n = recv(p.fd, tmp, sizeof tmp, 0);
        if (n > 0) { p.rbuf.insert(p.rbuf.end(), tmp, tmp + n); p.t_recv = now; budget -= std::min(budget, (size_t)n); }
        else if (n == 0) return false;
        else if (errno == EAGAIN || errno == EWOULDBLOCK) break;
        else if (errno == EINTR) continue;
        else return false;
        // разбор
        for (;;) {
            size_t avail = p.rbuf.size() - p.rpos;
            const uint8_t* q = p.rbuf.data() + p.rpos;
            if (p.state == Peer::HANDSHAKE) {
                if (avail < 68) break;
                if (q[0] != 19 || memcmp(q + 1, "BitTorrent protocol", 19) || memcmp(q + 28, m_.infohash, 20)) return false;
                p.rpos += 68;
                p.state = Peer::ACTIVE;
                p.rate_t = now;
                n_hs_ok_++;
                put32(p.wbuf, 1); p.wbuf.push_back(2);     // interested
                p.sent_interested = true;
                continue;
            }
            if (avail < 4) break;
            uint32_t len = get32(q);
            if (len > (2u << 20)) return false;
            if (avail < 4 + (size_t)len) break;
            if (!handle_msg(p, q + 4, len, now)) return false;
            p.rpos += 4 + len;
            if (failed_) return true;
        }
        if (p.rpos > 65536 || p.rpos == p.rbuf.size()) {
            p.rbuf.erase(p.rbuf.begin(), p.rbuf.begin() + p.rpos);
            p.rpos = 0;
        }
    }
    return true;
}

bool Swarm::feed(const uint8_t* data, uint64_t pstart, uint64_t n) {
    uint64_t pos = std::max(pstart, first_pos_);
    uint64_t end = pstart + n;
    while (cur_ < m_.files.size()) {
        const TFile& f = m_.files[cur_];
        uint64_t fend = f.off + f.len;
        if (!opened_) {
            if (f.len > 0 && pos >= end) break;
            if (!f.pad && !sink_->file_begin(m_, cur_)) { fail(sink_->error()); return false; }
            opened_ = true;
        }
        if (pos < end && pos < fend) {
            uint64_t k = std::min(end, fend) - pos;
            if (!f.pad && !sink_->file_data(data + (pos - pstart), (size_t)k, pos - f.off)) { fail(sink_->error()); return false; }
            pos += k;
            fed_pos_ = pos;
            uint64_t so = 0;
            if (!f.pad && sink_->seek_request(so)) {          // приёмник просит пропустить уже установленное
                uint64_t abs = f.off + so;
                if (abs > pos && abs <= fend) { do_seek(abs); return true; }
            }
        }
        if (pos >= fend) {
            if (!f.pad && !sink_->file_end()) { fail(sink_->error()); return false; }
            opened_ = false;
            if (file_cb_) file_cb_(cur_);
            cur_++;
            continue;
        }
        break;
    }
    return true;
}

// Прыжок вперёд внутри текущего файла: буфер и запросы сбрасываются, дальше качаем с нужного куска.
void Swarm::do_seek(uint64_t abs) {
    for (auto& s : slots_) { s.active = false; s.done = false; std::vector<uint8_t>().swap(s.buf); }
    for (auto& p : peers_) p->reqs.clear();                  // запоздавшие блоки будут проигнорированы
    first_pos_ = abs; fed_pos_ = abs;
    next_ = (size_t)(abs / m_.plen);
    start_piece_ = next_; verified_ = 0;
    seeked_ = true;
    last_progress_ = now_ms();
}

void Swarm::deliver(uint64_t now) {
    while (!failed_ && next_ < m_.npieces) {
        Slot& s = slot_for(next_);
        if (!s.active || s.idx != next_ || !s.done) break;
        uint64_t pstart = (uint64_t)next_ * m_.plen;
        if (!feed(s.buf.data(), pstart, s.buf.size())) return;
        if (seeked_) { seeked_ = false; continue; }           // слоты уже сброшены, next_ переставлен
        s.active = false; s.done = false;
        std::vector<uint8_t>().swap(s.buf);            // реально отдаём память
        next_++;
        last_progress_ = now;
    }
    if (!failed_ && next_ >= m_.npieces && !finished_) {
        if (!feed(nullptr, m_.total, 0)) return;
        if (cur_ >= m_.files.size()) { finished_ = true; status_ = "готово"; stop(); }
    }
}

void Swarm::update_speed(uint64_t now) {
    if (samples_.empty() || now - samples_.back().first >= 500) samples_.emplace_back(now, bytes_in_);
    while (samples_.size() > 2 && now - samples_[1].first > 5000) samples_.erase(samples_.begin());
    auto& a = samples_.front();
    double dt = (double)(now - a.first) / 1000.0;
    speed_ = dt > 0.4 ? (double)(bytes_in_ - a.second) / dt : speed_;
}

// ───────────────────────── трекеры: HTTP / UDP ─────────────────────────
static bool parse_url(const std::string& url, size_t skip, std::string& host, uint16_t& port, std::string& path, uint16_t defport) {
    std::string rest = url.substr(skip);
    size_t sl = rest.find('/');
    std::string hp = sl == std::string::npos ? rest : rest.substr(0, sl);
    path = sl == std::string::npos ? "/" : rest.substr(sl);
    port = defport;
    size_t c = hp.rfind(':');
    if (c != std::string::npos) {
        int pt = atoi(hp.c_str() + c + 1);
        if (pt <= 0 || pt > 65535) return false;
        port = (uint16_t)pt; hp = hp.substr(0, c);
    }
    host = hp;
    return !host.empty();
}

void Swarm::trackers_tick(uint64_t now) {
    // пропала сеть / нет пиров: не ждём долгих пауз между повторными запросами к трекерам
    if (peers_active() == 0 && now - last_kick_ > 90000) {
        last_kick_ = now;
        for (auto& t : trk_) { t->fails = 0; if (!t->busy && t->next_at > now) t->next_at = now; }
        for (auto& c : cands_) if (!c.live && !c.banned && c.next_try > now + 20000) c.next_try = now + 20000;
    }
    // запуск новых операций (до 3 одновременно)
    if (ops_.size() < 4 && !finished_) {
        int resolved_now = 0;
        for (auto& t : trk_) {
            if (ops_.size() >= 4) break;
            if (t->busy || t->next_at > now) continue;
            auto op = std::make_unique<TrkOp>();
            op->t = t.get(); op->t0 = now;
            uint16_t port = 0;
            std::string host, path;
            bool ok = false;
            if (t->kind == 0) ok = parse_url(t->url, 7, host, port, path, 80);
            else ok = parse_url(t->url, 6, host, port, path, 80);
            if (!ok) { t->fails++; t->last_err = "некорректный адрес"; t->next_at = now + 3600000; continue; }
            if (!t->resolved || now - t->addr_at > 1800000) {
                in_addr tmp;
                bool numeric = inet_pton(AF_INET, host.c_str(), &tmp) == 1;
                if (!numeric && resolved_now >= 1) continue;          // DNS блокирует цикл — не больше одного имени за шаг
                if (!numeric) resolved_now++;
                if (!resolve4(host, port, t->addr)) {
                    t->fails++; n_dns_fail_++; t->last_err = "DNS: адрес не найден";
                    t->next_at = now + std::min<uint64_t>(900000, 30000ull << std::min(t->fails, 5));
                    continue;
                }
                t->resolved = true; t->addr_at = now;
            }
            op->addr = t->addr;
            op->host = host; op->path = path;
            op->tx = (uint32_t)rand();
            if (t->kind == 0) {
                op->fd = socket(AF_INET, SOCK_STREAM, 0);
                if (op->fd < 0) { last_sock_errno_ = errno; n_sock_fail_++; continue; }
                if (!set_nb(op->fd)) { last_sock_errno_ = errno; n_sock_fail_++; close(op->fd); continue; }
                int r = connect(op->fd, (sockaddr*)&op->addr, sizeof op->addr);
                if (r != 0 && errno != EINPROGRESS && errno != EAGAIN && errno != EWOULDBLOCK) { last_sock_errno_ = errno; close(op->fd); t->fails++; t->last_err = "нет соединения"; t->next_at = now + 30000; continue; }
                op->stage = 0;
            } else {
                op->fd = socket(AF_INET, SOCK_DGRAM, 0);
                if (op->fd < 0) { last_sock_errno_ = errno; n_sock_fail_++; continue; }
                if (!set_nb(op->fd)) { last_sock_errno_ = errno; n_sock_fail_++; close(op->fd); continue; }
                uint8_t req[16];
                uint64_t proto = 0x41727101980ull;
                for (int i = 0; i < 8; i++) req[i] = (uint8_t)(proto >> (56 - 8 * i));
                req[8] = req[9] = req[10] = req[11] = 0;
                req[12] = op->tx >> 24; req[13] = op->tx >> 16; req[14] = op->tx >> 8; req[15] = op->tx;
                sendto(op->fd, req, 16, 0, (sockaddr*)&op->addr, sizeof op->addr);
                op->t_send = now; op->stage = 0;
            }
            t->busy = true;
            ops_.push_back(std::move(op));
        }
    }
    // ход существующих операций
    for (auto& o : ops_) {
        if (o->done) continue;
        if (now - o->t0 > 10000) { o->done = true; o->err = "таймаут"; continue; }
        if (o->t->kind == 0) {
            if (o->stage == 0) {
                pollfd pf{o->fd, POLLOUT, 0};
                if (poll(&pf, 1, 0) > 0) {
                    int e = 0; socklen_t l = sizeof e;
                    getsockopt(o->fd, SOL_SOCKET, SO_ERROR, &e, &l);
                    if (e || (pf.revents & (POLLERR | POLLHUP))) { o->done = true; o->err = "нет соединения"; continue; }
                    std::string q = o->path;
                    q += q.find('?') == std::string::npos ? "?" : "&";
                    char tail[200];
                    uint64_t left = m_.total > downloaded_abs() ? m_.total - downloaded_abs() : 0;
                    snprintf(tail, sizeof tail, "&peer_id=%s&port=6881&uploaded=0&downloaded=%llu&left=%llu&compact=1&numwant=100%s",
                             urlenc(peer_id_, 20).c_str(), (unsigned long long)bytes_in_, (unsigned long long)left, o->t->started ? "" : "&event=started");
                    q += "info_hash=" + urlenc(m_.infohash, 20) + tail;
                    std::string req = "GET " + q + " HTTP/1.0\r\nHost: " + o->host + "\r\nUser-Agent: archive_nintendo/1.0\r\nConnection: close\r\n\r\n";
                    if (send(o->fd, req.data(), req.size(), MSG_NOSIGNAL) != (ssize_t)req.size()) { o->done = true; o->err = "ошибка отправки"; continue; }
                    o->stage = 1;
                }
            } else {
                for (;;) {
                    char buf[4096];
                    ssize_t n = recv(o->fd, buf, sizeof buf, 0);
                    if (n > 0) { o->rx.append(buf, (size_t)n); if (o->rx.size() > (1u << 20)) { o->done = true; o->err = "большой ответ"; break; } continue; }
                    if (n == 0) {                                  // конец ответа
                        o->done = true;
                        size_t hb = o->rx.find("\r\n\r\n");
                        if (hb == std::string::npos || o->rx.compare(0, 5, "HTTP/") != 0) { o->err = "плохой ответ"; break; }
                        if (o->rx.compare(8, 4, " 200") != 0) {
                            int code = atoi(o->rx.c_str() + 9);
                            if (code >= 301 && code <= 308) {
                                std::string head = o->rx.substr(0, hb);
                                std::string low = lower(head);
                                size_t lp = low.find("\r\nlocation:");
                                if (lp != std::string::npos) {
                                    size_t a = lp + 11, e = head.find("\r\n", a);
                                    std::string loc = head.substr(a, e == std::string::npos ? std::string::npos : e - a);
                                    while (!loc.empty() && (loc[0] == ' ' || loc[0] == '\t')) loc.erase(0, 1);
                                    o->redirect = loc;
                                }
                                o->err = "перенаправление (HTTP " + std::to_string(code) + ")";
                            } else o->err = "HTTP " + std::to_string(code);
                            break;
                        }
                        std::string body = o->rx.substr(hb + 4);
                        BVal v; size_t pos = 0;
                        if (!bdecode((const uint8_t*)body.data(), body.size(), pos, v) || v.t != BVal::DICT) { o->err = "не bencode"; break; }
                        if (auto fr = v.get("failure reason")) { o->err = fr->s; break; }
                        if (auto iv = v.get("interval")) o->interval = (uint32_t)std::max<int64_t>(0, iv->i);
                        if (auto pv = v.get("peers")) {
                            if (pv->t == BVal::STR) parse_compact(pv->s, o->peers);
                            else if (pv->t == BVal::LIST)
                                for (auto& e : pv->l) {
                                    auto ip = e.get("ip"); auto pt = e.get("port");
                                    in_addr a;
                                    if (ip && pt && ip->t == BVal::STR && inet_pton(AF_INET, ip->s.c_str(), &a) == 1)
                                        o->peers.emplace_back(ntohl(a.s_addr), (uint16_t)pt->i);
                                }
                        }
                        o->ok = true;
                        break;
                    }
                    if (errno == EAGAIN || errno == EWOULDBLOCK) break;
                    if (errno == EINTR) continue;
                    o->done = true; o->err = "ошибка чтения"; break;
                }
            }
        } else {                                                   // UDP
            uint8_t buf[2048];
            ssize_t n = recvfrom(o->fd, buf, sizeof buf, 0, nullptr, nullptr);
            if (n >= 16 && o->stage == 0 && get32(buf) == 0 && get32(buf + 4) == o->tx) {
                o->conn_id = (uint64_t)get32(buf + 8) << 32 | get32(buf + 12);
                uint8_t req[98]; memset(req, 0, sizeof req);
                for (int i = 0; i < 8; i++) req[i] = (uint8_t)(o->conn_id >> (56 - 8 * i));
                req[11] = 1;                                       // action = announce
                o->tx = (uint32_t)rand();
                req[12] = o->tx >> 24; req[13] = o->tx >> 16; req[14] = o->tx >> 8; req[15] = o->tx;
                memcpy(req + 16, m_.infohash, 20);
                memcpy(req + 36, peer_id_, 20);
                uint64_t left = m_.total > downloaded_abs() ? m_.total - downloaded_abs() : 0;
                for (int i = 0; i < 8; i++) { req[56 + i] = (uint8_t)(bytes_in_ >> (56 - 8 * i)); req[64 + i] = (uint8_t)(left >> (56 - 8 * i)); }
                req[83] = o->t->started ? 0 : 2;                   // event (смещение 80): 2 = started
                uint32_t key = (uint32_t)rand();                   // key (смещение 88)
                req[88] = key >> 24; req[89] = key >> 16; req[90] = key >> 8; req[91] = key;
                req[92] = req[93] = req[94] = 0; req[95] = 100;    // num_want (смещение 92) = 100; ноль = «пиров не нужно»
                req[96] = 6881 >> 8; req[97] = 6881 & 255;
                sendto(o->fd, req, sizeof req, 0, (sockaddr*)&o->addr, sizeof o->addr);
                o->stage = 1; o->t_send = now;
            } else if (n >= 20 && o->stage == 1 && get32(buf) == 1 && get32(buf + 4) == o->tx) {
                o->interval = get32(buf + 8);
                parse_compact(std::string((const char*)buf + 20, (size_t)n - 20), o->peers);
                o->ok = true; o->done = true;
            } else if (n >= 8 && get32(buf) == 3) {
                o->done = true; o->err = std::string((const char*)buf + 8, (size_t)n - 8);
            } else if (now - o->t_send > 4000 && o->tries < 1) {   // одна повторная отправка
                o->tries++;
                o->t0 = now - 4000;
                o->stage = 0;
                uint8_t req[16];
                uint64_t proto = 0x41727101980ull;
                for (int i = 0; i < 8; i++) req[i] = (uint8_t)(proto >> (56 - 8 * i));
                req[8] = req[9] = req[10] = req[11] = 0;
                o->tx = (uint32_t)rand();
                req[12] = o->tx >> 24; req[13] = o->tx >> 16; req[14] = o->tx >> 8; req[15] = o->tx;
                sendto(o->fd, req, 16, 0, (sockaddr*)&o->addr, sizeof o->addr);
                o->t_send = now;
            }
        }
    }
    // завершённые операции
    for (auto& o : ops_) {
        if (!o->done) continue;
        if (o->fd >= 0) { close(o->fd); o->fd = -1; }
        Tracker* t = o->t;
        t->busy = false;
        if (o->ok) {
            t->fails = 0; t->started = true; t->ok_count++; t->last_err.clear(); t->last_peers = (int)o->peers.size();
            uint32_t iv = std::max<uint32_t>(60, std::min<uint32_t>(o->interval ? o->interval : 600, 1800));
            if (o->peers.empty() || peers_active() < 3) iv = std::min<uint32_t>(iv, 60);
            t->next_at = now + (uint64_t)iv * 1000;
            for (auto& pr : o->peers) add_peer(pr.first, pr.second);
            char b[80]; snprintf(b, sizeof b, "трекер ответил: пиров %d", (int)o->peers.size());
            status_ = b;
        } else {
            t->last_err = o->err.empty() ? std::string("нет ответа") : o->err;
            if (!o->redirect.empty()) {
                if (o->redirect.compare(0, 7, "http://") == 0) { t->url = o->redirect; t->resolved = false; t->next_at = now; t->fails = 0; }
                else { t->last_err = "трекер требует https (не поддерживается)"; t->fails++; t->next_at = now + 3600000; }
            } else {
                t->fails++;
                t->next_at = now + std::min<uint64_t>(900000, 30000ull << std::min(t->fails, 5));
            }
        }
    }
    ops_.erase(std::remove_if(ops_.begin(), ops_.end(), [](const std::unique_ptr<TrkOp>& o) { return o->done; }), ops_.end());
}

// ───────────────────────── диагностика ─────────────────────────
int Swarm::unchoked_peers() const {
    int n = 0;
    for (auto& p : peers_) if (p->state == Peer::ACTIVE && !p->choked) n++;
    return n;
}

std::string Swarm::diag_trackers() const {
    char b[320];
    if (trk_.empty()) {
        snprintf(b, sizeof b, "Трекеры: нет http/udp (есть только %s) — этот торрент скачать нельзя",
                 unsup_schemes_.empty() ? "DHT/magnet" : unsup_schemes_.c_str());
        return b;
    }
    int ok = 0, bad = 0, wait = 0, peers = 0;
    std::string err;
    for (auto& t : trk_) {
        if (t->ok_count) { ok++; peers = std::max(peers, t->last_peers); }
        else if (t->fails || !t->last_err.empty()) { bad++; if (err.empty()) err = t->last_err; }
        else wait++;
    }
    std::string s = "Трекеры: ответили " + std::to_string(ok) + " из " + std::to_string(trk_.size());
    if (bad) s += ", без ответа " + std::to_string(bad);
    if (wait) s += ", ждём " + std::to_string(wait);
    if (unsup_) s += " · пропущено " + unsup_schemes_ + ": " + std::to_string(unsup_);
    if (!ok && !err.empty()) s += " · " + err;
    if (n_dns_fail_ && !ok) s += " (DNS: " + std::to_string(n_dns_fail_) + " сбоев)";
    return s;
}

std::string Swarm::diag_peers() const {
    int connecting = 0, active = 0, data = 0;
    for (auto& p : peers_) {
        if (p->state == Peer::CONNECTING || p->state == Peer::HANDSHAKE) connecting++;
        else if (p->state == Peer::ACTIVE) { active++; if (p->got_data) data++; }
    }
    char b[320];
    snprintf(b, sizeof b, "Пиры: найдено %d · подключаются %d · на связи %d (разрешили качать %d, отдают %d) · отказов %d",
             (int)cands_.size(), connecting, active, unchoked_peers(), data, n_conn_fail_ + n_hs_fail_);
    std::string s = b;
    if (n_sock_fail_) s += " · ошибка сокета " + std::to_string(last_sock_errno_);
    return s;
}

// ───────────────────────── основной шаг ─────────────────────────
void Swarm::tick(uint64_t now) {
    if (finished_ || failed_ || stopped_) return;
    trackers_tick(now);
    connect_more(now);

    std::vector<pollfd> fds;
    std::vector<Peer*> who;
    for (auto& p : peers_) {
        if (p->state == Peer::DEAD || p->fd < 0) continue;
        short ev = POLLIN;
        if (p->state == Peer::CONNECTING || p->wpos < p->wbuf.size()) ev |= POLLOUT;
        fds.push_back({p->fd, ev, 0});
        who.push_back(p.get());
    }
    if (!fds.empty()) poll(fds.data(), fds.size(), 8);
    else {
#ifdef __SWITCH__
        svcSleepThread(8ull * 1000000ull);
#else
        struct timespec ts{0, 8 * 1000000}; nanosleep(&ts, nullptr);
#endif
    }
    now = now_ms();

    for (size_t i = 0; i < fds.size() && !failed_; i++) {
        Peer& p = *who[i];
        short re = fds[i].revents;
        if (p.state == Peer::DEAD) continue;
        if (p.state == Peer::CONNECTING) {
            if (re & (POLLOUT | POLLERR | POLLHUP)) {
                int e = 0; socklen_t l = sizeof e;
                getsockopt(p.fd, SOL_SOCKET, SO_ERROR, &e, &l);
                if (e || (re & (POLLERR | POLLHUP))) { drop_peer(p, false); continue; }
                p.state = Peer::HANDSHAKE;
                uint8_t hs[68]; memset(hs, 0, sizeof hs);
                hs[0] = 19; memcpy(hs + 1, "BitTorrent protocol", 19);
                memcpy(hs + 28, m_.infohash, 20); memcpy(hs + 48, peer_id_, 20);
                p.wbuf.insert(p.wbuf.end(), hs, hs + 68);
                p.t_recv = now;
            } else continue;
        }
        if (re & POLLIN) {
            if (!handle_peer_data(p, now)) { drop_peer(p, true); continue; }
        } else if (re & (POLLERR | POLLHUP | POLLNVAL)) { drop_peer(p, true); continue; }
    }
    if (failed_) return;

    // задачи по пирам: запросы, таймауты, отправка
    for (auto& pp : peers_) {
        Peer& p = *pp;
        if (p.state == Peer::DEAD) continue;
        if (p.state == Peer::CONNECTING && now - p.t_start > CONNECT_TIMEOUT) { drop_peer(p, false); continue; }
        if (p.state == Peer::HANDSHAKE && now - p.t_recv > HANDSHAKE_TIMEOUT) { drop_peer(p, false); continue; }
        if (p.state == Peer::ACTIVE) {
            bool snub = false;
            for (size_t i = 0; i < p.reqs.size();) {
                if (now - p.reqs[i].t > REQ_TIMEOUT) {
                    release_block(p.reqs[i].piece, p.reqs[i].block); p.reqs.erase(p.reqs.begin() + i);
                    if (!p.got_data) snub = true;                 // обещал и ни одного блока не прислал
                }
                else i++;
            }
            if (snub) { drop_peer(p, false); continue; }
            if (p.choked && now - p.t_choke > 150000) { drop_peer(p, true); continue; }
            if (now - p.t_send > 90000) { put32(p.wbuf, 0); p.t_send = now; }
            if (now - p.rate_t >= 300) {                            // скорость пира за последние ~0,3 с (сглаженная)
                uint64_t inst = p.rate_bytes * 1000 / (now - p.rate_t);
                p.rate = p.rate ? (p.rate + inst) / 2 : inst;
                p.rate_bytes = 0; p.rate_t = now;
            }
            fill_requests(p, now);
        }
        if (p.state == Peer::ACTIVE && now - p.t_recv > 120000) { drop_peer(p, true); continue; }
        if (p.fd >= 0 && p.state != Peer::CONNECTING && !peer_send(p)) drop_peer(p, true);
    }

    deliver(now);
    update_speed(now);
    if (!failed_ && !finished_) {
        int act = peers_active();
        char b[96];
        if (act) snprintf(b, sizeof b, "пиров: %d (известно %d)", act, (int)cands_.size());
        else if (!cands_.empty()) snprintf(b, sizeof b, "подключение к пирам (%d)…", (int)cands_.size());
        else if (trk_.empty()) snprintf(b, sizeof b, "нет поддерживаемых трекеров");
        else snprintf(b, sizeof b, "ожидание пиров от трекеров…");
        status_ = b;
    }
}
