#pragma once
// Скачивание одного файла по ссылке http:// или https:// (редиректы, chunked, имя файла из ответа сервера).
// Без потоков: tick() вызывается из главного цикла. Содержимое ссылки не анализируется.
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <functional>
#include <string>
#include <vector>

// Поток поверх соединения: обычный TCP или TLS.
struct NetStream {
    enum { NS_WOULDBLOCK = 0, NS_CLOSED = -1, NS_FAILED = -2 };
    virtual ~NetStream() {}
    virtual int read(uint8_t* p, size_t n) = 0;          // >0 — прочитано; 0 — данных пока нет; -1 — соединение закрыто; -2 — ошибка
    virtual int write(const uint8_t* p, size_t n) = 0;   // >=0 — записано (0 — пока нельзя); -1 — ошибка
    virtual std::string error() { return std::string(); }
};

// Открыть TLS поверх уже подключённого сокета. При успехе поток владеет сокетом (закроет сам).
// При неудаче вернуть nullptr и текст ошибки — сокет закроет вызывающий.
typedef NetStream* (*TlsOpenFn)(int fd, const std::string& host, std::string& err);
void urlfetch_set_tls(TlsOpenFn fn);                     // на Switch — служба ssl; на ПК не задаётся (https недоступен)

struct ParsedUrl {
    std::string scheme, host, path;                      // path уже закодирован (%XX), всегда начинается с '/'
    int port = 0;
    std::string hostport() const;                        // для заголовка Host
};
// Разбор ссылки; без схемы считается http://. false — в err причина (по-русски).
bool urlfetch_parse(const std::string& in, ParsedUrl& u, std::string& err);
// Безопасное имя файла для FAT (убирает / \ : * ? " < > |, управляющие и битый UTF-8, ограничивает длину)
std::string urlfetch_sanitize(const std::string& name);
// Имя из заголовка Content-Disposition ("" если нет)
std::string urlfetch_cd_name(const std::string& header_value);

class UrlFetch {
public:
    enum State { S_START, S_RESOLVE, S_CONNECT, S_TLS, S_SEND, S_HEADERS, S_BODY, S_DONE, S_FAILED };

    // download_dir — куда класть обычные файлы, torrent_dir — куда класть .torrent
    UrlFetch(const std::string& url, const std::string& download_dir, const std::string& torrent_dir);
    ~UrlFetch();
    UrlFetch(const UrlFetch&) = delete;
    UrlFetch& operator=(const UrlFetch&) = delete;

    void set_free_fn(std::function<int64_t()> f) { free_fn_ = f; }   // свободное место, Б (<0 — неизвестно)
    void tick(uint64_t now);

    State state() const { return st_; }
    bool finished() const { return st_ == S_DONE; }
    bool failed() const { return st_ == S_FAILED; }
    const std::string& error() const { return err_; }
    std::string status_text() const;                     // что происходит сейчас
    const std::string& input_url() const { return in_url_; }
    std::string current_url() const;                     // после перенаправлений
    const std::string& name() const { return name_; }    // имя файла (известно после заголовков)
    const std::string& dest_path() const { return final_; }   // куда сохранено (после DONE) или будет сохранено
    bool is_torrent() const { return torrent_; }
    const std::string& content_type() const { return ctype_; }   // тип от сервера (в нижнем регистре)
    const std::string& host() const { return cur_.host; }
    uint64_t downloaded() const { return got_; }
    uint64_t total() const { return has_len_ ? len_ : 0; }
    double speed() const { return speed_; }
    uint64_t last_progress() const { return t_data_; }
    int redirects() const { return redirects_; }

private:
    std::string in_url_, ddir_, tdir_;
    State st_ = S_START;
    std::string err_;
    ParsedUrl cur_;
    std::string cur_str_;
    int redirects_ = 0;
    int fd_ = -1, pfd_ = -1;                  // fd_ — пока идёт подключение; pfd_ — сокет под потоком (для ожидания данных)
    NetStream* ns_ = nullptr;
    uint64_t t_state_ = 0, t_data_ = 0, now_ = 0;
    std::string req_;
    size_t sent_ = 0;
    std::string hbuf_;                        // заголовки ответа
    std::vector<uint8_t> rb_;                 // буфер чтения (создаётся при первом использовании)
    // ответ
    bool has_len_ = false, chunked_ = false, body_done_ = false, torrent_ = false;
    uint64_t len_ = 0, got_ = 0;
    enum { C_SIZE, C_DATA, C_CRLF, C_TRAILER } cs_ = C_SIZE;
    uint64_t csz_ = 0;
    std::string line_;
    std::string name_, part_, final_, ctype_;
    FILE* out_ = nullptr;
    // скорость
    double speed_ = 0;
    uint64_t sp_t_ = 0, sp_b_ = 0;
    std::function<int64_t()> free_fn_;

    void fail(const std::string& msg);
    void cleanup(bool remove_part);
    void begin(uint64_t now);
    void do_resolve(uint64_t now);
    void do_connect(uint64_t now);
    void do_tls(uint64_t now);
    void do_send(uint64_t now);
    void do_headers(uint64_t now);
    void do_body(uint64_t now);
    bool on_headers(size_t hend);
    bool open_output();
    bool write_out(const uint8_t* p, size_t n);
    bool feed_body(const uint8_t* p, size_t n);
    void complete();
    void wait_readable(int ms);
};
