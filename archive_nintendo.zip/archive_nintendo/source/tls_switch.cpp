// HTTPS для «Скачать по ссылке»: системная служба ssl (libnx). Сертификаты сайтов проверяет сама консоль,
// своего хранилища сертификатов приложению не нужно. На ПК этот файл пустой.
#ifdef __SWITCH__
#include <switch.h>
#include <poll.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <vector>
#include "urlfetch.hpp"

static bool g_ssl_init = false, g_ctx_ok = false;
static SslContext g_ctx;
static Result g_ssl_rc = 0;
static std::string g_ssl_err;

static std::string hex_rc(const char* what, Result rc) {
    char b[96];
    snprintf(b, sizeof b, "%s (код 0x%X)", what, (unsigned)rc);
    return b;
}

namespace {
// Режим ввода-вывода у соединения — по умолчанию блокирующий. Чтобы не повиснуть, читаем только тогда,
// когда в сокете уже есть данные (poll) или служба говорит, что у неё есть расшифрованное.
struct TlsStream : NetStream {
    SslConnection c;
    int fd = -1;
    bool open = false;
    std::string err;

    ~TlsStream() override {
        if (open) sslConnectionClose(&c);
        if (fd >= 0) close(fd);
    }

    int read(uint8_t* p, size_t n) override {
        bool ready = false;
        s32 pend = 0;
        if (R_SUCCEEDED(sslConnectionPending(&c, &pend)) && pend > 0) ready = true;
        if (!ready) {
            pollfd pf{fd, POLLIN, 0};
            int r = poll(&pf, 1, 0);
            if (r > 0) ready = true;                    // пришли данные или соединение закрыли
        }
        if (!ready) return NS_WOULDBLOCK;
        u32 got = 0;
        Result rc = sslConnectionRead(&c, p, (u32)n, &got);
        if (R_FAILED(rc)) { err = hex_rc("чтение TLS", rc); return NS_FAILED; }
        if (got == 0) return NS_CLOSED;
        return (int)got;
    }

    int write(const uint8_t* p, size_t n) override {
        u32 wrote = 0;
        Result rc = sslConnectionWrite(&c, p, (u32)n, &wrote);
        if (R_FAILED(rc)) { err = hex_rc("запись TLS", rc); return -1; }
        return (int)wrote;
    }

    std::string error() override { return err; }
};
}

static NetStream* tls_open(int fd, const std::string& host, std::string& err) {
    if (!g_ssl_init) { err = g_ssl_err.empty() ? "HTTPS недоступен: служба ssl не запущена" : g_ssl_err; return nullptr; }
    if (!g_ctx_ok) { err = g_ssl_err; return nullptr; }
    TlsStream* s = new TlsStream;
    Result rc = sslContextCreateConnection(&g_ctx, &s->c);
    if (R_FAILED(rc)) { err = hex_rc("HTTPS: не удалось создать соединение", rc); delete s; return nullptr; }
    s->open = true;
    int out_fd = -1;
    rc = sslConnectionSetSocketDescriptor(&s->c, fd, &out_fd);       // служба дублирует сокет; свой закрываем сами
    if (R_FAILED(rc)) { err = hex_rc("HTTPS: не удалось передать сокет службе ssl", rc); delete s; return nullptr; }
    rc = sslConnectionSetHostName(&s->c, host.c_str(), (u32)host.size());
    if (R_FAILED(rc)) { err = hex_rc("HTTPS: не удалось задать имя сайта", rc); delete s; return nullptr; }
    rc = sslConnectionSetVerifyOption(&s->c, SslVerifyOption_PeerCa | SslVerifyOption_HostName);   // проверяем цепочку и имя сайта
    if (R_FAILED(rc)) { err = hex_rc("HTTPS: не удалось включить проверку сертификата", rc); delete s; return nullptr; }
    std::vector<u8> certs(16384);
    u32 out_size = 0, total_certs = 0;
    rc = sslConnectionDoHandshake(&s->c, &out_size, &total_certs, certs.data(), (u32)certs.size());
    if (R_FAILED(rc)) {
        Result ve = sslConnectionGetVerifyCertError(&s->c);
        std::string m = hex_rc("HTTPS: не удалось установить защищённое соединение", rc);
        if (R_FAILED(ve)) { char b[64]; snprintf(b, sizeof b, ", проверка сертификата 0x%X", (unsigned)ve); m += b; }
        m += ". Проверьте дату и время консоли";
        err = m;
        delete s;                      // закроет только соединение; сокет вызывающий закроет сам
        s = nullptr;
        return nullptr;
    }
    s->fd = fd;                        // с этого момента сокет принадлежит потоку
    return s;
}

bool switch_tls_init() {
    g_ssl_rc = sslInitialize(3);
    if (R_FAILED(g_ssl_rc)) { g_ssl_err = hex_rc("HTTPS недоступен: служба ssl не запустилась", g_ssl_rc); urlfetch_set_tls(&tls_open); return false; }
    g_ssl_init = true;
    // Прошивка 11+ ждёт в старших битах версию интерфейса (BIT(24)); если не принимает — пробуем «просто авто»
    Result rc = sslCreateContext(&g_ctx, (SslVersion)((u32)SslVersion_Auto | (1u << 24)));
    if (R_FAILED(rc)) rc = sslCreateContext(&g_ctx, SslVersion_Auto);
    if (R_FAILED(rc)) { g_ssl_err = hex_rc("HTTPS недоступен: не удалось создать контекст ssl", rc); }
    else g_ctx_ok = true;
    urlfetch_set_tls(&tls_open);
    return g_ctx_ok;
}

void switch_tls_exit() {
    if (g_ctx_ok) { sslContextClose(&g_ctx); g_ctx_ok = false; }
    if (g_ssl_init) { sslExit(); g_ssl_init = false; }
}
#endif
