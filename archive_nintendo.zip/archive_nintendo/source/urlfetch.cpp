#include "urlfetch.hpp"
#include "util.hpp"
#include <algorithm>
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

static const uint64_t CONNECT_T = 12000;   // подключение
static const uint64_t HEADERS_T = 25000;   // ответ сервера
static const uint64_t BODY_T = 30000;      // тишина посреди загрузки
static const int MAX_REDIRECTS = 6;

static TlsOpenFn g_tls = nullptr;
void urlfetch_set_tls(TlsOpenFn fn) { g_tls = fn; }

// ───────── обычный TCP ─────────
namespace {
struct TcpStream : NetStream {
    int fd;
    explicit TcpStream(int f) : fd(f) {}
    ~TcpStream() override { if (fd >= 0) close(fd); }
    int read(uint8_t* p, size_t n) override {
        ssize_t r = recv(fd, p, n, 0);
        if (r > 0) return (int)r;
        if (r == 0) return NS_CLOSED;
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) return NS_WOULDBLOCK;
        return NS_FAILED;
    }
    int write(const uint8_t* p, size_t n) override {
        ssize_t r = send(fd, p, n, MSG_NOSIGNAL);
        if (r >= 0) return (int)r;
        if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) return 0;
        return -1;
    }
    std::string error() override { return strerror(errno); }
};
}

// ───────── разбор ссылок и имён ─────────
static int hexv(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static std::string pct_decode(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); i++) {
        if (s[i] == '%' && i + 2 < s.size() && hexv(s[i + 1]) >= 0 && hexv(s[i + 2]) >= 0) {
            o += (char)(hexv(s[i + 1]) * 16 + hexv(s[i + 2]));
            i += 2;
        } else o += s[i];
    }
    return o;
}

static std::string enc_path(const std::string& s) {
    static const char* d = "0123456789ABCDEF";
    std::string o;
    for (unsigned char c : s) {
        if (c <= 0x20 || c >= 0x7F || c == '"' || c == '<' || c == '>' || c == '\\' || c == '^' || c == '`' || c == '{' || c == '|' || c == '}') {
            o += '%'; o += d[c >> 4]; o += d[c & 15];
        } else o += (char)c;
    }
    return o;
}

std::string ParsedUrl::hostport() const {
    int def = scheme == "https" ? 443 : 80;
    return port == def ? host : host + ":" + std::to_string(port);
}

bool urlfetch_parse(const std::string& in, ParsedUrl& u, std::string& err) {
    size_t a = 0, b = in.size();
    while (a < b && (unsigned char)in[a] <= 0x20) a++;
    while (b > a && (unsigned char)in[b - 1] <= 0x20) b--;
    std::string s = in.substr(a, b - a);
    if (s.empty()) { err = "Ссылка пустая"; return false; }
    if (lower(s.substr(0, 7)) == "magnet:") { err = "Magnet-ссылки не поддерживаются — нужна ссылка http:// или https:// на файл"; return false; }
    std::string scheme = "http", rest = s;
    size_t p = s.find("://");
    if (p != std::string::npos) { scheme = lower(s.substr(0, p)); rest = s.substr(p + 3); }
    if (scheme != "http" && scheme != "https") { err = "Поддерживаются только ссылки http:// и https://"; return false; }
    size_t h = rest.find('#');
    if (h != std::string::npos) rest.resize(h);
    size_t e = rest.find_first_of("/?");
    std::string auth = e == std::string::npos ? rest : rest.substr(0, e);
    std::string path = e == std::string::npos ? "/" : rest.substr(e);
    if (path[0] == '?') path = "/" + path;
    size_t at = auth.rfind('@');
    if (at != std::string::npos) auth = auth.substr(at + 1);
    if (!auth.empty() && auth[0] == '[') { err = "Адреса IPv6 не поддерживаются"; return false; }
    int port = scheme == "https" ? 443 : 80;
    std::string host = auth;
    size_t c = auth.rfind(':');
    if (c != std::string::npos) {
        host = auth.substr(0, c);
        std::string ps = auth.substr(c + 1);
        if (!ps.empty()) {
            for (char ch : ps) if (ch < '0' || ch > '9') { err = "Неверный порт в ссылке"; return false; }
            long v = ps.size() > 6 ? 0 : atol(ps.c_str());
            if (v < 1 || v > 65535) { err = "Неверный порт в ссылке"; return false; }
            port = (int)v;
        }
    }
    if (host.empty()) { err = "В ссылке нет адреса сервера"; return false; }
    for (unsigned char ch : host) {
        if (ch >= 0x80) { err = "Адрес сайта с не-латинскими буквами: введите его в виде xn--… (punycode)"; return false; }
        if (!((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || ch == '-' || ch == '.' || ch == '_')) {
            err = "В адресе сервера недопустимые символы"; return false;
        }
    }
    u.scheme = scheme; u.host = lower(host); u.port = port; u.path = enc_path(path);
    return true;
}

// Location → полная ссылка
static std::string resolve_location(const ParsedUrl& base, const std::string& loc0) {
    size_t a = 0, b = loc0.size();
    while (a < b && (unsigned char)loc0[a] <= 0x20) a++;
    while (b > a && (unsigned char)loc0[b - 1] <= 0x20) b--;
    std::string loc = loc0.substr(a, b - a);
    std::string l = lower(loc.substr(0, 8));
    if (l.compare(0, 7, "http://") == 0 || l.compare(0, 8, "https://") == 0) return loc;
    std::string origin = base.scheme + "://" + base.hostport();
    if (loc.compare(0, 2, "//") == 0) return base.scheme + ":" + loc;
    if (!loc.empty() && loc[0] == '/') return origin + loc;
    std::string dir = base.path;
    size_t q = dir.find_first_of("?#");
    if (q != std::string::npos) dir.resize(q);
    size_t sl = dir.rfind('/');
    dir = sl == std::string::npos ? "/" : dir.substr(0, sl + 1);
    if (!loc.empty() && loc[0] == '?') return origin + base.path.substr(0, base.path.find('?')) + loc;
    return origin + dir + loc;
}

std::string urlfetch_sanitize(const std::string& name) {
    std::string o;
    size_t i = 0;
    while (i < name.size()) {
        unsigned char c = (unsigned char)name[i];
        int len = c < 0x80 ? 1 : (c >> 5) == 6 ? 2 : (c >> 4) == 14 ? 3 : (c >> 3) == 30 ? 4 : 0;
        bool ok = len > 0 && i + len <= name.size() && !(len == 2 && c < 0xC2);
        for (int k = 1; ok && k < len; k++) if (((unsigned char)name[i + k] & 0xC0) != 0x80) ok = false;
        if (!ok) { o += '_'; i++; continue; }
        if (len == 1) {
            if (c < 0x20 || c == 0x7F || strchr("/\\:*?\"<>|", c)) o += '_';
            else o += (char)c;
        } else o.append(name, i, len);
        i += len;
    }
    size_t a = 0, b = o.size();
    while (a < b && (o[a] == ' ' || o[a] == '.')) a++;
    while (b > a && (o[b - 1] == ' ' || o[b - 1] == '.')) b--;
    o = o.substr(a, b - a);
    const size_t MAXN = 150;
    if (o.size() > MAXN) {
        size_t d = o.rfind('.');
        std::string ext = (d != std::string::npos && o.size() - d <= 12) ? o.substr(d) : std::string();
        size_t keep = MAXN - ext.size();
        while (keep > 0 && ((unsigned char)o[keep] & 0xC0) == 0x80) keep--;
        o = o.substr(0, keep) + ext;
    }
    return o;
}

std::string urlfetch_cd_name(const std::string& v) {
    std::string lv = lower(v);
    size_t p = lv.find("filename*=");
    if (p != std::string::npos) {
        size_t q = p + 10;
        size_t e = lv.find(';', q);
        std::string val = v.substr(q, e == std::string::npos ? std::string::npos : e - q);
        while (!val.empty() && (val.back() == ' ' || val.back() == '\t')) val.pop_back();
        size_t a1 = val.find('\'');
        size_t a2 = a1 == std::string::npos ? std::string::npos : val.find('\'', a1 + 1);
        if (a2 != std::string::npos) val = val.substr(a2 + 1);
        if (val.size() >= 2 && val.front() == '"' && val.back() == '"') val = val.substr(1, val.size() - 2);
        std::string r = pct_decode(val);
        if (!r.empty()) return r;
    }
    p = lv.find("filename=");
    if (p != std::string::npos) {
        size_t q = p + 9;
        while (q < v.size() && (v[q] == ' ' || v[q] == '\t')) q++;
        std::string r;
        if (q < v.size() && v[q] == '"') {
            for (q++; q < v.size() && v[q] != '"'; q++) {
                if (v[q] == '\\' && q + 1 < v.size()) q++;
                r += v[q];
            }
        } else {
            while (q < v.size() && v[q] != ';' && v[q] != ' ' && v[q] != '\t') r += v[q++];
        }
        return r;
    }
    return std::string();
}

static std::string unique_path(const std::string& dir, const std::string& name) {
    std::string p = dir + "/" + name;
    if (!file_exists(p)) return p;
    size_t d = name.rfind('.');
    std::string stem = name, ext;
    if (d != std::string::npos && d > 0 && name.size() - d <= 12) { stem = name.substr(0, d); ext = name.substr(d); }
    for (int i = 1; i < 1000; i++) {
        p = dir + "/" + stem + " (" + std::to_string(i) + ")" + ext;
        if (!file_exists(p)) return p;
    }
    return dir + "/" + name;
}

static std::string trim_ws(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && (s[a] == ' ' || s[a] == '\t')) a++;
    while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r')) b--;
    return s.substr(a, b - a);
}

// ───────── загрузка ─────────
UrlFetch::UrlFetch(const std::string& url, const std::string& download_dir, const std::string& torrent_dir)
    : in_url_(url), ddir_(download_dir), tdir_(torrent_dir) {
    while (ddir_.size() > 1 && ddir_.back() == '/') ddir_.pop_back();
    while (tdir_.size() > 1 && tdir_.back() == '/') tdir_.pop_back();
    cur_str_ = url;
}

UrlFetch::~UrlFetch() { cleanup(st_ != S_DONE); }

void UrlFetch::cleanup(bool remove_part) {
    delete ns_; ns_ = nullptr;
    if (fd_ >= 0) { close(fd_); fd_ = -1; }
    pfd_ = -1;
    if (out_) { fclose(out_); out_ = nullptr; }
    if (remove_part && !part_.empty()) remove(part_.c_str());
}

void UrlFetch::fail(const std::string& msg) {
    err_ = msg;
    st_ = S_FAILED;
    cleanup(true);
}

std::string UrlFetch::current_url() const { return cur_str_; }

std::string UrlFetch::status_text() const {
    switch (st_) {
    case S_START: case S_RESOLVE: return cur_.host.empty() ? std::string("Подготовка…") : "Поиск сервера " + cur_.host + "…";
    case S_CONNECT: return "Подключение к " + cur_.host + "…";
    case S_TLS: return "Защищённое соединение (TLS)…";
    case S_SEND: case S_HEADERS: return "Ожидание ответа сервера…";
    case S_BODY: return "Скачивание";
    case S_DONE: return "Готово";
    case S_FAILED: return err_;
    }
    return "";
}

void UrlFetch::tick(uint64_t now) {
    now_ = now;
    switch (st_) {
    case S_START: begin(now); break;
    case S_RESOLVE: do_resolve(now); break;
    case S_CONNECT: do_connect(now); break;
    case S_TLS: do_tls(now); break;
    case S_SEND: do_send(now); if (st_ == S_HEADERS) do_headers(now); break;
    case S_HEADERS: do_headers(now); break;
    case S_BODY: do_body(now); break;
    default: break;
    }
}

void UrlFetch::begin(uint64_t now) {
    std::string e;
    if (!urlfetch_parse(cur_str_, cur_, e)) { fail(e); return; }
    delete ns_; ns_ = nullptr;
    if (fd_ >= 0) { close(fd_); fd_ = -1; }
    pfd_ = -1;
    hbuf_.clear(); sent_ = 0; req_.clear();
    has_len_ = chunked_ = body_done_ = false; len_ = 0; csz_ = 0; cs_ = C_SIZE; line_.clear(); ctype_.clear();
    st_ = S_RESOLVE; t_state_ = now; t_data_ = now;
}

static bool resolve4(const std::string& host, uint16_t port, sockaddr_in& out) {
    memset(&out, 0, sizeof out);
    out.sin_family = AF_INET; out.sin_port = htons(port);
    if (inet_pton(AF_INET, host.c_str(), &out.sin_addr) == 1) return true;
    struct addrinfo hints; memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_INET; hints.ai_socktype = SOCK_STREAM;
    struct addrinfo* res = nullptr;
    if (getaddrinfo(host.c_str(), nullptr, &hints, &res) != 0 || !res) return false;
    out.sin_addr = ((sockaddr_in*)res->ai_addr)->sin_addr;
    freeaddrinfo(res);
    return true;
}

void UrlFetch::do_resolve(uint64_t now) {
    sockaddr_in addr;
    if (!resolve4(cur_.host, (uint16_t)cur_.port, addr)) { fail("Не удалось найти сервер " + cur_.host + " (нет сети или неверный адрес)"); return; }
    fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (fd_ < 0) { fail("Не удалось открыть сетевое соединение"); return; }
    if (fcntl(fd_, F_SETFL, O_NONBLOCK) != 0) { fail("Не удалось настроить сетевое соединение"); return; }
    int r = connect(fd_, (sockaddr*)&addr, sizeof addr);
    if (r != 0 && errno != EINPROGRESS && errno != EAGAIN && errno != EWOULDBLOCK) { fail("Нет соединения с сервером " + cur_.host); return; }
    st_ = S_CONNECT; t_state_ = now;
}

void UrlFetch::do_connect(uint64_t now) {
    pollfd pf{fd_, POLLOUT, 0};
    if (poll(&pf, 1, 4) > 0) {
        int e = 0; socklen_t l = sizeof e;
        getsockopt(fd_, SOL_SOCKET, SO_ERROR, &e, &l);
        if (e || (pf.revents & (POLLERR | POLLHUP))) { fail("Сервер " + cur_.host + " не принимает соединение"); return; }
        if (cur_.scheme == "https") {
            if (!g_tls) { fail("HTTPS недоступен в этой сборке — используйте ссылку http://"); return; }
            st_ = S_TLS; t_state_ = now;
        } else {
            ns_ = new TcpStream(fd_); pfd_ = fd_; fd_ = -1;
            st_ = S_SEND; t_state_ = now;
        }
        return;
    }
    if (now - t_state_ > CONNECT_T) fail("Сервер " + cur_.host + " не отвечает на подключение");
}

void UrlFetch::do_tls(uint64_t now) {
    std::string e;
    ns_ = g_tls(fd_, cur_.host, e);               // блокирующее рукопожатие (обычно доли секунды)
    if (!ns_) { fail(e.empty() ? "Не удалось установить защищённое соединение" : e); return; }
    pfd_ = fd_; fd_ = -1;
    st_ = S_SEND; t_state_ = now;
}

void UrlFetch::do_send(uint64_t now) {
    if (req_.empty()) {
        req_ = "GET " + cur_.path + " HTTP/1.1\r\nHost: " + cur_.hostport() +
               "\r\nUser-Agent: archive_nintendo/1.0\r\nAccept: */*\r\nAccept-Encoding: identity\r\nConnection: close\r\n\r\n";
    }
    while (sent_ < req_.size()) {
        int w = ns_->write((const uint8_t*)req_.data() + sent_, req_.size() - sent_);
        if (w < 0) { fail("Ошибка отправки запроса: " + ns_->error()); return; }
        if (w == 0) break;
        sent_ += (size_t)w;
    }
    if (sent_ >= req_.size()) { st_ = S_HEADERS; t_state_ = now; t_data_ = now; return; }
    if (now - t_state_ > CONNECT_T) fail("Сервер не принимает запрос");
}

void UrlFetch::wait_readable(int ms) {
    if (pfd_ < 0) return;
    pollfd p{pfd_, POLLIN, 0};
    poll(&p, 1, ms);
}

void UrlFetch::do_headers(uint64_t now) {
    if (rb_.empty()) rb_.resize(65536);
    for (;;) {
        size_t he = hbuf_.find("\r\n\r\n");
        if (he != std::string::npos) {
            if (!on_headers(he + 4)) return;
            if (st_ != S_HEADERS) return;
            continue;                                          // 1xx: ждём настоящий ответ
        }
        if (hbuf_.size() > 65536) { fail("Слишком длинный ответ сервера (это не HTTP?)"); return; }
        int r = ns_->read(rb_.data(), 16384);
        if (r > 0) { hbuf_.append((const char*)rb_.data(), (size_t)r); t_data_ = now; continue; }
        if (r == NetStream::NS_WOULDBLOCK) {
            if (now - t_data_ > HEADERS_T) { fail("Сервер не отвечает на запрос"); return; }
            wait_readable(4);
            return;
        }
        if (r == NetStream::NS_CLOSED) { fail("Сервер закрыл соединение, ничего не ответив"); return; }
        fail("Ошибка чтения ответа: " + ns_->error());
        return;
    }
}

bool UrlFetch::on_headers(size_t hend) {
    std::string head = hbuf_.substr(0, hend);
    std::string rest = hbuf_.substr(hend);
    hbuf_.clear();
    size_t le = head.find("\r\n");
    std::string status = head.substr(0, le);
    if (status.compare(0, 5, "HTTP/") != 0) { fail("Это не HTTP-сервер (неожиданный ответ)"); return false; }
    size_t sp = status.find(' ');
    int code = sp == std::string::npos ? 0 : atoi(status.c_str() + sp + 1);
    if (code < 100 || code > 599) { fail("Неверный ответ сервера: " + status.substr(0, 60)); return false; }
    if (code >= 100 && code < 200) { hbuf_ = rest; return true; }
    // заголовки
    std::string location, cd, te;
    bool have_len = false; uint64_t clen = 0;
    size_t pos = le == std::string::npos ? head.size() : le + 2;
    while (pos < head.size()) {
        size_t e = head.find("\r\n", pos);
        if (e == std::string::npos) e = head.size();
        std::string ln = head.substr(pos, e - pos);
        pos = e + 2;
        size_t c = ln.find(':');
        if (c == std::string::npos) continue;
        std::string k = lower(ln.substr(0, c)), v = trim_ws(ln.substr(c + 1));
        if (k == "location") location = v;
        else if (k == "content-disposition") cd = v;
        else if (k == "content-type") ctype_ = lower(v);
        else if (k == "transfer-encoding") te = lower(v);
        else if (k == "content-length") {
            bool ok = !v.empty() && v.size() < 20;
            for (char ch : v) if (ch < '0' || ch > '9') ok = false;
            if (ok) { have_len = true; clen = strtoull(v.c_str(), nullptr, 10); }
        }
    }
    if (code == 301 || code == 302 || code == 303 || code == 307 || code == 308) {
        if (location.empty()) { fail("Сервер перенаправил, но не сказал куда"); return false; }
        if (++redirects_ > MAX_REDIRECTS) { fail("Слишком много перенаправлений"); return false; }
        cur_str_ = resolve_location(cur_, location);
        delete ns_; ns_ = nullptr; pfd_ = -1;
        st_ = S_START;
        return true;
    }
    if (code != 200) {
        std::string t = trim_ws(sp == std::string::npos ? std::string() : status.substr(sp + 1));
        std::string hint;
        if (code == 403 || code == 401) hint = " — доступ запрещён";
        else if (code == 404 || code == 410) hint = " — файл не найден";
        else if (code >= 500) hint = " — ошибка на стороне сервера";
        fail("Сервер ответил: " + t.substr(0, 60) + hint);
        return false;
    }
    chunked_ = te.find("chunked") != std::string::npos;
    has_len_ = have_len && !chunked_;
    len_ = has_len_ ? clen : 0;
    // имя файла: заголовок → последняя часть пути ссылки
    std::string nm = urlfetch_sanitize(urlfetch_cd_name(cd));
    if (nm.empty()) {
        std::string pth = cur_.path;
        size_t q = pth.find_first_of("?#");
        if (q != std::string::npos) pth.resize(q);
        size_t sl = pth.rfind('/');
        nm = urlfetch_sanitize(pct_decode(sl == std::string::npos ? pth : pth.substr(sl + 1)));
    }
    torrent_ = ends_with_ci(nm, ".torrent") || ctype_.find("x-bittorrent") != std::string::npos;
    if (nm.empty()) nm = torrent_ ? "download.torrent" : "download.bin";
    if (torrent_ && !ends_with_ci(nm, ".torrent")) nm += ".torrent";
    name_ = nm;
    if (!open_output()) return false;
    st_ = S_BODY; t_data_ = now_; sp_t_ = now_; sp_b_ = 0;
    if (has_len_ && len_ == 0) { complete(); return true; }
    if (!rest.empty()) {
        if (!feed_body((const uint8_t*)rest.data(), rest.size())) return false;
        if (body_done_) complete();
    }
    return true;
}

bool UrlFetch::open_output() {
    const std::string& dir = torrent_ ? tdir_ : ddir_;
    mkdirs(dir);
    final_ = unique_path(dir, name_);
    part_ = final_ + ".part";
    if (has_len_ && free_fn_) {
        int64_t fr = free_fn_();
        const uint64_t margin = 64ull << 20;
        if (fr >= 0 && len_ + margin > (uint64_t)fr) {
            part_.clear();
            fail("Не хватает места на SD: нужно " + human_size((double)len_) + ", свободно " + human_size((double)fr));
            return false;
        }
    }
    out_ = fopen(part_.c_str(), "wb");
    if (!out_) { part_.clear(); fail("Не удалось создать файл на SD-карте: " + name_); return false; }
    setvbuf(out_, nullptr, _IOFBF, 131072);
    return true;
}

bool UrlFetch::write_out(const uint8_t* p, size_t n) {
    if (n == 0) return true;
    if (fwrite(p, 1, n, out_) != n) {
        fail("Ошибка записи на SD-карту (нет места или файл больше 4 ГБ на карте FAT32)");
        return false;
    }
    got_ += n;
    return true;
}

bool UrlFetch::feed_body(const uint8_t* p, size_t n) {
    if (!chunked_) {
        size_t take = n;
        if (has_len_ && got_ + take > len_) take = (size_t)(len_ - got_);
        if (!write_out(p, take)) return false;
        if (has_len_ && got_ >= len_) body_done_ = true;
        return true;
    }
    size_t i = 0;
    while (i < n && !body_done_) {
        switch (cs_) {
        case C_SIZE: {
            char c = (char)p[i++];
            if (c == '\n') {
                size_t sc = line_.find(';');
                std::string h = trim_ws(sc == std::string::npos ? line_ : line_.substr(0, sc));
                if (h.empty() || h.size() > 16) { fail("Сервер прислал неверные данные (chunked)"); return false; }
                uint64_t v = 0;
                for (char ch : h) {
                    int x = hexv(ch);
                    if (x < 0) { fail("Сервер прислал неверные данные (chunked)"); return false; }
                    v = v * 16 + (uint64_t)x;
                }
                line_.clear();
                csz_ = v;
                cs_ = v == 0 ? C_TRAILER : C_DATA;
            } else {
                line_ += c;
                if (line_.size() > 256) { fail("Сервер прислал неверные данные (chunked)"); return false; }
            }
            break;
        }
        case C_DATA: {
            size_t take = (size_t)std::min<uint64_t>(n - i, csz_);
            if (!write_out(p + i, take)) return false;
            i += take; csz_ -= take;
            if (csz_ == 0) cs_ = C_CRLF;
            break;
        }
        case C_CRLF: {
            char c = (char)p[i++];
            if (c == '\n') cs_ = C_SIZE;
            else if (c != '\r') { fail("Сервер прислал неверные данные (chunked)"); return false; }
            break;
        }
        case C_TRAILER: {
            char c = (char)p[i++];
            if (c == '\n') {
                if (trim_ws(line_).empty()) body_done_ = true;
                line_.clear();
            } else {
                line_ += c;
                if (line_.size() > 4096) line_.clear();
            }
            break;
        }
        }
    }
    return true;
}

void UrlFetch::complete() {
    if (out_) {
        int rc = fclose(out_); out_ = nullptr;
        if (rc != 0) { fail("Ошибка записи на SD-карту при завершении файла"); return; }
    }
    if (rename(part_.c_str(), final_.c_str()) != 0) {
        remove(final_.c_str());
        if (rename(part_.c_str(), final_.c_str()) != 0) { fail("Не удалось сохранить файл: " + name_); return; }
    }
    part_.clear();
    delete ns_; ns_ = nullptr; pfd_ = -1;
    st_ = S_DONE;
}

void UrlFetch::do_body(uint64_t now) {
    if (rb_.empty()) rb_.resize(65536);
    size_t budget = 1u << 20;
    bool any = false;
    while (budget > 0 && st_ == S_BODY) {
        int r = ns_->read(rb_.data(), rb_.size());
        if (r > 0) {
            any = true;
            budget -= std::min(budget, (size_t)r);
            if (!feed_body(rb_.data(), (size_t)r)) return;
            if (body_done_) { complete(); return; }
        } else if (r == NetStream::NS_WOULDBLOCK) {
            break;
        } else if (r == NetStream::NS_CLOSED) {
            if (chunked_ && !body_done_) fail("Соединение оборвано до конца файла");
            else if (has_len_ && got_ < len_) fail("Соединение оборвано: получено " + human_size((double)got_) + " из " + human_size((double)len_));
            else complete();
            return;
        } else {
            fail("Ошибка чтения: " + ns_->error());
            return;
        }
    }
    if (any) t_data_ = now;
    if (now - sp_t_ >= 400) {
        double inst = (double)(got_ - sp_b_) * 1000.0 / (double)(now - sp_t_);
        speed_ = speed_ <= 0 ? inst : speed_ * 0.5 + inst * 0.5;
        sp_t_ = now; sp_b_ = got_;
    }
    if (!any) {
        if (now - t_data_ > BODY_T) fail("Сервер перестал отвечать (нет данных " + std::to_string(BODY_T / 1000) + " с)");
        else wait_readable(4);
    }
}
