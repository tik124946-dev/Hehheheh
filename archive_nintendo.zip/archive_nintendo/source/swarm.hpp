#pragma once
#include <stdint.h>
#include <string>
#include <vector>
#include <functional>
#include <memory>
#include "meta.hpp"
#include "sink.hpp"

// Однопоточный BitTorrent-клиент (только скачивание), отдающий данные потоком по порядку.
// Куски лежат в оперативной памяти окном (mem_cap), после проверки SHA-1 сразу уходят в Sink
// и память освобождается — на SD-карте торрент целиком никогда не оказывается.
class Swarm {
public:
    Swarm(const Meta& m, Sink* sink, uint64_t start_pos, uint64_t mem_cap);   // start_pos — абсолютное смещение в потоке торрента
    ~Swarm();
    void tick(uint64_t now);          // одна порция работы (до ~10 мс ожидания в poll)
    void stop();

    bool finished() const { return finished_; }
    bool failed() const { return failed_; }
    const std::string& error() const { return error_; }

    uint64_t downloaded_abs() const;  // проверенные байты (абсолютная позиция в потоке торрента)
    uint64_t received_bytes() const { return bytes_in_; }   // принято по сети (для статистики)
    uint64_t consumed_bytes() const { return fed_pos_; }   // уже переданные Sink (установленные)
    uint64_t buffered_bytes() const;  // лежит в памяти, ещё не передано
    double speed() const { return speed_; }
    int peers_active() const;
    int peers_known() const { return (int)cands_.size(); }
    size_t cur_file() const { return cur_; }
    uint64_t last_progress() const { return last_progress_; }
    void set_file_done_cb(std::function<void(size_t)> cb) { file_cb_ = cb; }
    void add_peer(uint32_t ip_host_order, uint16_t port);
    std::string status_text() const { return status_; }
    // Диагностика для экрана: что делают трекеры и пиры (две строки)
    std::string diag_trackers() const;
    std::string diag_peers() const;
    int unchoked_peers() const;

private:
    struct Slot {
        bool active = false, done = false;
        uint32_t idx = 0, nb = 0, ngot = 0, hint = 0;
        int fails = 0;
        std::vector<uint8_t> buf, st;
        std::vector<uint32_t> bpeer;
        std::vector<uint8_t> dup;        // сколько раз блок запрошен повторно (у другого пира)
        std::vector<uint32_t> rt;        // когда блок запросили первый раз (мс, младшие 32 бита)
    };
    struct Req { uint32_t piece, block; uint64_t t; };
    struct Peer {
        int fd = -1;
        uint32_t id = 0, cand = 0;
        enum { CONNECTING, HANDSHAKE, ACTIVE, DEAD } state = CONNECTING;
        bool choked = true, sent_interested = false, got_data = false;
        std::vector<uint8_t> bits;
        std::vector<uint8_t> rbuf; size_t rpos = 0;
        std::vector<uint8_t> wbuf; size_t wpos = 0;
        uint64_t t_start = 0, t_recv = 0, t_send = 0, t_choke = 0;
        uint64_t rate = 0, rate_bytes = 0, rate_t = 0, t_steal = 0;   // скорость пира (байт/с) и его «перехват» зависших блоков
        std::vector<Req> reqs;
        bool has(size_t i) const { return (i >> 3) < bits.size() && (bits[i >> 3] & (0x80 >> (i & 7))); }
    };
    struct Cand { uint32_t ip; uint16_t port; int fails = 0; uint64_t next_try = 0; bool live = false, banned = false; };
    struct Tracker;                    // определено в .cpp
    struct TrkOp;

    // состояние
    const Meta& m_;
    Sink* sink_;
    uint64_t mem_cap_;
    size_t W_ = 2;
    size_t start_piece_ = 0, next_ = 0;
    uint64_t first_pos_ = 0, fed_pos_ = 0, verified_ = 0;
    size_t cur_ = 0; bool opened_ = false;
    std::vector<Slot> slots_;
    std::vector<std::unique_ptr<Peer>> peers_;
    std::vector<Cand> cands_;
    std::vector<std::unique_ptr<Tracker>> trk_;
    std::vector<std::unique_ptr<TrkOp>> ops_;
    uint32_t next_peer_id_ = 1;
    uint8_t peer_id_[20];
    bool finished_ = false, failed_ = false, stopped_ = false;
    std::string error_, status_;
    uint64_t last_progress_ = 0, bytes_in_ = 0, t0_ = 0;
    std::vector<std::pair<uint64_t, uint64_t>> samples_;
    double speed_ = 0;
    std::function<void(size_t)> file_cb_;
    uint64_t last_kick_ = 0;
    bool seeked_ = false;
    // счётчики для диагностики
    int unsup_ = 0;                    // трекеров с неподдерживаемой схемой (https, ...)
    std::string unsup_schemes_;
    int n_conn_try_ = 0, n_conn_fail_ = 0, n_hs_ok_ = 0, n_hs_fail_ = 0, n_nodata_ = 0, n_dns_fail_ = 0, n_sock_fail_ = 0;
    int last_sock_errno_ = 0;

    // реализация
    void fail(const std::string& e);
    Slot& slot_for(size_t idx) { return slots_[idx % W_]; }
    bool slot_alloc(size_t idx);
    void deliver(uint64_t now);
    bool feed(const uint8_t* data, uint64_t pstart, uint64_t n);
    void do_seek(uint64_t abs);
    void on_block(Peer& p, uint32_t piece, uint32_t begin, const uint8_t* d, size_t n, uint64_t now);
    void release_block(uint32_t piece, uint32_t block);
    void release_peer_reqs(Peer& p);
    void verify_piece(Slot& s, uint64_t now);
    void fill_requests(Peer& p, uint64_t now);
    size_t qmax_for(const Peer& p) const;
    void cancel_dups(uint32_t from_id, uint32_t piece, uint32_t block);
    bool handle_peer_data(Peer& p, uint64_t now);
    bool handle_msg(Peer& p, const uint8_t* b, size_t n, uint64_t now);
    bool peer_send(Peer& p);
    void drop_peer(Peer& p, bool good);
    void connect_more(uint64_t now);
    void trackers_tick(uint64_t now);
    void update_speed(uint64_t now);
    friend struct TrkOp;
};
