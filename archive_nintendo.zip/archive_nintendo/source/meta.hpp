#pragma once
#include <stdint.h>
#include <string>
#include <vector>

struct TFile {
    std::string path;     // относительный путь внутри торрента (с '/'), уже очищенный
    uint64_t off = 0;     // смещение в потоке торрента
    uint64_t len = 0;
    bool pad = false;     // BEP-47 pad-файл
};

struct Meta {
    std::string name;
    uint64_t plen = 0, total = 0;
    size_t npieces = 0;
    bool multi = false;
    std::vector<TFile> files;
    std::vector<uint8_t> hashes;                 // 20 байт на кусок
    uint8_t infohash[20];
    std::vector<std::string> trackers;

    static bool load(const std::string& path, Meta& m, std::string& err);
    uint64_t piece_len(size_t idx) const {
        uint64_t s = (uint64_t)idx * plen;
        return s + plen <= total ? plen : total - s;
    }
};

// Делает безопасный относительный путь: без "..", без запрещённых для FAT символов.
std::string sanitize_rel_path(const std::string& p);
