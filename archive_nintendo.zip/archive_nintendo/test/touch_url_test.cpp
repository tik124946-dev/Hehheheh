// Тест окна «Скачать по ссылке» и управления касанием: нажатия по нарисованным кнопкам, перетаскивание списка,
// пробуждение экрана касанием, скачивание по ссылке (мок-сервер) в разных режимах.
#include "../source/app.hpp"
#include "../source/util.hpp"
#include "host_platform.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

static std::string slurp(const std::string& p) {
    std::vector<uint8_t> v;
    if (!read_file(p, v, 1u << 30)) return "<нет файла>";
    return std::string(v.begin(), v.end());
}

int main(int argc, char** argv) {
    std::string root = argc > 1 ? argv[1] : "/tmp/anq/root2/";
    std::string mock = argc > 2 ? argv[2] : "/tmp/anq/mock";
    std::string shots = argc > 3 ? argv[3] : "/tmp/anq/shots2";
    mkdirs(shots);
    HostPlatform pf(root);
    App app(&pf);
    app.init();
    Gfx g;
    uint64_t now = now_ms();
    auto shot = [&](const char* n) { now = now_ms(); app.draw(g, now); g.save_ppm(shots + "/" + n + ".ppm"); };
    auto frames = [&](int ms) { uint64_t t0 = now_ms(); while (now_ms() - t0 < (uint64_t)ms) { now = now_ms(); app.frame(0, now); } };
    auto until = [&](auto pred, int ms) { uint64_t t0 = now_ms(); while (!pred() && now_ms() - t0 < (uint64_t)ms) { now = now_ms(); app.frame(0, now); } return pred(); };
    // «нажатие пальцем»: сначала отрисовка (по ней строятся области касания), потом касание и отпускание
    auto tap = [&](int x, int y) { now = now_ms(); app.draw(g, now); app.touch(x, y, 0, now); app.touch(x, y, 2, now); };

    // порт мок-сервера
    Meta m; std::string e;
    if (!Meta::load(mock + "/torrents/a_mocktest.torrent", m, e)) { printf("нет торрента\n"); return 2; }
    std::string base = "http://127.0.0.1:" + std::to_string(atoi(m.trackers[0].c_str() + strlen("http://127.0.0.1:"))) + "/dl/";
    std::string single = slurp(mock + "/payload/single.bin");
    std::string dd = root + "archive_nintendo/downloads/";

    printf("== вкладки и строки касанием\n");
    app.frame(0, now_ms());
    shot("t1_start");
    tap(60, 64 + 16 + 66 + 20);                                        // вкладка «Загрузки»
    CHECK(app.tab() == 1);
    tap(60, 64 + 16 + 20);                                             // «Установленные»
    CHECK(app.tab() == 0);
    tap(60, 64 + 16 + 132 + 20);                                       // «Торренты»
    CHECK(app.tab() == 2);
    tap(400, 64 + 14 + 28 + 58 + 20);                                  // вторая строка: выбирается, окно не открывается
    CHECK(app.selected(2) == 1 && !app.dialog_open());
    tap(400, 64 + 14 + 28 + 58 + 20);                                  // повторное касание — как A
    CHECK(app.dialog_open());
    shot("t2_dialog");
    tap(300, 40);                                                      // мимо окна — ничего (вкладки за окном не нажимаются)
    CHECK(app.dialog_open() && app.tab() == 2);
    // «Отмена» — третий пункт окна
    tap(500, 64 + 42 + 92 + 116 * 2 + 20);
    CHECK(!app.dialog_open() && !app.job_running());

    printf("== перетаскивание списка\n");
    now = now_ms(); app.draw(g, now);
    app.touch(700, 400, 0, now); app.touch(700, 340, 1, now); app.touch(700, 280, 1, now); app.touch(700, 230, 1, now); app.touch(700, 230, 2, now);
    CHECK(app.selected(2) >= 4 && !app.dialog_open());                  // 1 + три шага вниз
    printf("  выбрана строка %d\n", app.selected(2));
    now = now_ms(); app.draw(g, now);
    app.touch(700, 230, 0, now); app.touch(700, 400, 1, now); app.touch(700, 520, 1, now); app.touch(700, 520, 2, now);
    CHECK(app.selected(2) == 0);

    printf("== скачивание торрента с выбором «в папку» касанием\n");
    tap(400, 64 + 14 + 28 + 20);                                       // строка 0 (a_mocktest) — выбрана, значит откроется окно
    CHECK(app.dialog_open());
    tap(500, 64 + 42 + 92 + 116 + 30);                                 // «Положить в папку»
    CHECK(!app.dialog_open() && app.job_running());
    CHECK(until([&] { return !app.job_running(); }, 30000));
    CHECK(slurp(dd + "mocktest/a/one.bin") != "<нет файла>" && file_exists(dd + "mocktest/c/d/three.bin"));
    shot("t3_after_raw");

    printf("== Скачать по ссылке: клавиша Y\n");
    pf.kb_text = base + "plain.bin";
    app.frame(K_Y, now_ms());
    CHECK(pf.kb_calls == 1 && pf.kb_header.find("Ссылка") != std::string::npos && app.url_open() && app.fetching());
    CHECK(until([&] { return !app.fetching() || app.fetch()->state() == UrlFetch::S_BODY; }, 5000));
    CHECK(until([&] { return app.fetch() == nullptr; }, 15000));
    CHECK(!app.url_open() && slurp(dd + "plain.bin") == single);
    printf("  скачано plain.bin\n");
    // повторно с тем же URL — клавиатура получает прошлую ссылку
    pf.kb_text = base + "cd2";
    app.frame(K_Y, now_ms());
    CHECK(pf.kb_initial == base + "plain.bin");
    CHECK(until([&] { return app.fetch() == nullptr; }, 15000));
    CHECK(slurp(dd + "Игра №1.bin") == single);

    printf("== Отмена клавиатуры и ошибка клавиатуры\n");
    pf.kb_cancel = true; app.frame(K_Y, now_ms()); CHECK(!app.url_open() && app.fetch() == nullptr);
    pf.kb_cancel = false; pf.kb_text = "   "; app.frame(K_Y, now_ms()); CHECK(app.fetch() == nullptr);
    pf.kb_err = "Клавиатура не открылась"; app.frame(K_Y, now_ms()); CHECK(app.fetch() == nullptr); pf.kb_err.clear();

    printf("== ошибка, «Повторить», «Закрыть» касанием\n");
    pf.kb_text = base + "missing";
    app.frame(K_Y, now_ms());
    CHECK(until([&] { return app.fetch() && app.fetch()->failed(); }, 8000));
    CHECK(app.url_open());
    shot("t4_url_failed");
    // кнопки окна: «Повторить (A)» слева, «Закрыть (B)» справа внизу
    tap(640 + 400 - 24 - 40, 150 + 380 - 62 + 19);                     // «Закрыть»
    CHECK(app.fetch() == nullptr && !app.url_open());
    app.frame(K_Y, now_ms());                                          // тот же адрес снова
    CHECK(until([&] { return app.fetch() && app.fetch()->failed(); }, 8000));
    app.frame(K_A, now_ms());                                          // «Повторить» — новая попытка (снова 404)
    CHECK(app.fetch() != nullptr && app.url_open());
    CHECK(until([&] { return app.fetch() && app.fetch()->failed(); }, 8000));
    app.frame(K_B, now_ms()); CHECK(app.fetch() == nullptr);

    printf("== скачивание в фоне: свернуть, открыть, дождаться\n");
    pf.kb_text = base + "slow.bin";
    app.frame(K_Y, now_ms());
    CHECK(until([&] { return app.fetch() && app.fetch()->state() == UrlFetch::S_BODY && app.fetch()->downloaded() > 200000; }, 8000));
    shot("t5_url_active");
    app.frame(K_X, now_ms());                                          // свернуть
    CHECK(!app.url_open() && app.fetching() && pf.awake);
    frames(300);
    shot("t6_url_background");
    app.frame(K_Y, now_ms());                                          // снова показать
    CHECK(app.url_open());
    // отмена — только после повторного нажатия B
    app.frame(K_B, now_ms()); CHECK(app.fetch() != nullptr);
    shot("t7_url_cancel_confirm");
    app.frame(K_B, now_ms()); CHECK(app.fetch() == nullptr && !app.url_open());
    CHECK(!file_exists(dd + "slow.bin") && !file_exists(dd + "slow.bin.part"));
    CHECK(until([&] { return !pf.awake; }, 2000));

    printf("== свёрнутая загрузка доходит до конца сама\n");
    app.frame(K_Y, now_ms());
    CHECK(until([&] { return app.fetch() && app.fetch()->state() == UrlFetch::S_BODY; }, 8000));
    app.frame(K_X, now_ms());
    CHECK(until([&] { return app.fetch() == nullptr; }, 20000));
    CHECK(file_exists(dd + "slow.bin") && !app.url_open());

    printf("== .torrent по ссылке → папка торрентов → окно выбора\n");
    pf.kb_text = base + "get?id=7";                                    // отдаёт b_single.torrent
    app.frame(K_Y, now_ms());
    CHECK(until([&] { return app.fetch() == nullptr; }, 10000));
    CHECK(app.tab() == 2 && app.dialog_open() && file_exists(root + "archive_nintendo/torrents/get.torrent"));
    shot("t8_torrent_dialog");
    tap(500, 64 + 42 + 92 + 30);                                       // «Автоустановка»
    CHECK(app.job_running());
    CHECK(until([&] { return !app.job_running(); }, 20000));
    CHECK(file_exists(dd + "single.bin") || file_exists(dd + "single.bin/single.bin"));

    printf("== вкладка URL: ввод, история, «скачать снова», сохранение списка\n");
    CHECK(app.url_history() == 4);                                     // plain, cd2, slow, get?id=7
    tap(60, 64 + 16 + 3 * 66 + 20);
    CHECK(app.tab() == 3);
    shot("t9_urltab");
    pf.kb_text = base + "chunked.bin"; int kc = pf.kb_calls;
    tap(500, 64 + 14 + 28 + 30);                                       // строка «Ввести ссылку…» — срабатывает с первого касания
    CHECK(pf.kb_calls == kc + 1 && app.fetching());
    CHECK(until([&] { return app.fetch() == nullptr; }, 15000));
    CHECK(app.url_history() == 5 && slurp(dd + "chunked.bin") == single);
    app.frame(K_Y, now_ms());                                          // та же ссылка из клавиатуры ещё раз
    CHECK(until([&] { return app.fetch() == nullptr; }, 15000));
    CHECK(app.url_history() == 5);                                     // та же ссылка — запись не дублируется
    app.frame(K_DOWN, now_ms());
    CHECK(app.selected(3) == 1);
    shot("t9_urltab_rows");
    kc = pf.kb_calls;
    tap(500, 64 + 14 + 28 + 94 + 20);                                  // первая строка истории: выбрана (уже выбрана → сразу «скачать снова»)
    CHECK(app.fetching() && pf.kb_calls == kc);                        // без клавиатуры
    shot("t9_urltab_busy");
    CHECK(until([&] { return app.fetch() == nullptr; }, 20000));
    app.frame(K_X, now_ms()); CHECK(app.url_history() == 5);           // первое нажатие X только просит подтвердить
    app.frame(K_X, now_ms()); CHECK(app.url_history() == 4);
    {   // список переживает перезапуск
        App again(&pf); again.init();
        CHECK(again.url_history() == 4);
    }
    app.frame(K_R, now_ms()); CHECK(app.tab() == 0);
    app.frame(K_L, now_ms()); CHECK(app.tab() == 3);
    app.frame(K_Y, now_ms());
    CHECK(until([&] { return app.fetch() == nullptr; }, 15000));

    printf("== касание будит чёрный экран и ничего не нажимает\n");
    app.select_tab(2);
    app.stall_limit_ms = 1200;
    now = now_ms(); app.draw(g, now);
    // b_dead.torrent — трекер не отвечает
    int dead = -1; for (int i = 0; i < 12; i++) { tap(400, 64 + 14 + 28 + 20); (void)i; break; }
    (void)dead;
    // выберем b_dead по клавишам: он второй в списке
    app.select_tab(2);
    app.frame(K_DOWN, now_ms()); app.frame(K_A, now_ms()); app.frame(K_A, now_ms());
    CHECK(app.job_running());
    CHECK(until([&] { return app.screen_off(); }, 6000));
    int sel_before = app.selected(2);
    now = now_ms(); app.draw(g, now);
    app.touch(400, 200, 0, now);
    CHECK(!app.screen_off() && pf.backlight_on);
    app.touch(400, 200, 2, now_ms());
    CHECK(!app.dialog_open() && app.selected(2) == sel_before);       // первое касание только будит
    tap(60, 64 + 16 + 66 + 20);                                        // а следующее — уже работает
    CHECK(app.tab() == 1);

    printf(fails ? "ТАЧ/URL: НЕУДАЧА (%d)\n" : "ТАЧ/URL: ВСЁ ОК\n", fails);
    return fails != 0;
}
