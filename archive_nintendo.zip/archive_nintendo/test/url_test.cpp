// Тест загрузки по ссылке: локальный HTTP-сервер из mock_swarm.py (маршруты /dl/…)
#include "../source/urlfetch.hpp"
#include "../source/meta.hpp"
#include "../source/util.hpp"
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <unistd.h>
#include <memory>
#include <algorithm>
#include <stdlib.h>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

static std::string slurp(const std::string& p) {
    std::vector<uint8_t> v;
    if (!read_file(p, v, 1u << 30)) return "<нет файла>";
    return std::string(v.begin(), v.end());
}

// Заглушка «TLS»: тот же TCP, но через общий хук — проверяем, что https идёт через него и что хост передаётся
static int tls_calls = 0;
static std::string tls_host;
namespace {
struct FakeTls : NetStream {
    int fd;
    explicit FakeTls(int f) : fd(f) {}
    ~FakeTls() override { close(fd); }
    int read(uint8_t* p, size_t n) override {
        ssize_t r = recv(fd, p, n, 0);
        if (r > 0) return (int)r;
        if (r == 0) return NS_CLOSED;
        return (errno == EAGAIN || errno == EWOULDBLOCK) ? NS_WOULDBLOCK : NS_FAILED;
    }
    int write(const uint8_t* p, size_t n) override {
        ssize_t r = send(fd, p, n, 0);
        if (r >= 0) return (int)r;
        return (errno == EAGAIN || errno == EWOULDBLOCK) ? 0 : -1;
    }
};
}
static NetStream* fake_tls(int fd, const std::string& host, std::string&) { tls_calls++; tls_host = host; return new FakeTls(fd); }

struct Run { bool ok; std::string err, path, name; bool torrent; int redirects; uint64_t got; };
static Run run(const std::string& url, const std::string& dd, const std::string& td, uint64_t cancel_after = 0, int64_t free_b = -1) {
    UrlFetch f(url, dd, td);
    if (free_b >= 0) f.set_free_fn([free_b]() { return free_b; });
    uint64_t t0 = now_ms();
    int seen_states = 0; (void)seen_states;
    while (!f.finished() && !f.failed() && now_ms() - t0 < 20000) {
        f.tick(now_ms());
        if (cancel_after && f.downloaded() >= cancel_after) break;
    }
    Run r{f.finished(), f.error(), f.dest_path(), f.name(), f.is_torrent(), f.redirects(), f.downloaded()};
    return r;
}

int main(int argc, char** argv) {
    std::string mock = argc > 1 ? argv[1] : "/tmp/anq_all/mock";
    std::string work = argc > 2 ? argv[2] : "/tmp/anq_all/urlwork";
    std::string cmd = "rm -rf '" + work + "' && mkdir -p '" + work + "'";
    if (system(cmd.c_str()) != 0) return 2;
    std::string dd = work + "/downloads", td = work + "/torrents";

    // ── разбор ссылок и имён (без сети)
    {
        ParsedUrl u; std::string e;
        CHECK(urlfetch_parse("https://Example.com:8443/a b/файл.bin?x=1#frag", u, e));
        CHECK(u.scheme == "https" && u.host == "example.com" && u.port == 8443);
        CHECK(u.path == "/a%20b/%D1%84%D0%B0%D0%B9%D0%BB.bin?x=1");
        CHECK(u.hostport() == "example.com:8443");
        CHECK(urlfetch_parse("  example.org/x.torrent \n", u, e) && u.scheme == "http" && u.port == 80 && u.path == "/x.torrent" && u.hostport() == "example.org");
        CHECK(urlfetch_parse("http://h?q=1", u, e) && u.path == "/?q=1");
        CHECK(urlfetch_parse("http://user:pw@h.example/p", u, e) && u.host == "h.example");
        CHECK(!urlfetch_parse("", u, e) && !e.empty());
        CHECK(!urlfetch_parse("ftp://h/x", u, e));
        CHECK(!urlfetch_parse("magnet:?xt=urn:btih:abc", u, e) && e.find("Magnet") != std::string::npos);
        CHECK(!urlfetch_parse("http://h:99999/x", u, e));
        CHECK(!urlfetch_parse("http://[::1]/x", u, e));
        CHECK(!urlfetch_parse("http://сайт.рф/x", u, e));
        CHECK(!urlfetch_parse("http:///x", u, e));
        CHECK(urlfetch_sanitize("a/b\\c:d*e?f\"g<h>i|j") == "a_b_c_d_e_f_g_h_i_j");
        CHECK(urlfetch_sanitize("  ..x.bin.. ") == "x.bin");
        CHECK(urlfetch_sanitize("..") == "" && urlfetch_sanitize("") == "");
        CHECK(urlfetch_sanitize("Игра №1.bin") == "Игра №1.bin");
        CHECK(urlfetch_sanitize(std::string("a\xff" "b")) == "a_b");
        std::string longn(400, 'x'); longn += ".nsp";
        std::string sn = urlfetch_sanitize(longn);
        CHECK(sn.size() <= 150 && sn.size() > 100 && sn.substr(sn.size() - 4) == ".nsp");
        std::string rus; for (int i = 0; i < 200; i++) rus += "ы";
        std::string sr = urlfetch_sanitize(rus + ".bin");
        CHECK(sr.size() <= 150 && sr.substr(sr.size() - 4) == ".bin" && urlfetch_sanitize(sr) == sr);   // UTF-8 не порвано
        CHECK(urlfetch_cd_name("attachment; filename=\"a b.zip\"") == "a b.zip");
        CHECK(urlfetch_cd_name("attachment; filename=plain.zip; size=3") == "plain.zip");
        CHECK(urlfetch_cd_name("attachment; filename=\"x.bin\"; filename*=UTF-8''%D0%98%20%E2%84%961.bin") == "И №1.bin");
        CHECK(urlfetch_cd_name("inline") == "");
        CHECK(urlfetch_cd_name("attachment; filename=\"q\\\"r.bin\"") == "q\"r.bin");
    }

    // порт мок-сервера берём из тестового торрента
    Meta m; std::string e;
    if (!Meta::load(mock + "/torrents/a_mocktest.torrent", m, e) || m.trackers.empty()) { printf("нет торрента: %s\n", e.c_str()); return 2; }
    int port = atoi(m.trackers[0].c_str() + strlen("http://127.0.0.1:"));
    std::string base = "http://127.0.0.1:" + std::to_string(port) + "/dl/";
    std::string single = slurp(mock + "/payload/single.bin");
    std::string slowd = slurp(mock + "/payload/slow.bin");
    printf("порт сервера %d\n", port);

    auto good = [&](const char* label, const std::string& url, const std::string& expect_name, const std::string& expect_data, int redirects = 0) {
        Run r = run(url, dd, td);
        printf("  %-34s %s %s\n", label, r.ok ? "ok" : "ОШИБКА", r.ok ? r.name.c_str() : r.err.c_str());
        CHECK(r.ok);
        if (!r.ok) return r;
        CHECK(r.name == expect_name);
        CHECK(slurp(r.path) == expect_data);
        CHECK(r.redirects == redirects);
        CHECK(!file_exists(r.path + ".part"));
        return r;
    };

    printf("== обычные ответы\n");
    good("Content-Length", base + "plain.bin", "plain.bin", single);
    good("тот же файл ещё раз (без затирания)", base + "plain.bin", "plain.bin", single);
    CHECK(file_exists(dd + "/plain (1).bin"));
    good("без Content-Length (до закрытия)", base + "nolen.bin", "nolen.bin", single);
    good("chunked + расширения + trailer", base + "chunked.bin", "chunked.bin", single);
    good("пустой файл", base + "empty.bin", "empty.bin", "");
    good("имя из пути с UTF-8", base + "%D0%A4%D0%B0%D0%B9%D0%BB.bin", "Файл.bin", single);
    good("без схемы (http по умолчанию)", std::string(base.c_str() + 7) + "plain.bin?a=1", "plain.bin", single);

    printf("== перенаправления\n");
    good("302 → 301 (абсолютный и относительный)", base + "r1", "plain.bin", single, 2);
    good("относительный Location", base + "rel", "plain.bin", single, 1);
    { Run r = run(base + "loop", dd, td); CHECK(!r.ok && r.err.find("перенаправлений") != std::string::npos); printf("  петля: %s\n", r.err.c_str()); }

    printf("== имя файла\n");
    good("Content-Disposition с мусором", base + "cd", "a_b_c_.bin", single);
    good("filename* (UTF-8)", base + "cd2", "Игра №1.bin", single);

    printf("== .torrent уходит в папку торрентов\n");
    { Run r = run(base + "t.torrent?id=1", dd, td); CHECK(r.ok && r.torrent && r.path == td + "/t.torrent" && slurp(r.path) == slurp(mock + "/torrents/a_mocktest.torrent"));
      printf("  %s → %s\n", r.name.c_str(), r.path.c_str()); }
    { Run r = run(base + "get?id=7", dd, td); CHECK(r.ok && r.torrent && r.name == "get.torrent" && r.path == td + "/get.torrent");
      printf("  по Content-Type: %s\n", r.name.c_str()); }
    { Meta mm; std::string ee; CHECK(Meta::load(td + "/t.torrent", mm, ee)); }

    printf("== ошибки\n");
    { Run r = run(base + "missing", dd, td); CHECK(!r.ok && r.err.find("404") != std::string::npos); printf("  404: %s\n", r.err.c_str()); }
    { Run r = run(base + "trunc.bin", dd, td); CHECK(!r.ok && r.err.find("оборвано") != std::string::npos); printf("  обрыв: %s\n", r.err.c_str());
      std::vector<std::string> names; list_dir(dd, names); for (auto& n : names) CHECK(n.find(".part") == std::string::npos); }
    { Run r = run("http://127.0.0.1:9/x", dd, td); CHECK(!r.ok && !r.err.empty()); printf("  порт закрыт: %s\n", r.err.c_str()); }
    { Run r = run("http://no-such-host.invalid/x", dd, td); CHECK(!r.ok && r.err.find("найти сервер") != std::string::npos); printf("  DNS: %s\n", r.err.c_str()); }
    { Run r = run("ftp://x/y", dd, td); CHECK(!r.ok); }
    { Run r = run("https://127.0.0.1:" + std::to_string(port) + "/dl/plain.bin", dd, td); CHECK(!r.ok && r.err.find("HTTPS") != std::string::npos); printf("  https без TLS: %s\n", r.err.c_str()); }
    { Run r = run(base + "plain.bin", dd, td, 0, 1000000); CHECK(!r.ok && r.err.find("места") != std::string::npos); printf("  мало места: %s\n", r.err.c_str());
      CHECK(!file_exists(dd + "/plain (2).bin.part")); }

    printf("== https через хук TLS\n");
    urlfetch_set_tls(fake_tls);
    { Run r = run("https://127.0.0.1:" + std::to_string(port) + "/dl/plain.bin", dd, td); CHECK(r.ok && slurp(r.path) == single && tls_calls == 1 && tls_host == "127.0.0.1"); printf("  вызовов TLS %d, хост %s\n", tls_calls, tls_host.c_str()); }
    urlfetch_set_tls(nullptr);

    printf("== отмена посреди загрузки удаляет .part\n");
    {
        std::string part_seen;
        {
            UrlFetch f(base + "slow.bin", dd, td);
            uint64_t t0 = now_ms();
            while (!f.failed() && !f.finished() && f.downloaded() < 300000 && now_ms() - t0 < 10000) f.tick(now_ms());
            CHECK(f.state() == UrlFetch::S_BODY && f.downloaded() >= 300000 && f.total() == slowd.size());
            CHECK(file_exists(f.dest_path() + ".part"));
            part_seen = f.dest_path() + ".part";
            printf("  скачано %llu из %llu, скорость %.0f КБ/с\n", (unsigned long long)f.downloaded(), (unsigned long long)f.total(), f.speed() / 1024);
        }                                                  // деструктор = отмена
        CHECK(!file_exists(part_seen));
        CHECK(!file_exists(dd + "/slow.bin"));
    }
    printf("== полная скачка медленного файла + скорость\n");
    {
        UrlFetch f(base + "slow.bin", dd, td);
        uint64_t t0 = now_ms(); double maxsp = 0; int states_seen = 0; int last = -1;
        while (!f.failed() && !f.finished() && now_ms() - t0 < 20000) { f.tick(now_ms()); maxsp = std::max(maxsp, f.speed()); if ((int)f.state() != last) { last = (int)f.state(); states_seen++; } }
        CHECK(f.finished() && slurp(f.dest_path()) == slowd && maxsp > 100 * 1024);
        printf("  готово за %llu мс, максимальная скорость %.1f МБ/с, смен состояний %d\n", (unsigned long long)(now_ms() - t0), maxsp / 1048576.0, states_seen);
    }
    printf(fails ? "URL: НЕУДАЧА (%d)\n" : "URL: ВСЁ ОК\n", fails);
    return fails != 0;
}
