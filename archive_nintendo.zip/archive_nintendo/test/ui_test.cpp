// UI-тест: скриншоты вкладок + проверка «5 минут без прогресса → экран гаснет → любая кнопка включает»
#include "../source/app.hpp"
#include "../source/util.hpp"
#include "host_platform.hpp"
#include <stdio.h>
#include <unistd.h>

#define CHECK(c) do { if (!(c)) { printf("FAIL line %d: %s\n", __LINE__, #c); fails++; } } while (0)
static int fails = 0;

int main(int argc, char** argv) {
    std::string root = argc > 1 ? argv[1] : "/tmp/anq/root/";
    std::string shots = argc > 2 ? argv[2] : "/tmp/anq/shots";
    mkdirs(shots);
    HostPlatform pf(root);
    App app(&pf);
    app.init();
    Gfx g;
    uint64_t now = now_ms();
    auto shot = [&](const char* n) { app.draw(g, now); g.save_ppm(shots + "/" + n + ".ppm"); };
    app.frame(0, now);
    app.select_tab(2); shot("1_torrents");
    // A на первом торренте открывает окно выбора; B — отмена
    app.frame(K_A, now);
    CHECK(app.dialog_open() && !app.job_running());
    shot("1b_dialog_auto");
    app.frame(K_DOWN, now); shot("1c_dialog_folder");
    app.frame(K_B, now);
    CHECK(!app.dialog_open() && !app.job_running());
    // A → «Автоустановка» (первый вариант) → загрузка пошла
    app.frame(K_A, now); app.frame(K_A, now);
    CHECK(!app.dialog_open() && app.job_running());
    CHECK(pf.awake);
    // качаем с реального мок-сида
    uint64_t t0 = now_ms();
    for (int i = 0; i < 20 && app.job_running(); i++) { now = now_ms(); app.frame(0, now); }
    now = now_ms(); shot("2_downloads_running");
    while (app.job_running() && now_ms() - t0 < 30000) { now = now_ms(); app.frame(0, now); }
    CHECK(!app.job_running());
    app.select_tab(0); shot("3_installed");
    app.select_tab(1); shot("4_downloads_idle");
    // ── мёртвый торрент b_dead: нет пиров → через stall_limit гаснет экран
    app.select_tab(2);
    app.stall_limit_ms = 1500;                       // для теста: 1.5 с вместо 5 минут
    bool started = false;
    app.frame(K_DOWN, now);
    // выбираем b_dead.torrent
    app.frame(K_A, now_ms()); app.frame(K_A, now_ms());
    started = app.job_running();
    printf("dead job started=%d\n", started);
    uint64_t ts = now_ms();
    while (!app.screen_off() && now_ms() - ts < 6000) { now = now_ms(); app.frame(0, now); }
    printf("screen_off=%d after %llu ms, backlight=%d\n", app.screen_off(), (unsigned long long)(now_ms() - ts), pf.backlight_on);
    CHECK(started && app.screen_off() && !pf.backlight_on && pf.awake);
    app.frame(0, now_ms()); CHECK(app.screen_off());
    app.frame(K_Y, now_ms());                         // любая кнопка — только будит
    CHECK(!app.screen_off() && pf.backlight_on && pf.awake);
    now = now_ms(); app.select_tab(1); shot("5_stalled_awake");
    // ── торрент только с https-трекером: окно не открывается
    app.frame(K_Y, now_ms());
    app.select_tab(2);
    for (int i = 0; i < 4; i++) app.frame(K_DOWN, now_ms());      // пятый по списку: e_https
    app.frame(K_A, now_ms());
    CHECK(!app.dialog_open());
    shot("6_https_refused");
    printf(fails ? "UI: НЕУДАЧА\n" : "UI: ВСЁ ОК\n");
    return fails != 0;
}
