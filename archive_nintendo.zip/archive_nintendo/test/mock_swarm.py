#!/usr/bin/env python3
"""Локальный стенд: HTTP- и UDP-трекер + 2 сида. Создаёт тестовые торренты.
Использование: mock_swarm.py <outdir> [bad]"""
import hashlib, os, socket, struct, sys, threading, random, http.server, socketserver, time

out = sys.argv[1]
bad = len(sys.argv) > 2 and sys.argv[2] == "bad"
random.seed(7)
os.makedirs(out + "/payload/mocktest/a", exist_ok=True)
os.makedirs(out + "/payload/mocktest/c/d", exist_ok=True)
os.makedirs(out + "/torrents", exist_ok=True)

def rnd(n): return bytes(random.getrandbits(8) for _ in range(n))
files = [("a/one.bin", rnd(3300000)), ("b_empty.txt", b""), ("b/two.bin", rnd(1000000)), ("c/d/three.bin", rnd(500001))]
for rel, data in files:
    p = out + "/payload/mocktest/" + rel
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, "wb").write(data)
single = rnd(777777)
open(out + "/payload/single.bin", "wb").write(single)

def benc(v):
    if isinstance(v, int): return b"i%de" % v
    if isinstance(v, bytes): return b"%d:" % len(v) + v
    if isinstance(v, str): return benc(v.encode())
    if isinstance(v, list): return b"l" + b"".join(benc(x) for x in v) + b"e"
    if isinstance(v, dict): return b"d" + b"".join(benc(k) + benc(v[k]) for k in sorted(v)) + b"e"
    raise TypeError

PL = 262144
def mk_info(name, flist):
    blob = b"".join(d for _, d in flist)
    hashes = b"".join(hashlib.sha1(blob[i:i + PL]).digest() for i in range(0, len(blob), PL))
    info = {"name": name, "piece length": PL, "pieces": hashes}
    if len(flist) == 1 and flist[0][0] is None: info["length"] = len(blob)
    else: info["files"] = [{"length": len(d), "path": r.split("/")} for r, d in flist]
    return info, blob

# ── фиктивный NSP (PFS0): 3 NCA + мета-NCA + билет/сертификат
def pfs0(items):
    st = b""; offs = []
    for n, _ in items: offs.append(len(st)); st += n.encode() + b"\0"
    while len(st) % 16: st += b"\0"
    h = b"PFS0" + struct.pack("<III", len(items), len(st), 0)
    o = 0
    for (n, d), so in zip(items, offs):
        h += struct.pack("<QQII", o, len(d), so, 0); o += len(d)
    return h + st + b"".join(d for _, d in items)
random.seed(11)
NCAS = [("11111111111111111111111111111111.nca", rnd(1300000)), ("22222222222222222222222222222222.nca", rnd(2200000)),
        ("33333333333333333333333333333333.nca", rnd(500000)), ("44444444444444444444444444444444.cnmt.nca", rnd(16384)),
        ("0100aaaa0000.tik", rnd(0x2C0)), ("0100aaaa0000.cert", rnd(0x700)), ("note.xml", b"<x/>")]
nsp = pfs0(NCAS)
open(out + "/payload/game.nsp", "wb").write(nsp)
info_n, blob_n = mk_info("game.nsp", [(None, nsp)])
info_a, blob_a = mk_info("mocktest", files)
info_b, blob_b = mk_info("single.bin", [(None, single)])
slow_data = rnd(6000000)
info_s, blob_s = mk_info("slow.bin", [(None, slow_data)])
open(out + "/payload/slow.bin", "wb").write(slow_data)
SLOW_IH = hashlib.sha1(benc(info_s)).digest()      # на этом торренте второй сид медленный (≈64 КБ/с), первый быстрый
blobs = {SLOW_IH: blob_s, hashlib.sha1(benc(info_a)).digest(): blob_a, hashlib.sha1(benc(info_b)).digest(): blob_b, hashlib.sha1(benc(info_n)).digest(): blob_n}
infos = {}

# ── сиды
corrupted = set()
def seeder(sock, idx):
    while True:
        c, _ = sock.accept()
        threading.Thread(target=serve, args=(c, idx), daemon=True).start()

def recvn(c, n):
    b = b""
    while len(b) < n:
        x = c.recv(n - len(b))
        if not x: raise EOFError
        b += x
    return b

def serve(c, idx):
    try:
        hs = recvn(c, 68)
        ih = hs[28:48]
        if ih not in blobs: c.close(); return
        blob = blobs[ih]; npieces = (len(blob) + PL - 1) // PL
        slow = idx == 1 and ih == SLOW_IH
        c.sendall(bytes([19]) + b"BitTorrent protocol" + bytes(8) + ih + b"-MOCK00-123456789012")
        bf = bytearray((npieces + 7) // 8)
        for i in range(npieces): bf[i >> 3] |= 0x80 >> (i & 7)
        c.sendall(struct.pack(">IB", 1 + len(bf), 5) + bytes(bf))
        while True:
            ln = struct.unpack(">I", recvn(c, 4))[0]
            if ln == 0: continue
            m = recvn(c, ln)
            if m[0] == 2: c.sendall(struct.pack(">IB", 1, 1))
            elif m[0] == 6:
                idx, beg, l = struct.unpack(">III", m[1:13])
                d = bytearray(blob[idx * PL + beg: idx * PL + beg + l])
                if bad and idx == 3 and beg == 0 and "x" not in corrupted and ih == list(blobs)[0]:
                    corrupted.add("x"); d[5] ^= 0xFF
                c.sendall(struct.pack(">IBII", 9 + len(d), 7, idx, beg) + bytes(d))
                time.sleep(0.25 if slow else 0.001)
    except Exception:
        try: c.close()
        except Exception: pass

ports = []
for idx in range(2):
    s = socket.socket(); s.bind(("127.0.0.1", 0)); s.listen(16)
    ports.append(s.getsockname()[1])
    threading.Thread(target=seeder, args=(s, idx), daemon=True).start()
peers = b"".join(socket.inet_aton("127.0.0.1") + struct.pack(">H", p) for p in ports)

import urllib.parse
class H(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    def do_GET(self):
        if self.path.startswith("/dl/"): return self.dl()
        body = benc({"interval": 60, "peers": peers})
        self.send_response(200); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def reply(self, code, headers, body=b"", length=True):
        self.send_response(code)
        for k, v in headers: self.send_header(k, v)
        if length: self.send_header("Content-Length", str(len(body)))
        else: self.send_header("Connection", "close"); self.close_connection = True
        self.end_headers(); self.wfile.write(body)
    def dl(self):
        """Маршруты для проверки загрузки по ссылке"""
        path = self.path.split("?")[0]
        name = urllib.parse.unquote(path[4:])
        me = "http://127.0.0.1:%d" % self.server.server_address[1]
        if name == "plain.bin": self.reply(200, [("Content-Type", "application/octet-stream")], single)
        elif name == "empty.bin": self.reply(200, [], b"")
        elif name == "nolen.bin": self.reply(200, [], single, length=False)
        elif name == "chunked.bin":
            self.send_response(200); self.send_header("Transfer-Encoding", "chunked"); self.send_header("Connection", "close"); self.close_connection = True; self.end_headers()
            pos, sizes, i = 0, [1, 100, 4096, 70000, 255, 300000], 0
            while pos < len(single):
                n = min(sizes[i % len(sizes)], len(single) - pos); i += 1
                self.wfile.write(b"%x;ext=1\r\n" % n + single[pos:pos + n] + b"\r\n"); pos += n
            self.wfile.write(b"0\r\nX-Trailer: yes\r\n\r\n")
        elif name == "r1": self.reply(302, [("Location", "/dl/r2")])
        elif name == "r2": self.reply(301, [("Location", me + "/dl/plain.bin?x=1")])
        elif name == "rel": self.reply(302, [("Location", "plain.bin")])
        elif name == "loop": self.reply(302, [("Location", "/dl/loop")])
        elif name == "cd": self.reply(200, [("Content-Disposition", 'attachment; filename="a/b:c?.bin"')], single)
        elif name == "cd2": self.reply(200, [("Content-Disposition", "attachment; filename=\"x.bin\"; filename*=UTF-8''%D0%98%D0%B3%D1%80%D0%B0%20%E2%84%961.bin")], single)
        elif name == "Файл.bin": self.reply(200, [], single)
        elif name == "t.torrent": self.reply(200, [("Content-Type", "application/x-bittorrent")], open(out + "/torrents/a_mocktest.torrent", "rb").read())
        elif name == "get": self.reply(200, [("Content-Type", "application/x-bittorrent")], open(out + "/torrents/b_single.torrent", "rb").read())
        elif name == "trunc.bin":
            self.send_response(200); self.send_header("Content-Length", "1000000"); self.send_header("Connection", "close"); self.close_connection = True; self.end_headers()
            self.wfile.write(single[:300000])
        elif name == "slow.bin":
            self.send_response(200); self.send_header("Content-Length", str(len(slow_data))); self.end_headers()
            try:
                for i in range(0, len(slow_data), 65536):
                    self.wfile.write(slow_data[i:i + 65536]); self.wfile.flush(); time.sleep(0.02)
            except Exception: pass
        else: self.reply(404, [("Content-Type", "text/plain")], b"not found")
    def log_message(self, *a): pass
httpd = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
hport = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()

class U(socketserver.BaseRequestHandler):
    def handle(self):
        data, sock = self.request
        if len(data) >= 16 and struct.unpack(">Q", data[:8])[0] == 0x41727101980 and struct.unpack(">I", data[8:12])[0] == 0:
            sock.sendto(struct.pack(">II", 0, struct.unpack(">I", data[12:16])[0]) + b"CONNID12", self.client_address)
        elif len(data) >= 98 and struct.unpack(">I", data[8:12])[0] == 1:
            # как opentracker: num_want (смещение 92) == 0 → пиров не отдаём
            nw = struct.unpack(">i", data[92:96])[0]
            out_peers = b"" if nw == 0 else peers
            sock.sendto(struct.pack(">IIIII", 1, struct.unpack(">I", data[12:16])[0], 60, 0, 2) + out_peers, self.client_address)
udp = socketserver.ThreadingUDPServer(("127.0.0.1", 0), U)
uport = udp.server_address[1]
threading.Thread(target=udp.serve_forever, daemon=True).start()

def write_torrent(fn, info, announce, alist=None):
    t = {"announce": announce, "info": info}
    if alist: t["announce-list"] = alist
    open(out + "/torrents/" + fn, "wb").write(benc(t))
dead = rnd(300000)
info_dead, blob_dead = mk_info("dead.bin", [(None, dead)])
info_https, blob_https = mk_info("https.bin", [(None, rnd(100000))])
write_torrent("f_slow.torrent", info_s, "http://127.0.0.1:%d/announce" % hport)   # быстрый + медленный сид
write_torrent("b_dead.torrent", info_dead, "http://127.0.0.1:9/announce")          # трекер не отвечает
write_torrent("e_https.torrent", info_https, "https://tracker.invalid/announce")   # только https — не поддерживается
write_torrent("a_mocktest.torrent", info_a, "http://127.0.0.1:%d/announce" % hport)
write_torrent("d_nsp.torrent", info_n, "http://127.0.0.1:%d/announce" % hport)
write_torrent("b_single.torrent", info_b, "udp://127.0.0.1:%d" % uport, [["https://nope.invalid/announce"], ["udp://127.0.0.1:%d" % uport]])
print("READY", flush=True)
while True: time.sleep(1)
