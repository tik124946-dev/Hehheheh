#!/bin/bash
# Полный прогон хост-тестов. Запуск: test/run_all.sh <рабочая папка>
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"; SRC="$HERE/../source"; W="${1:-/tmp/anq_all}"
FL="-std=c++17 -O1 -g -fsanitize=address,undefined -Wall -Wextra"
mkdir -p "$W/bin"
g++ $FL -o "$W/bin/host_test"   "$HERE/host_test.cpp"   "$SRC/swarm.cpp" "$SRC/meta.cpp" "$SRC/util.cpp"
g++ $FL -o "$W/bin/resume_test" "$HERE/resume_test.cpp" "$SRC/swarm.cpp" "$SRC/meta.cpp" "$SRC/util.cpp" "$SRC/router.cpp" "$SRC/nsp_install.cpp" "$SRC/zipx.cpp" -lz
g++ $FL -o "$W/bin/nsp_test"    "$HERE/nsp_test.cpp"    "$SRC/nsp_install.cpp" "$SRC/util.cpp" -lz
APPSRC="$SRC/app.cpp $SRC/gfx.cpp $SRC/swarm.cpp $SRC/meta.cpp $SRC/util.cpp $SRC/router.cpp $SRC/library.cpp $SRC/nsp_install.cpp $SRC/zipx.cpp $SRC/urlfetch.cpp"
g++ $FL -o "$W/bin/ui_test"     "$HERE/ui_test.cpp"     $APPSRC -lz
g++ $FL -o "$W/bin/touch_url_test" "$HERE/touch_url_test.cpp" $APPSRC -lz
g++ $FL -o "$W/bin/url_test"    "$HERE/url_test.cpp"    "$SRC/urlfetch.cpp" "$SRC/meta.cpp" "$SRC/util.cpp"
pkill -f mock_swarm.py || true; sleep 1
rm -rf "$W/mock" && mkdir -p "$W/mock"
(python3 -I "$HERE/mock_swarm.py" "$W/mock" > "$W/mock.log" 2>&1 &)
for i in 1 2 3 4 5 6 7 8 9 10; do grep -q READY "$W/mock.log" && break; sleep 1; done
grep -q READY "$W/mock.log" || { echo "мок-стенд не запустился"; exit 1; }
M="$W/mock"
echo "== nsp_test";    "$W/bin/nsp_test" | tail -2
echo "== host: a_mocktest (HTTP-трекер)"; rm -rf "$W/o1"; "$W/bin/host_test" "$M/torrents/a_mocktest.torrent" "$W/o1" | tr '\r' '\n' | tail -2; diff -r "$M/payload/mocktest" "$W/o1/mocktest" && echo "содержимое совпало"
echo "== host: b_single (UDP-трекер)";    rm -rf "$W/o2"; "$W/bin/host_test" "$M/torrents/b_single.torrent" "$W/o2" | tr '\r' '\n' | tail -2; cmp "$M/payload/single.bin" "$W/o2/single.bin" && echo "содержимое совпало"
echo "== host: старт с 3-го файла";       rm -rf "$W/o3"; "$W/bin/host_test" "$M/torrents/a_mocktest.torrent" "$W/o3" 2 | tr '\r' '\n' | tail -2; cmp "$M/payload/mocktest/b/two.bin" "$W/o3/mocktest/b/two.bin" && echo "содержимое совпало"
echo "== host: быстрый + медленный сид (раньше ~3300 мс)"; rm -rf "$W/o4"; R=$("$W/bin/host_test" "$M/torrents/f_slow.torrent" "$W/o4" | tr '\r' '\n' | tail -1); echo "$R"; cmp "$M/payload/slow.bin" "$W/o4/slow.bin" && echo "содержимое совпало"
T=$(echo "$R" | sed -n 's/.*time=\([0-9]*\)ms.*/\1/p'); [ "${T:-99999}" -lt 2600 ] && echo "скорость в норме (${T} мс)" || { echo "СЛИШКОМ МЕДЛЕННО: ${T} мс"; exit 1; }
echo "== resume_test"; rm -rf "$W/work"; "$W/bin/resume_test" "$M" "$W/work" | tail -8
echo "== ui_test";     rm -rf "$W/root" "$W/shots"; mkdir -p "$W/root/archive_nintendo/torrents"; cp "$M"/torrents/*.torrent "$W/root/archive_nintendo/torrents/"; "$W/bin/ui_test" "$W/root/" "$W/shots" | tail -6
echo "== url_test (загрузка по ссылке)"; "$W/bin/url_test" "$M" "$W/urlwork" | tail -12
echo "== touch_url_test (касания и окно ссылки)"; rm -rf "$W/root2" "$W/shots2"; mkdir -p "$W/root2/archive_nintendo/torrents"; for f in "$M"/torrents/*.torrent; do [ "$(basename "$f")" = "b_single.torrent" ] || cp "$f" "$W/root2/archive_nintendo/torrents/"; done; "$W/bin/touch_url_test" "$W/root2/" "$M" "$W/shots2" | tail -40
pkill -f mock_swarm.py || true
