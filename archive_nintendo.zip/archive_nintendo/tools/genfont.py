#!/usr/bin/env python3
"""Генерирует source/font_data.h (растровые шрифты DejaVu с кириллицей)."""
import sys
from PIL import ImageFont

REG = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
BOLD = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"
SPECS = [("F_SMALL", REG, 15), ("F_BODY", REG, 20), ("F_TITLE", BOLD, 26), ("F_BIG", BOLD, 36)]

cps = list(range(0x20, 0x7F)) + list(range(0x410, 0x450)) + [0x401, 0x451]
cps += [0x2116, 0x2190, 0x2191, 0x2192, 0x2193, 0x2022, 0x2713, 0xD7, 0x2026,
        0x2014, 0xAB, 0xBB, 0x25B6, 0x25A0, 0x25AE, 0xB7, 0x2212, 0x2261, 0x203A, 0x2248]
cps = sorted(set(cps))

out = ["// Автогенерация tools/genfont.py — не править руками.",
       "#pragma once", "#include <stdint.h>",
       "struct FGlyph { uint32_t cp; uint32_t off; uint8_t w, h; int8_t bx, by; uint8_t adv; };",
       "struct FFont { int height, ascent, n; const FGlyph* g; const uint8_t* bmp; };"]
for name, path, size in SPECS:
    font = ImageFont.truetype(path, size)
    asc, desc = font.getmetrics()
    glyphs, bmp = [], bytearray()
    for cp in cps:
        ch = chr(cp)
        adv = int(round(font.getlength(ch)))
        bb = font.getbbox(ch, anchor="ls")  # relative to baseline origin
        if bb is None or bb[2] <= bb[0] or bb[3] <= bb[1]:
            glyphs.append((cp, len(bmp), 0, 0, 0, 0, adv))
            continue
        x0, y0, x1, y1 = bb
        mask = font.getmask(ch, mode="L", anchor="ls")
        w, h = mask.size
        data = bytes(mask)
        # getmask с anchor ls возвращает маску размером bbox
        glyphs.append((cp, len(bmp), w, h, x0, y0, adv))
        bmp.extend(data[: w * h])
    n = name.lower()
    out.append(f"static const uint8_t {n}_bmp[] = {{")
    row = []
    for i, b in enumerate(bmp):
        row.append(str(b))
        if len(row) == 40:
            out.append(",".join(row) + ","); row = []
    if row: out.append(",".join(row) + ",")
    out.append("0};")
    out.append(f"static const FGlyph {n}_glyphs[] = {{")
    for g in glyphs:
        out.append("{%d,%d,%d,%d,%d,%d,%d}," % g)
    out.append("};")
    out.append(f"static const FFont {n}_font = {{{asc + desc}, {asc}, {len(glyphs)}, {n}_glyphs, {n}_bmp}};")
open(sys.argv[1] if len(sys.argv) > 1 else "source/font_data.h", "w").write("\n".join(out) + "\n")
print("glyphs:", len(cps))
